<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Kiosco | Combu-Express</title>
<link rel="icon" type="image/png" href="img/favicon.ico" />
	<link rel="stylesheet" type="text/css" href="css3/style.css" media="all" />
</head>

<body>
<table width="100%" border="0">
  <tr>
    <td colspan="3" align="center"><div style="margin-bottom:10%; margin-top:5%"><img src="images/logo.png" alt="" width="406" height="99"/></div></td>
  </tr>
  <tr>
    <td width="36%" align="center"><a href="clientes"><img src="img/apli-clientes.png" width="224" height="203"  alt=""/></a></td>
    <td width="31%" align="center"><img src="img/apli-facturacion.png" width="224" height="203"  alt=""/></td>
    <td width="33%" align="center"><<img src="img/apli-monedero.png" width="224" height="203"  alt=""/></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
</table>
</body>
</html>