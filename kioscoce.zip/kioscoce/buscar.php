<?php
require_once 'include/conecta.php';

if($_GET['type'] == 'cliente'){
	$result = mysql_query("SELECT id_cliente,rfc,nombre FROM clientes where nombre LIKE '".strtoupper($_GET['name_startsWith'])."%' or rfc LIKE '".strtoupper($_GET['name_startsWith'])."%' order by nombre ASC limit 7");	
	$data = array();
	while ($row = mysql_fetch_array($result)) {
		array_push($data, $row['rfc']."-".$row['nombre']);	
	}	
	echo json_encode($data);
}

if($_GET['type'] == 'despachador'){
	$result = mysql_query("SELECT id,nombre FROM despachadores where nombre LIKE '".strtoupper($_GET['name_startsWith'])."%' order by nombre ASC limit 10");	
	$data = array();
	while ($row = mysql_fetch_array($result)) {
		array_push($data, $row['id']."-".$row['nombre']);	
	}	
	echo json_encode($data);
}

?>