<?php
error_reporting (E_ALL & ~E_STRICT ^ E_NOTICE );
session_start();
$cliente =$_POST['rfc'];
unset($_SESSION['numfactura'],$_SESSION['id_domicilio']);
  $_SESSION['rfc2'] =$cliente;
  echo json_encode($jsondata);
  @mysql_close($db_link);
?>