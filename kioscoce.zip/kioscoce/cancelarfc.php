<?
session_start();
unset($_SESSION['rfc'],$_SESSION['numfactura'],$_SESSION['id_domicilio'],$_SESSION['rfc2'],$_SESSION['tipofact']);
header( "Location: index.php" );
?>