<?php
error_reporting (E_ALL & ~E_STRICT ^ E_NOTICE );
@session_start();
$id_cliente =trim($_POST['id_cliente']);
$calle =strtoupper(trim($_POST['calle']));
$exterior =trim($_POST['exterior']);
$interior =trim($_POST['interior']);
$cp =trim($_POST['cp']);
$colonia =strtoupper(trim($_POST['colonia']));
$localidad =strtoupper(trim($_POST['localidad']));
$municipio =strtoupper(trim($_POST['municipio']));
$pais =strtoupper(trim($_POST['pais']));
$id_estado =trim($_POST['id_estado']);
$fecha_alta=date("Y-m-d H:i:s");


  include("include/conecta.php");

  $sql=mysql_query("insert into domicilio (id_cliente,calle,exterior,interior,cp,colonia,localidad,municipio,pais,id_estado,fecha_alta)value('$id_cliente','$calle','$exterior','$interior','$cp','$colonia','$localidad','$municipio','$pais','$id_estado','$fecha_alta') ");   

//   $jsondata['valido']=2;

 
  echo json_encode($jsondata);
  @mysql_close($db_link);
?>