<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en">

<?
error_reporting (E_ALL & ~E_STRICT ^ E_NOTICE );
session_start();
include("include/conecta.php");
$user= $_SESSION['user'];
$nombre= $_SESSION['nombre'];
$rfc=$_SESSION['rfc'];
$rfc2=$_SESSION['rfc2'];
$progreso=$_SESSION['progreso'];
$pro=$_SESSION['pro'];
$id_domicilio=$_SESSION['id_domicilio'];
$id_estacion=$_SESSION['id_estacion'];
$id_formpago=$_SESSION['id_formpago'];
$numfactura=$_SESSION['numfactura'];
$descarga=$_SESSION['progreso'];
$nip=$_SESSION['nip'];


$sql=mysql_query("select id_cliente,rfc,nombre,correo,telefono from clientes where rfc='$rfc'");
$dDatos=mysql_fetch_assoc($sql);

$sql1=mysql_query("select d.*,e.nombre as estado from domicilio as d left outer join estado as e on e.id_estado=d.id_estado where id_domicilio='$id_domicilio'");
$dDatos1=@mysql_fetch_assoc($sql1);



	$id_cliente=$dDatos['id_cliente'];
    $sD=mysql_query("select d.*,e.nombre as estado from domicilio as d left outer join estado as e on e.id_estado=d.id_estado where id_cliente='$id_cliente' "); 
$direcciones=mysql_num_rows($sD);


$sql2=mysql_query("select nombre_estacion,pemex from estaciones where id='$id_estacion'");
$dDatos2=@mysql_fetch_assoc($sql2);

//$sqd=mysql_query("select id,nombre from usuario	 where nip='$nip'");
//$dDes=@mysql_fetch_assoc($sqd);

//$sqc=mysql_query("select * from clientes where rfc='$rfc'");
//$dClie=@mysql_fetch_assoc($sqc);

$sql3=mysql_query("select descripcion from instrumento_monetario where id='$id_formpago'");
$dDatos3=@mysql_fetch_assoc($sql3);

$sT=@mysql_query("select t.*,p.denominacion as producto from tickets as t left outer join productos as p on p.id=t.id_producto where numfactura='$numfactura'");
$tickets=mysql_num_rows($sT);
//echo $tickets;
?>
<head>
<meta http-equiv="Content-Type" content="text/html;charset=UTF-8" />
<title>Kiosco | Combu-Express</title>
<link rel="icon" type="image/png" href="img/favicon.ico" />
	
	<link rel="stylesheet" type="text/css" href="css3/style.css" media="all" />
	
    <script type="text/javascript" src="js3/jquery.min.js"></script>
    <script type="text/javascript" src="js3/jquery-1.7.0.min.js"></script>
        
    <script type="text/javascript" src="js3/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js3/jquery.inputfocus-0.9.min.js"></script>
    <script type="text/javascript" src="js3/jquery.main.js"></script>
    <script  type="text/javascript" src="js3/jquery.blockUI.js"></script>
       
	<script type="text/javascript" src="js3/jquery.tooltipster.js"></script>
    <link rel="stylesheet" type="text/css" href="css3/tooltipster.css" />
    
	<link rel="stylesheet" href="css3/jquery.ui.all.css">
	<script src="js3/jquery.ui.core.js"></script>
	<script src="js3/jquery.ui.widget.js"></script>
	<script src="js3/jquery.ui.datepicker.js"></script>

	<script type="text/javascript">
		$(document).ready(function() {
			$('.tooltip').tooltipster({ position: 'bottom' });
		});
	</script>

	<script> 
	$(function() {
		$( "#datepicker" ).datepicker({
			changeMonth: true,
			changeYear: true
		});
	});
	</script>

<script>
function progreso(){

<? if($progreso==1){ ?>
 $('#progress_text').html('20% Complete');
 $('#progress').css('width','90px');
<? }?>

<? if($pro==3){?> 
 $('#progress_text').html('70% Complete');
 $('#progress').css('width','250px'); 
<? }?>

}

var nav4 = window.Event ? true : false; 
function acceptNum(evt){  
// NOTE: Backspace = 8, Enter = 13, '0' = 48, '9' = 57  
var key = nav4 ? evt.which : evt.keyCode;  
return (key <= 13 || (key >= 48 && key <= 57)); 
} 
</script>
<style>
 <? if (!empty($rfc)){?>
    #container .form { margin: 0px 0px 0 340px; }
 <?  }else{ ?>
  	   #container .form { margin: 40px 72px 0 340px; }
 <? }  ?>
</style>

<script>

function pago(valor)
{

$('#cuentaP input').remove();	
id_pago= valor.value; 
//alert (id_pago);
if(id_pago=='99' || id_pago=='01' || id_pago=='08' || id_pago=='98'){
	$('#cuentaP input').remove();		
}else{
	campo = '<input name="numcuenta" type="text" class="rfc1" id="numcuenta" placeholder="Num Cuenta" onkeypress="return acceptNum(event)"  style="text-align:center" maxlength="4"  />';
	$("#cuentaP").append(campo);	
}

}
	</script>

</head>

<body onload="progreso();">
<div id="loading" style="display:none;"><img src="images/image_725610.gif" alt="" width="85" height="85" /></div>
<!--inicio container-->
<div id="container">

<table width="100%" border="0" align="center">
          <tr>
            <td colspan="4" align="center"><img src="images/logo.png" alt="" width="406" height="99" /></td>


          </tr>
          <tr>
      
            <td colspan="2" style="vertical-align:top;">
           <!--
             <div style=" top: 120px;" class="banner">
 <a href="#" id="home"><img src="images/inicio.png" alt="" width="30" height="30" border="0" style="margin-left:10px;" class="tooltip" title="Inicio" /></a>          
 <a href="busca"  id="buscar"><img src="images/facturasestacion.png" alt="" width="40" height="30" border="0" style="margin-left:10px;" class="tooltip" title="Buscar Facturas de Estacion" /></a>
 <a href="buscap"  id="buscar"><img src="images/facturasportal.png" alt="" width="40" height="30" border="0" style="margin-left:10px;" class="tooltip" title="Buscar Facturas de Portal" /></a>
 <a href="eclientes"  id="buscar"><img src="images/editardatos.png" alt="" width="30" height="30" border="0" style="margin-left:10px;" class="tooltip" title="Buscar Clientes" /></a>
 <a href="buscat"  id="buscar"><img src="images/buscaticket.png" alt="" width="40" height="30" border="0" style="margin-left:10px;" class="tooltip" title="Liberar Ticket" /></a>
 
              </div>
            -->
            <!--<span style="color:#FFF;"><a href="busca" class="enlace" id="buscar">Buscar Facturas</a></span>-->
            <div > <a href="logout.php" ><img src="images/home.png" width="181" height="54" /></a> </div></td>
            <td width="599" colspan="3" align="right" style="vertical-align:top;">&nbsp;</td>


          </tr>
</table>

<div id="contenido">
<? if (empty($rfc)){?>
 
 
  <? if (!empty($rfc2)){?>

    <!-- por si no existe el cliente o rfc -->
    
        <div id="second_step">

          <table width="850" border="0" align="center" class="table">
  <tr>
    <td colspan="7" height="7"></td>
  </tr>
  <tr>

    <td>RFC:</td>
   
    <td>Nombre:</td>
 
    <td width="315">correo:</td>
    <td width="131">Teléfono:</td>
  </tr>
  <tr>
  
    <td width="144"><input name="rfc" type="text" id="rfc" class="rfc1" value="<?=$rfc2?>" size="18" readonly="readonly" style="text-align:center" /></td>

    <td width="317"><input name="nombre" class="rfc1" type="text" id="nombre" size="35" style="text-align:center" /></td>
  
    <td><input name="correo" type="text" class="rfc1" id="correo" size="35" style="text-align:center" /></td>
    <td><input name="telefono" class="rfc1" type="text" id="telefono" size="15" style="text-align:center" /></td>
  </tr>
</table>
          <table width="850" border="0" align="center" class="table">
            <tr>
              <td width="339"><span style="margin-left:4px;">Calle:</span></td>
              <td width="115"> Exterior:</td>
              <td width="128"> Interior:</td>
              <td width="325">cp:</td>
            </tr>
            <tr>
              <td><input name="calle" class="rfc1" type="text" id="calle" size="40" style="text-align:center" /></td>
              <td><input name="exterior" type="text" class="rfc1" id="exterior"  size="10" style="text-align:center"  /></td>
              <td><input name="interior" type="text" class="rfc1" id="interior"  size="10"  style="text-align:center" /></td>
              <td><input name="cp" type="text" class="rfc1" id="cp"  size="10" style="text-align:center" /></td>
            </tr>
          </table>
          <table width="850" border="0" align="center" class="table">
            <tr>
              <td colspan="2">Colonia:</td>
              <td colspan="2">Localidad:</td>
              <td width="318">Municipio:</td>
            </tr>
            <tr>
              <td colspan="2"><input name="colonia" class="rfc1" type="text" id="colonia" size="40" style="text-align:center" /></td>
              <td colspan="2"><input name="localidad" class="rfc1" type="text" id="localidad" size="28" style="text-align:center" /></td>
              <td><input name="municipio" class="rfc1" type="text" id="municipio" size="35" style="text-align:center" /></td>
            </tr>
            <tr>
              <td width="148">País:</td>
              <td width="188">Estado:</td>
              <td width="132" align="center">&nbsp;</td>
              <td width="117" align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
            </tr>
            <tr>
              <td><select  name="pais" id="pais" class="rfc1" style="width:130px"  >
                <option value="Mexico ">México</option>
              </select></td>
              <td><select name="id_estado" class="rfc1" id="id_estado" >
                <option value="">Seleccione</option>
                <?	
           $qEst=mysql_query("SELECT * FROM estado order by nombre ASC ");
           while ($dEst=mysql_fetch_assoc($qEst)){
                        ?>
                <option value="<?=$dEst['id_estado']?>" >
                  <?=($dEst['nombre'])?>
                </option>
                <? }?>
              </select></td>
              <td align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
            </tr>
          </table>
          <table width="850" border="0" align="center" class="table">
            <tr>
              <td>&nbsp;</td>
            </tr>
            <tr>
              <td width="919"><input type="submit" name="crearfc" id="crearfc" value="C o n t i n u a r "   class="boton" />
              <input type="submit" name="cancelarRFC" id="cancelarRFC" value="Cancelar"  class="boton" />
              <input type="hidden" name="id_cliente" id="id_cliente" value="<?=$dDatos['id_cliente']?>" /></td>
            </tr>
          </table>
      
</div>


 <div id="estacion" style="display:none">
 <table width="925" border="0" align="center" class="table2" >
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><img src="images/seleccion.png" alt="" width="30" height="23" /></td>
    <td>Dirección:</td>
    <td><div id="dirseleccionada"></div></td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
    <td>Estación:</td>
    <td><select name="id_estacion" class="second" id="id_estacion" >
      <option value="">Seleccione</option>
      <?	
           $qEsta=mysql_query("SELECT * FROM estaciones order by nombre_estacion ASC ");
           while ($dEsta=mysql_fetch_assoc($qEsta)){
                        ?>
      <option value="<?=$dEsta['id']?>" >
        <?=($dEsta['nombre_estacion'])?>
        </option>
      <? }?>
    </select></td>
  </tr>
  <tr>
    <td width="38" align="center">&nbsp;</td>
    <td width="130">Forma de Pago:</td>
    <td width="743"><select name="id_formpago" class="second" id="id_formpago" >
      <option value="">Seleccione</option>
      <?	
           $qF=mysql_query("SELECT * FROM instrumento_monetario  limit 3 ");
           while ($dF=mysql_fetch_assoc($qF)){
                        ?>
      <option value="<?=$dF['clave']?>" >
        <?=($dF['descripcion'])?>
        </option>
      <? }?>
    </select></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">
      <input type="hidden" name="rfc" id="rfc" value="<?=$dDatos['rfc']?>" />
      <input type="hidden" name="domicilio" id="domicilio" />
      <input type="submit" name="anterior" id="anterior" value="A n t e r i o r"   class="boton" />
      <input type="submit" name="submit_estacion" id="submit_estacion" value="S i g u i e n t e"   class="boton" /></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
 </table>
</div>
    


  <? }else{?> 
 
 <div id="rfc_cliente">
  <table width="850" border="0" align="center" class="table">
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2">&nbsp;</td>
  </tr>
  <tr>

    <td width="607" align="center">

     <div id="inputcliente" style="margin-left:150px;">
    <input name="cliente" type="text" class="cliente" id="cliente" placeholder="Ingrese RFC o Nombre de Cliente"   style="text-align:center; font-size: 26px;" />
    </div>

    </td>
  </tr>
  <tr>
  <td colspan="2" align="center">

  <input type="submit"    name="submit_buscarcliente" id="submit_buscarcliente"  value="C o n t i n u a r "   class="boton" />

  <input type="hidden" name="id_estacion" id="id_estacion" value="<?=$id_estacion?>">
  
  </td>
  </tr>
  </table>
</div>
  <? }?>
  
  
<? }else{ ?>
       <div id="first_step"> 
  <? if($direcciones>0){?>
  <div id="facturas" align="center">
    <table width="850" border="0" class="table">
            <tr>
              <td width="125" align="center"><strong>RFC:</strong></td>
              <td width="283" align="center"><strong>Nombre:</strong></td>
              <td width="313" align="center"><strong>correo:</strong></td>
              <td width="186" align="center"><strong>Teléfono:</strong></td>
            </tr>
            <tr>
              <td align="center"><div  class="cuadro"><?=$dDatos['rfc']?></div></td>
              <td align="center"><div  class="cuadro"><?=$dDatos['nombre']?></div></td>
              <td align="center"><div  class="cuadro"><?=$dDatos['correo']?></div></td>
              <td align="center"><div  class="cuadro"><?=$dDatos['telefono']?></div></td>
            </tr>
    </table>
       
  <? if(!empty($numfactura) && !empty($id_domicilio)) { ?>
	
  <? 
  if($_SESSION['tipofact']=='conticket')
  { include("conticket.php"); }
  else if($_SESSION['tipofact']=='sinticket')
  { include("sinticket.php"); }
  else if($_SESSION['tipofact']=='monedero')
  { include("monedero.php"); }
  else if($_SESSION['tipofact']=='anticipos')
  { include("anticipos.php"); }
  else if($_SESSION['tipofact']=='contar')
  { include("contar.php"); }
  else{
  ?>
  <table width="850" border="0" align="center">
  <tr>
  <td colspan="3" align="center">&nbsp;</td>
  </tr>
  <tr>
  <td colspan="3" align="center"><strong>Favor de elegir el tipo de Facturacion:</strong></td>
  </tr>
  <tr>
    <td colspan="3" align="center">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">
    
    <div id="camposmon" style="display:none;">
    <table width="745" border="0" align="center" cellpadding="0" cellspacing="0">
      <tr>
        <td align="center">&nbsp;</td>
      </tr>
      <tr>
        <td align="center"><div style="margin-bottom:5px; font-weight:bold;">Ingrese el número de folio del CFDI de egresos:</div></td>
      </tr>
      <tr>
        <td align="center">
       
          <input name="foliocfdi" type="text" id="foliocfdi" style="text-align:center; font-size:18px;" size="37" maxlength="37"/>
 
        
        </td>
      </tr>
      <tr>
        <td align="center"><div style="margin-bottom:5px; margin-top:5px; font-weight:bold;">Ingrese el RFC del emisor autorizado:</div></td>
      </tr>
      <tr>
        <td align="center">
    <input name="rfcautorizado" type="text" id="rfcautorizado" style="text-align:center; font-size:18px;" size="12" maxlength="12"/>
        </td>
      </tr>
      <tr>
        <td align="center">&nbsp;</td>
      </tr>
      <tr>
        <td align="center">
        <input type="button" name="continuamon" id="continuamon" value="Continuar" class="boton" />
        <input type="button" name="cancelamon" id="cancelamon" value="Cancelar" class="boton" />
        <input type="hidden" name="tipofact" id="tipofact" value="monedero"  />
        </td>
      </tr>
    </table>
     </div>
    
    </td>
  </tr>
  <tr>
  <td colspan="3">
  
<div id="botones" style="display:block">  
  <table width="836" border="0" align="center" cellpadding="0" cellspacing="0">
    <tr>
      <td width="177" align="center"><div class="banner">
  <a href="#" class="tipofactura" name="monedero">
  <img src="images/monedero.png" alt="" width="150" height="146" border="0"  /> 
  </a>
  </div></td>
      <td width="248" align="center"> <div id="sintiket" class="banner"> <a href="#" id="sin">
    <!-- <img src="images/sinticket.png" alt="" name="sinticket" width="210" height="206" border="0" class="tipofactura" />-->
    <img src="images/sinticket.png" alt="" width="150" height="146" border="0"  /> </a> </div>
     <div id="ingresenip" style="display:none; width:268px;">
    <p><strong>Ingrese Nip de Autorización</strong></p>
  <input type="hidden" name="idestacion" id="idestacion" value="<?=$_SESSION['id_estacion']?>"  />  
  <input name="nipiestacion" type="password" id="nipestacion" size="6" maxlength="5" style="text-align:center; font-size:18px;" />
  <br /><br />
  <input type="button" name="envianip" id="envianip" value="Validar Nip" class="boton" />
  <input type="button" name="cancelasin" id="cancelasin" value="Cancelar" class="boton" />
</div></td>
      <td width="221" align="center">
      <div id="anticipos" class="banner"> <a href="#" id="anti">
    <!-- <img src="images/sinticket.png" alt="" name="sinticket" width="210" height="206" border="0" class="tipofactura" />-->
    <img src="images/anticipos.png" alt="" width="150" height="146" border="0"  /> </a> </div>
     <div id="ingresenip2" style="display:none; width:268px;">
    <p><strong>Ingrese Nip de Autorización</strong></p>
  <input type="hidden" name="idestacion" id="idestacion" value="<?=$_SESSION['id_estacion']?>"  />  
  <input name="nipiestacion2" type="password" id="nipestacion2" size="6" maxlength="5" style="text-align:center; font-size:18px;" />
  <br /><br />
  <input type="button" name="envianip2" id="envianip2" value="Validar Nip" class="boton" />
  <input type="button" name="cancelaanti" id="cancelaanti" value="Cancelar" class="boton" />
</div>
      </td>
      <td width="190" align="center">
      <div class="banner">
  <a href="#" class="tipofactura" name="conticket">
  <img src="images/conticket.png" width="150" height="146" border="0"  />
  </a>
  </div>
      </td>
    </tr>
  </table>
  </div>  
  
  </td>
  </tr>


 <tr>
 <td width="224" align="center" style="vertical-align:top;">

  
    
  </td>
  <td width="275" align="center" style="vertical-align:top;">
    
    </td>
 
  <td width="378" align="center">
  
  </td>
  </tr>

  
  
  <tr>
  <td colspan="3">&nbsp;</td>
  </tr>
  </table>

  <? }?> 
   
     
     
    <div id="descarga" style="display:none;" align="center"></div>
    
    <?  }else{ ?>
       
     <div id="direcciones">
         
          <div id="agregadir" style="display:block;"> 
          <table width="850" border="0" align="center" class="table">
            <tr>
              <td colspan="2" height="7"></td>
            </tr>
            <tr>
              <td width="182"> [ <strong><a href="#" id="agregardireccion" class="enlace2">Agregar Dirección</a></strong> ] </td>
              <td width="744" ><div style="color:#D41A10; font-weight:bold; " ></div></td>
            </tr>
             <tr>
              <td colspan="2" height="7"></td>
            </tr>
          </table>
       </div>
          
       <div id="agregardir" style="display:none">
            <table width="925" border="0" class="table">
              <tr>
                <td colspan="4" height="7"></td>
              </tr>
              <tr>
                <td width="374"><span style="margin-left:4px;">Calle:</span></td>
                <td width="204"> Exterior:</td>
                <td width="197"> Interior:</td>
                <td width="132">cp:</td>
              </tr>
              <tr>
                <td><input name="calle" class="rfc1" type="text" id="calle" size="40" style="text-align:center" /></td>
                <td><input name="exterior" type="text" class="rfc1" id="exterior"  size="10" style="text-align:center"  /></td>
                <td><input name="interior" type="text" class="rfc1" id="interior"  size="10"  style="text-align:center" /></td>
                <td><input name="cp" type="text" class="rfc1" id="cp"  size="10" style="text-align:center" /></td>
              </tr>
            </table>
            <table width="925" border="0" class="table">
              <tr>
                <td colspan="2">Colonia:</td>
                <td colspan="2">Localidad:</td>
                <td>Municipio:</td>
              </tr>
              <tr>
                <td colspan="2"><input name="colonia" class="rfc1" type="text" id="colonia" size="40" style="text-align:center" /></td>
                <td colspan="2"><input name="localidad" class="rfc1" type="text" id="localidad" size="28" style="text-align:center" /></td>
                <td><input name="municipio" class="rfc1" type="text" id="municipio" size="35" style="text-align:center" /></td>
              </tr>
              <tr>
                <td>País:</td>
                <td>Estado:</td>
                <td align="center">&nbsp;</td>
                <td align="center">&nbsp;</td>
                <td align="center">&nbsp;</td>
              </tr>
              <tr>
                <td><select  name="pais" id="pais" class="rfc1" style="width:130px"  >
                  <option value="Mexico ">México</option>
                </select></td>
                <td><select name="id_estado" class="rfc1" id="id_estado" >
                  <option value="">Seleccione</option>
                  <?	
           $qEst=mysql_query("SELECT * FROM estado order by nombre ASC ");
           while ($dEst=mysql_fetch_assoc($qEst)){
                        ?>
                  <option value="<?=$dEst['id_estado']?>" >
                    <?=($dEst['nombre'])?>
                  </option>
                  <? }?>
                </select></td>
                <td align="center">&nbsp;</td>
                <td align="center">&nbsp;</td>
                <td align="center">&nbsp;</td>
              </tr>
            </table>
            <table width="925" border="0" align="center" class="table"> 
              <tr>
                <td width="945"><input type="submit" name="submit_insertdir" id="submit_insertdir" value="C o n t i n u a r "   class="boton" />
                  <input type="submit" name="submit_insercan" id="submit_insercan" value="C a n c e l a r "   class="boton" />
                  <input type="hidden" name="id_cliente" id="id_cliente" value="<?=$dDatos['id_cliente']?>" /></td>
              </tr>
            </table>
          </div>
          <table width="850" border="0" align="center" class="table">
            <tr>
              <td>
              
              <div id="direccion">
                <?
  
  	$id_cliente=$dDatos['id_cliente'];
    $sD=mysql_query("select d.*,e.nombre as estado from domicilio as d left outer join estado as e on e.id_estado=d.id_estado where id_cliente='$id_cliente' "); 
	
  ?>            
                
    <table align="center"  id="tabla2">

          <tr data-valor="0">
            <td width="215">Calle</td>
            <td width="80">Numero</td>
            <td width="159">Colonia</tdd>
            <td width="171">Municipio</td>
            <td width="125">Estado</td>
            <td width="72">Cp</td>    
          </tr>
   </table>
  <div style="height:180px; width:100%; overflow:auto; overflow-x: hidden; ">  
   <table align="center"  id="tabla">
         <? 
		 for ($i=0;$row=@mysql_fetch_assoc($sD);$i++){
		
		 ?>
          <tr  >
            <td width="215" align="center"><?=$row['calle']?></td>
            <td width="80" align="center"><?=$row['exterior']?></td>
            <td width="159" align="center"><?=$row['colonia']?></td>
            <td width="171" align="center"><?=$row['municipio']?></td>
            <td width="125" align="center"><?=$row['estado']?></td>
            <td width="72" align="center"><?=$row['cp']?></td>
          </tr>
          <? }?>
    
      </table>
 </div>
 </div> 
              </td>
            </tr>
          </table>
    </div>   		
        
        
         
	  <? } ?>
       
        

<? }else{?>
 
           <div id="second_step">
          
          <table width="850" border="0" align="center" class="table">
  <tr>
    <td colspan="7" height="7"></td>
  </tr>
  <tr>

    <td>RFC:</td>
   
    <td>Nombre:</td>
 
    <td width="315">correo:</td>
    <td width="131">Teléfono:</td>
  </tr>
  <tr>
  
    <td width="144"><input name="rfc" type="text" id="rfc" class="rfc1" value="<?=$rfc?>" size="18" readonly="readonly" style="text-align:center"  /></td>

    <td width="317"><input name="nombre" class="rfc1" type="text" id="nombre" size="35" style="text-align:center" /></td>
  
    <td><input name="correo" type="text" class="rfc1" id="correo" size="35" style="text-align:center" /></td>
    <td><input name="telefono" class="rfc1" type="text" id="telefono" size="15" style="text-align:center" /></td>
  </tr>
</table>
          <table width="850" border="0" align="center" class="table">
            <tr>
              <td width="339"><span style="margin-left:4px;">Calle:</span></td>
              <td width="115"> Exterior:</td>
              <td width="128"> Interior:</td>
              <td width="325">cp:</td>
            </tr>
            <tr>
              <td><input name="calle" class="rfc1" type="text" id="calle" size="40" style="text-align:center" /></td>
              <td><input name="exterior" type="text" class="rfc1" id="exterior"  size="10" style="text-align:center"  /></td>
              <td><input name="interior" type="text" class="rfc1" id="interior"  size="10"  style="text-align:center" /></td>
              <td><input name="cp" type="text" class="rfc1" id="cp"  size="10" style="text-align:center" /></td>
            </tr>
          </table>
          <table width="925" border="0" align="center" class="table">
            <tr>
              <td colspan="2">Colonia:</td>
              <td colspan="2">Localidad:</td>
              <td width="318">Municipio:</td>
            </tr>
            <tr>
              <td colspan="2"><input name="colonia" class="rfc1" type="text" id="colonia" size="40" style="text-align:center" /></td>
              <td colspan="2"><input name="localidad" class="rfc1" type="text" id="localidad" size="28" style="text-align:center" /></td>
              <td><input name="municipio" class="rfc1" type="text" id="municipio" size="35" style="text-align:center" /></td>
            </tr>
            <tr>
              <td width="148">País:</td>
              <td width="188">Estado:</td>
              <td width="132" align="center">&nbsp;</td>
              <td width="117" align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
            </tr>
            <tr>
              <td><select  name="pais" id="pais" class="rfc1" style="width:130px"  >
                <option value="Mexico ">México</option>
              </select></td>
              <td><select name="id_estado" class="rfc1" id="id_estado" >
                <option value="">Seleccione</option>
                <?	
           $qEst=mysql_query("SELECT * FROM estado order by nombre ASC ");
           while ($dEst=mysql_fetch_assoc($qEst)){
                        ?>
                <option value="<?=$dEst['id_estado']?>" >
                  <?=($dEst['nombre'])?>
                </option>
                <? }?>
              </select></td>
              <td align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
              <td align="center">&nbsp;</td>
            </tr>
          </table>
          <table width="925" border="0" align="center" class="table">
            <tr>
              <td width="919"><input type="submit" name="crearfc" id="crearfc" value="C o n t i n u a r "   class="boton" />
              <input type="submit" name="cancelarRFC" id="cancelarRFC" value="Cancelar"  class="boton" />
              <input type="hidden" name="id_cliente" id="id_cliente" value="<?=$dDatos['id_cliente']?>" /></td>
            </tr>
          </table>
          
    </div>
          
         
  <? }?>  
  
<? }?>

 <div id="estacion" style="display:none">
 <table width="925" border="0" align="center" class="table2" >
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td align="center"><img src="images/seleccion.png" alt="" width="30" height="23" /></td>
    <td>Dirección:</td>
    <td><div id="dirseleccionada"></div></td>
  </tr>
  <tr>
    <td align="center">&nbsp;</td>
    <td>Estación:</td>
    <td><select name="id_estacion" class="second" id="id_estacion" >
      <option value="">Seleccione</option>
      <?	
           $qEsta=mysql_query("SELECT * FROM estaciones order by nombre_estacion ASC ");
           while ($dEsta=mysql_fetch_assoc($qEsta)){
                        ?>
      <option value="<?=$dEsta['id']?>" >
        <?=($dEsta['nombre_estacion'])?>
        </option>
      <? }?>
    </select></td>
  </tr>
  <tr>
    <td width="38" align="center">&nbsp;</td>
    <td width="130">Forma de Pago:</td>
    <td width="743"><select name="id_formpago" class="second" id="id_formpago" >
     <option value="0">N/A</option>
      <?	
           $qF=mysql_query("SELECT * FROM instrumento_monetario  limit 3 ");
           while ($dF=mysql_fetch_assoc($qF)){
                        ?>
      <option value="<?=$dF['clave']?>" >
        <?=($dF['descripcion'])?>
        </option>
      <? }?>
    </select></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
  <tr>
    <td colspan="3">
      <input type="hidden" name="rfc" id="rfc" value="<?=$dDatos['rfc']?>" />
      <input type="hidden" name="domicilio" id="domicilio" />
      <input type="submit" name="anterior" id="anterior" value="A n t e r i o r"   class="boton" />
      <input type="submit" name="submit_estacion" id="submit_estacion" value="S i g u i e n t e"   class="boton" /></td>
  </tr>
  <tr>
    <td colspan="3">&nbsp;</td>
  </tr>
 </table>
  </div>


  
</div>
</div>
<p>&nbsp;</p>
<p>&nbsp;</p>
<script src="js3/auto.js"></script>
</body>
</html>