$(function(){
    //original field values
    var field_values = {
            //id        :  value
            'rfc'  : 'rfc',
			'nombre'  : 'nombre'
    };


    //inputfocus
    $('input#rfc').inputfocus({ value: field_values['Ingrese su RFC'] });
	 $('input#nombre').inputfocus({ value: field_values['Ingrese su Nombre'] });


    //first_step

    $('#submit_first').click(function(){
        //remove classes
        $('#first_step input').removeClass('error').removeClass('valid');

        //ckeck if inputs aren't empty
        var fields = $('#first_step input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<4 || value==field_values[$(this).attr('id')] ) {
                $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
            } else {
                $(this).addClass('valid');
            }
        });        
        
        if(!error) {
          
            var rfc=$("#rfc").val();
			strCorrecta = rfc;
			
	        if (rfc.length == 12){
	        var valid = '^(([A-Z]|[a-z]){3})([0-9]{6})((([A-Z]|[a-z]|[0-9]){3}))';
 	        }else{
	        var valid = '^(([A-Z]|[a-z]|\s){1})(([A-Z]|[a-z]){3})([0-9]{6})((([A-Z]|[a-z]|[0-9]){3}))';
	        }
	        var validRfc=new RegExp(valid);
	        var matchArray=strCorrecta.match(validRfc);
	        if (matchArray==null) {
            alert ("Ingrese un RFC Valido");
			$(this).addClass('error');
	        document.getElementById("rfc").value="";
			$('#rfc').focus();
	        return false;
	        }
	        else
	        {
        
           // alert (rfc)
			   function restults(dataf) {
				window.location.reload()	
			    $.unblockUI(); 	  
			   }
			
			
			$.ajax({
            data: "rfc="+rfc,
            type: "POST",
            dataType: "json",
            url: "enviarfc.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(dataf){
            restults(dataf);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
			
		}

                          
        } else return false;
    });

    $('#submit_crearfc').click(function(){
        //remove classes
        $('#first_step input').removeClass('error').removeClass('valid');
		$('#first_step select').removeClass('error').removeClass('valid');
      
	

        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#second_step input[type=text],select');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')] || ( $(this).attr('id')=='correo' && !emailPattern.test(value) ) ) {
               if ($(this).attr('id')!='interior'){
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			   }
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {
  
 	         var id_cliente=$("#id_cliente").val();
			 var rfc=$("#rfc").val();
			 var nombre=$("#nombre").val();
			 var correo=$("#correo").val();
			 var telefono=$("#telefono").val();
			 var calle=$("#calle").val();
			 var exterior=$("#exterior").val();
			 var interior=$("#interior").val();
			 var cp=$("#cp").val();
			 var colonia=$("#colonia").val();
			 var localidad=$("#localidad").val();
			 var municipio=$("#municipio").val();
			 var pais=$("#pais").val();
			 var id_estado=$("#id_estado").val();
			 
			  function restults(datar) {
				window.location.reload()	
			    $.unblockUI(); 	  
			   }
 
            $.ajax({
            data: "id_cliente="+id_cliente+"&rfc="+rfc+"&nombre="+nombre+"&correo="+correo+"&telefono="+telefono+"&calle="+calle+"&exterior="+exterior+"&interior="+interior+"&cp="+cp+"&colonia="+colonia+"&localidad="+localidad+"&municipio="+municipio+"&pais="+pais+"&id_estado="+id_estado,
            type: "POST",
            dataType: "json",
            url: "procesarfc.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
        } else return false;

    });
	
	 $('#agregardireccion').click(function(){
		$('#direccion').slideUp();
		$('#agregardir').slideDown();   
		document.getElementById('agregadir').style.display="none"; 
	    });
		
	$('#submit_insercan').click(function(){
			 $("#calle").val('');
			 $("#exterior").val('');
			 $("#interior").val('');
			 $("#cp").val('');
			 $("#colonia").val('');
			 $("#localidad").val('');
			 $("#municipio").val('');
			 document.getElementById('id_estado').options.selectedIndex = 0;
	    $('#first_step input').removeClass('error').removeClass('valid');
		$('#first_step select').removeClass('error').removeClass('valid');
		$('#direccion').slideDown();
		$('#agregardir').slideUp();  
		document.getElementById('agregadir').style.display="block";  
	    });	
	


  $('#submit_insertdir').click(function(){
        //remove classes
        $('#agregardir input').removeClass('error').removeClass('valid');
		$('#agregardir select').removeClass('error').removeClass('valid');
      
	    var fields = $('#agregardir input[class=rfc1],select.rfc1');
        var error = 0;
       
	    fields.each(function(){
            var value = $(this).val();
      
		    if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
             if ($(this).attr('id')!='interior'){
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			   }
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var id_cliente=$("#id_cliente").val();
			 var calle=$("#calle").val();
			 var exterior=$("#exterior").val();
			 var interior=$("#interior").val();
			 var cp=$("#cp").val();
			 var colonia=$("#colonia").val();
			 var localidad=$("#localidad").val();
			 var municipio=$("#municipio").val();
			 var pais=$("#pais").val();
			 var id_estado=$("#id_estado").val();
			
			  function restults(datar) {
				window.location.reload()	
			    $.unblockUI(); 	  
			   }
 
            $.ajax({
            data: "id_cliente="+id_cliente+"&calle="+calle+"&exterior="+exterior+"&interior="+interior+"&cp="+cp+"&colonia="+colonia+"&localidad="+localidad+"&municipio="+municipio+"&pais="+pais+"&id_estado="+id_estado,
            type: "POST",
            dataType: "json",
            url: "insertdir.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
        } else return false;

    });




	$('#tabla tbody  tr').click(function (e) {
    // e.preventDefault();
    var id_domicilio = $(this).attr("data-valor");
	var calle= $(this).attr("data-valor2");   
    var id_estacion=$(this).attr("data-valor3"); 
	 var rfc=$(this).attr("data-valor4"); 
    var procesa = confirm("Direccion seleccionada "+calle+ " Realmente deseas Continuar?");
   
  // alert (rfc)
        if (procesa){
   
    if (id_domicilio!=0){
		
	         var rfc=rfc;
		 	 var domicilio=id_domicilio;
			 var id_estacion=id_estacion;
					 
			  function restults(datar) {
				//$('#direcciones').slideUp();
				window.location.reload()	
			    $.unblockUI(); 	  
			   
			   }
 
            $.ajax({
            data: "rfc="+rfc+"&domicilio="+domicilio+"&id_estacion="+id_estacion,
            type: "POST",
            dataType: "json",
            url: "enviaest.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
	  }
	  
		}
	  
	});


	$('#anterior').click(function(){

		document.getElementById('id_estacion').options.selectedIndex = 0;
		document.getElementById('id_formpago').options.selectedIndex = 0;
		$('#estacion select').removeClass('error').removeClass('valid');
		$('#estacion').slideUp();
		$('#direcciones').slideDown();  
		$('#progress_text').html('20% Complete');
        $('#progress').css('width','90px'); 
	
	});	
	

  $('#submit_estacion').click(function(){
        //remove classes

		$('#estacion select').removeClass('error').removeClass('valid');

        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#estacion select');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')] ) {
                $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {
 	    
			 var rfc=$("#rfc").val();
			 var domicilio=$("#domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var id_formpago=$("#id_formpago").val();
						 
			  function restults(datar) {
				window.location.reload()	
			    $.unblockUI(); 	  
			   
			   }
 
            $.ajax({
            data: "rfc="+rfc+"&domicilio="+domicilio+"&id_estacion="+id_estacion+"&id_formpago="+id_formpago,
            type: "POST",
            dataType: "json",
            url: "enviaest.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
        } else return false;

    });


  $('#submit_agregarT').click(function(){
        //remove classes
        $('#tickets input').removeClass('error').removeClass('valid');
		$('#tickets select').removeClass('error').removeClass('valid');

        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#tickets input[type=text],select.rfc1');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            // alert($(this).attr('id'))
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var ticket=$("#ticket").val();
			 var fecha=$("#datepicker").val();
			 var producto=$("#producto").val();
			 var bomba=$("#bomba").val();
			 var numfactura=$("#numfactura").val();
		
			    function restults(datar) {
			 
				 if (datar.mensaje=='1'){
			     $.unblockUI();          
				 window.location.reload();	 
				 }else{
				 $.unblockUI(); 
				 alert (datar.mensaje);
				 document.getElementById('ticket').value=''
				 }
				
				 if(datar.valido==1){
				 $.unblockUI(); 
				 window.location.reload();	 
				 }

				}			 
	 
            $.ajax({
            data: "ticket="+ticket+"&fecha="+fecha+"&producto="+producto+"&bomba="+bomba+"&numfactura="+numfactura,
            type: "POST",
            dataType: "json",
            url: "bticket.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
        } else return false;

    });


  $('#cancelarF').click(function(){

   var cancela = confirm("Realmente deseas Cancelar?")
	if (cancela){
		window.location.assign("cancelar.php");
	}
 });


  $('#cancelarRFC').click(function(){

   var cancela = confirm("Realmente deseas Cancelar?")
	if (cancela){
		window.location.assign("cancelarfc.php");
	}
 });



  $('#submit_procesar').click(function(){
        //remove classes
       $('#facturas input').removeClass('error').removeClass('valid');
		$('#facturas select').removeClass('error').removeClass('valid');
        
		  var fields = $('#facturas select.second,input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
           // alert($(this).attr('id'))
			    
				if(($(this).attr('id'))!='ticket' && ($(this).attr('id'))!='datepicker'){
				$(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
				}
            } else {
                $(this).addClass('valid');
            }
        });

         if(!error) {


	         var rfc=$("#rfc").val();
			 var id_domicilio=$("#id_domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var pemex=$("#pemex").val();
			 var id_formpago=$("#id_formpago").val();
			 var serie=$("#serie").val();
			 var numfactura=$("#numfactura").val();
			 var nticket=$("#nticket").val();
			 var id_despachador=$("#id_despachador").val();
			 var numcuenta=$("#numcuenta").val();
		
			 		
			 if (nticket==0){
				alert ("Inrgese un Ticket para Procesar la Factura"); 
			 }else{
			 
			 var procesa = confirm("Realmente deseas Procesar la Factura?");

	         if (procesa){
			    
				 function restults(dataf) {
			 
			     if (dataf.facturado!=0){
   
				 $.unblockUI(); 

			 	 $('#facturas').slideUp();
		         $('#descarga').slideDown();  
				 $('#progress_text').html('100% Complete');
                 $('#progress').css('width','339px');
				 $("#descarga").load("descarga.php",{f:dataf.facturado}, function(response, status, xhr) {
                     if (status == "error") {
                     var msg = "Error!, algo ha sucedido: ";
                     $("#descarga").html(msg + xhr.status + " " + xhr.statusText);
                     }	
					 
			     });
				
				
				 }else{
                 alert("No Se pudo Procesar la Factura, Favor de revisar los datos del cliente\n\n!Que no contenga espacios vacios entre los datos del cliente!")	 
                 $.unblockUI();  
                 window.location.reload();
                 }

			}			 
            

			
            $.ajax({
            data: "rfc="+rfc+"&id_domicilio="+id_domicilio+"&id_estacion="+id_estacion+"&pemex="+pemex+"&id_formpago="+id_formpago+"&numfactura="+numfactura+"&serie="+serie+"&id_despachador="+id_despachador+"&numcuenta="+numcuenta,
            type: "POST",
            dataType: "json",
            url: "procesardespachador.php",
	        beforeSend: function(){
     
			 $.blockUI({ message: $('#loading') });  
            },
	         success: function(dataf){
            restults(dataf);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
         }
  
      }
	  
	     } else return false;

    });




  $('#submit_procesar2').click(function(){
        //remove classes
        $('#facturas input').removeClass('error').removeClass('valid');
		$('#facturas select').removeClass('error').removeClass('valid');
        
		  var fields = $('#facturas select.second,input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
           //  alert($(this).attr('id'))
			  if(($(this).attr('id'))!='ticket' && ($(this).attr('id'))!='datepicker' && ($(this).attr('id'))!='cliente1'){
				$(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
				}
            } else {
                $(this).addClass('valid');
            }
        });

         if(!error) {


	         var rfc=$("#rfc").val();
			 var id_domicilio=$("#id_domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var pemex=$("#pemex").val();
			 var id_formpago=$("#id_formpago").val();
			 var serie=$("#serie").val();
			 var numfactura=$("#numfactura").val();
			 var nticket=$("#nticket").val();
			 var numcuenta=$("#numcuenta").val();
					 
			 		 
			 if (nticket==0){
				alert ("Inrgese un Ticket para Procesar la Factura"); 
			 }else{
			 
			 var procesa = confirm("Realmente deseas Procesar la Factura?");

	         if (procesa){
			    
				 function restults(dataf) {
			 
			     if (dataf.facturado!=0){
   
				 $.unblockUI(); 

			 	 $('#facturas').slideUp();
		         $('#descarga').slideDown();  
				 $('#progress_text').html('100% Complete');
                 $('#progress').css('width','339px');
				 $("#descarga").load("descarga.php",{f:dataf.facturado}, function(response, status, xhr) {
                     if (status == "error") {
                     var msg = "Error!, algo ha sucedido: ";
                     $("#descarga").html(msg + xhr.status + " " + xhr.statusText);
                     }	
					 
			     });
				
				
				 }else{
                 alert("No Se pudo Procesar la Factura, Favor de revisar los datos del cliente\n\n!Que no contenga espacios vacios entre los datos del cliente!")
                 $.unblockUI();  
                 window.location.reload();
                 }

			}			 
       
            $.ajax({
            data: "rfc="+rfc+"&id_domicilio="+id_domicilio+"&id_estacion="+id_estacion+"&pemex="+pemex+"&id_formpago="+id_formpago+"&numfactura="+numfactura+"&serie="+serie+"&numcuenta="+numcuenta,
            type: "POST",
            dataType: "json",
            url: "procesarfacturista.php",
	        beforeSend: function(){
     
			 $.blockUI({ message: $('#loading') });  
            },
	         success: function(dataf){
            restults(dataf);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
         }
  
      }
	  
	     } else return false;

    });






 $('#enviaemail').click(function(){
	
		//alert ("hola")
		$('#descargaarchivo').slideUp();
		$('#enviarmail').slideDown();  
		document.getElementById('agrega').style.display='block';
		 $('#enviarfactura').click(function(){
      		
 	     $('#enviarmail input').removeClass('error').removeClass('valid');
       
	    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#enviarmail input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if(($(this).attr('id')=='correo' && !emailPattern.test(value)) || ($(this).attr('id')=='cc' && !emailPattern.test(value))  ) {
                
				$(this).addClass('error');
              //  $(this).effect("shake", { times:3 }, 50);
                error++;
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {
		 var correo=$("#correo").val();
		 var numfactura=$("#numfactura").val();
		 var cc=$("#cc").val();

	     //$.blockUI({ message: $('#loading') });  
		 // setTimeout($.unblockUI, 2000);
		  function restults(dataf) {
			 // alert (dataf.enviado+"-"+dataf.numfactura)
			 if (dataf.enviado==0){		
			  alert ("Favor de Ingresar una direccion de correo valida");	 
			  $.unblockUI(); 	
			 }else{
			  alert ("la Factura [ "+dataf.numfactura+" ] ha sido envia correctamente");		 
			  $('#enviarmail').slideUp();
              $('#descargaarchivo').slideDown();   
			  $.unblockUI(); 	
			 }
		  }
		 
		  $.ajax({
            data: "correo="+correo+"&numfactura="+numfactura+"&cc="+cc,
            type: "POST",
            dataType: "json",
            url: "enviarcorreo.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	         success: function(dataf){
            restults(dataf);
            }
	        }).done(function() {
            //  $.unblockUI(); 
           });
 
		 
		 
		  
		} else return false;

     }); 
   
  });

   $('#cancelaemail').click(function(){
    $('#copia input,span').remove();	
   	$('#enviarmail').slideUp();
    $('#descargaarchivo').slideDown();   

  });



 $('#submit_nip').click(function(){
        //remove classes
        $('#inputnip input').removeClass('error').removeClass('valid');

      
	    var fields = $('#inputnip input[class=rfc],select.rfc');
        var error = 0;
       
	    fields.each(function(){
            var value = $(this).val();
      
		    if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var nip=$("#nip").val();
			 var id_estacion=$("#id_estacion").val();
				
			  function restults(datar) {
					
			    if(datar.valido==0){
				alert ("Nip Invalido");
				$.unblockUI(); 
				document.getElementById('nip').value='';
				}else{
				$.unblockUI(); 
				window.location.reload()	
				}
			    	  
			   }
 
            $.ajax({
            data: "nip="+nip+"&id_estacion="+id_estacion,
            type: "POST",
            dataType: "json",
            url: "buscardespachador.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
        } else return false;

    });





 $('#submit_buscarcliente').click(function(){
        //remove classes
        $('#inputcliente input').removeClass('error').removeClass('valid');

      
	    var fields = $('#inputcliente input[id=cliente]');
        var error = 0;
       
	    fields.each(function(){
            var value = $(this).val();
      
		    if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var cliente=$("#cliente").val();
						
			  function restults(datar) {
				//alert (datar.valido)
				if(datar.valido!=0){
				
				$.unblockUI(); 	
				window.location.reload();		
								
				}else{
				
				
				 var rfc=cliente;
			     strCorrecta = rfc;
			
	             if (rfc.length == 12){
	             var valid = '^(([A-Z]|[a-z]){3})([0-9]{6})((([A-Z]|[a-z]|[0-9]){3}))';
 	             }else{
	             var valid = '^(([A-Z]|[a-z]|\s){1})(([A-Z]|[a-z]){3})([0-9]{6})((([A-Z]|[a-z]|[0-9]){3}))';
	             }
	             var validRfc=new RegExp(valid);
	             var matchArray=strCorrecta.match(validRfc);
	             
				 if (matchArray==null) {
                 alert ("Ingrese un RFC Valido");
			     $.unblockUI();
				 //$(this).addClass('error');
	             document.getElementById("cliente").value="";
			     $('#cliente').focus();
	             return false;
	             }else{
				   var cliente2=$("#cliente").val(); 
					   
					   function restult(data1) {
					    $.unblockUI(); 	
					    window.location.reload();
					   }				
				
				     $.ajax({
                     data: "rfc="+cliente2,
                     type: "POST",
                     dataType: "json",
                     url: "rfc.php",
	                 beforeSend: function(){
			         $.blockUI({ message: $('#loading') });  
                     },
	                 success: function(data1){
                     restult(data1);
                     }
	                 }).done(function() {
                     //  $.unblockUI(); 
                     });
				     //$.unblockUI(); 	
				     //alert("No Existe el Cliente Favor de ingresar un RFC valido")	
				     //document.getElementById('cliente').value='';
				
			    	 }
				
				}
			   
			   }
 
            $.ajax({
            data: "cliente="+cliente,
            type: "POST",
            dataType: "json",
            url: "buscarcliente.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
            //  $.unblockUI(); 
           });
 
        } else return false;

    });


///////////////otro para agregar clientes


    $('#crearfc').click(function(){
        //remove classes
        $('#second_step input').removeClass('error').removeClass('valid');
		$('#second_step select').removeClass('error').removeClass('valid');
      
	 

        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#second_step input[class=rfc1],select.rfc1');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')] || ( $(this).attr('id')=='correo' && !emailPattern.test(value) ) ) {
            
			   if ($(this).attr('id')!='interior'){
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			   }
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var id_cliente=$("#id_cliente").val();
			 var rfc=$("#rfc").val();
			 var nombre=$("#nombre").val();
			 var correo=$("#correo").val();
			 var telefono=$("#telefono").val();
			 var calle=$("#calle").val();
			 var exterior=$("#exterior").val();
			 var interior=$("#interior").val();
			 var cp=$("#cp").val();
			 var colonia=$("#colonia").val();
			 var localidad=$("#localidad").val();
			 var municipio=$("#municipio").val();
			 var pais=$("#pais").val();
			 var id_estado=$("#id_estado").val();
			 
			  function restults(datar) {
				window.location.reload()	
			    $.unblockUI(); 	  
			   }
 
            $.ajax({
            data: "id_cliente="+id_cliente+"&rfc="+rfc+"&nombre="+nombre+"&correo="+correo+"&telefono="+telefono+"&calle="+calle+"&exterior="+exterior+"&interior="+interior+"&cp="+cp+"&colonia="+colonia+"&localidad="+localidad+"&municipio="+municipio+"&pais="+pais+"&id_estado="+id_estado,
            type: "POST",
            dataType: "json",
            url: "procesarfc.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
        } else return false;

    });



///////////hasta aqui


//////////// para buscar facturas 



   $('#buscar').click(function(){
   	$('#rfc_cliente').slideUp();
    $('#buscarfacturas').slideDown();   
   });
   
   $('#cancelaBusqueda').click(function(){
   	$('#buscarfacturas').slideUp();
    $('#rfc_cliente').slideDown();   
   });


});