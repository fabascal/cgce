$(function(){
    //original field values
    var field_values = {
            //id        :  value
            'rfc'  : 'rfc',
			'nombre'  : 'nombre'
    };


    //inputfocus
    $('input#rfc').inputfocus({ value: field_values['Ingrese su RFC'] });
	 $('input#nombre').inputfocus({ value: field_values['Ingrese su Nombre'] });


    //first_step

    $('#submit_first').click(function(){
        //remove classes
        $('#first_step input').removeClass('error').removeClass('valid');

        //ckeck if inputs aren't empty
        var fields = $('#first_step input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<4 || value==field_values[$(this).attr('id')] ) {
                $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
            } else {
                $(this).addClass('valid');
            }
        });        
        
        if(!error) {
          
            var rfc=$("#rfc").val();
			strCorrecta = rfc;
			
	        if (rfc.length == 12){
	           var valid = '^(([A-Z-&]|[a-z-&]){3})([0-9-&]{6})((([A-Z-&]|[a-z-&]|[0-9-&]){3}))';
 	           }else{
	           var valid = '^(([A-Z-&]|[a-z-&]|\s){1})(([A-Z-&]|[a-z-&]){3})([0-9-&]{6})((([A-Z-&]|[a-z-&]|[0-9-&]){3}))';
	           }
	        var validRfc=new RegExp(valid);
	        var matchArray=strCorrecta.match(validRfc);
	        if (matchArray==null) {
            alert ("Ingrese un RFC Valido");
			$(this).addClass('error');
	        document.getElementById("rfc").value="";
			$('#rfc').focus();
	        return false;
	        }
	        else
	        {
        
           // alert (rfc)
			   function restults(dataf) {
				window.location.reload()	
			    $.unblockUI(); 	  
			   }
			
			
			$.ajax({
            data: "rfc="+encodeURIComponent(rfc),
            type: "POST",
            dataType: "json",
            url: "enviarfc.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(dataf){
            restults(dataf);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
			
		}

                          
        } else return false;
    });

    $('#submit_crearfc').click(function(){
        //remove classes
        $('#first_step input').removeClass('error').removeClass('valid');
		$('#first_step select').removeClass('error').removeClass('valid');
      
	

        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#second_step input[type=text],select');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')] || ( $(this).attr('id')=='correo' && !emailPattern.test(value) ) ) {
               if ($(this).attr('id')!='interior'){
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			   }
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {
  
 	         var id_cliente=$("#id_cliente").val();
			 var rfc=$("#rfc").val();
			 var nombre=$("#nombre").val();
			 var correo=$("#correo").val();
			 var telefono=$("#telefono").val();
			 var calle=$("#calle").val();
			 var exterior=$("#exterior").val();
			 var interior=$("#interior").val();
			 var cp=$("#cp").val();
			 var colonia=$("#colonia").val();
			 var localidad=$("#localidad").val();
			 var municipio=$("#municipio").val();
			 var pais=$("#pais").val();
			 var id_estado=$("#id_estado").val();
			 
			  function restults(datar) {
				window.location.reload()	
			    $.unblockUI(); 	  
			   }
 
            $.ajax({
            data: "id_cliente="+id_cliente+"&rfc="+encodeURIComponent(rfc)+"&nombre="+encodeURIComponent(nombre)+"&correo="+correo+"&telefono="+telefono+"&calle="+calle+"&exterior="+exterior+"&interior="+interior+"&cp="+cp+"&colonia="+colonia+"&localidad="+localidad+"&municipio="+municipio+"&pais="+pais+"&id_estado="+id_estado,
            type: "POST",
            dataType: "json",
            url: "procesarfc.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
        } else return false;

    });
	
	 $('#agregardireccion').click(function(){
		$('#direccion').slideUp();
		$('#agregardir').slideDown();   
		document.getElementById('agregadir').style.display="none"; 
	    });
		
	$('#submit_insercan').click(function(){
			 $("#calle").val('');
			 $("#exterior").val('');
			 $("#interior").val('');
			 $("#cp").val('');
			 $("#colonia").val('');
			 $("#localidad").val('');
			 $("#municipio").val('');
			 document.getElementById('id_estado').options.selectedIndex = 0;
	    $('#first_step input').removeClass('error').removeClass('valid');
		$('#first_step select').removeClass('error').removeClass('valid');
		$('#direccion').slideDown();
		$('#agregardir').slideUp();  
		document.getElementById('agregadir').style.display="block";  
	    });	
	


  $('#submit_insertdir').click(function(){
        //remove classes
        $('#agregardir input').removeClass('error').removeClass('valid');
		$('#agregardir select').removeClass('error').removeClass('valid');
      
	    var fields = $('#agregardir input[class=rfc1],select.rfc1');
        var error = 0;
       
	    fields.each(function(){
            var value = $(this).val();
      
		    if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
             if ($(this).attr('id')!='interior'){
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			   }
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var id_cliente=$("#id_cliente").val();
			 var calle=$("#calle").val();
			 var exterior=$("#exterior").val();
			 var interior=$("#interior").val();
			 var cp=$("#cp").val();
			 var colonia=$("#colonia").val();
			 var localidad=$("#localidad").val();
			 var municipio=$("#municipio").val();
			 var pais=$("#pais").val();
			 var id_estado=$("#id_estado").val();
			
			  function restults(datar) {
				window.location.reload()	
			    $.unblockUI(); 	  
			   }
 
            $.ajax({
            data: "id_cliente="+id_cliente+"&calle="+calle+"&exterior="+exterior+"&interior="+interior+"&cp="+cp+"&colonia="+colonia+"&localidad="+localidad+"&municipio="+municipio+"&pais="+pais+"&id_estado="+id_estado,
            type: "POST",
            dataType: "json",
            url: "insertdir.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
        } else return false;

    });



/*
	$('#tabla tbody  tr').click(function (e) {
    // e.preventDefault();
    var id_domicilio = $(this).attr("data-valor");
	var calle= $(this).attr("data-valor2");   
    var id_estacion=$(this).attr("data-valor3"); 
	 var rfc=$(this).attr("data-valor4"); 
    var procesa = confirm("Direccion seleccionada "+calle+ " Realmente deseas Continuar?");
   
  // alert (rfc)
        if (procesa){
   
    if (id_domicilio!=0){
		
	         var rfc=rfc;
		 	 var domicilio=id_domicilio;
			 var id_estacion=id_estacion;
					 
			  function restults(datar) {
				//$('#direcciones').slideUp();
				window.location.reload()	
			    $.unblockUI(); 	  
			   
			   }
 
            $.ajax({
            data: "rfc="+encodeURIComponent(rfc)+"&domicilio="+domicilio+"&id_estacion="+id_estacion,
            type: "POST",
            dataType: "json",
            url: "enviaest.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
	  }
	  
		}
	  
	});

*/
	$('#anterior').click(function(){

		document.getElementById('id_estacion').options.selectedIndex = 0;
		document.getElementById('id_formpago').options.selectedIndex = 0;
		$('#estacion select').removeClass('error').removeClass('valid');
		$('#estacion').slideUp();
		$('#direcciones').slideDown();  
		$('#progress_text').html('20% Complete');
        $('#progress').css('width','90px'); 
	
	});	
	

  $('#submit_estacion').click(function(){
        //remove classes

		$('#estacion select').removeClass('error').removeClass('valid');

        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#estacion select');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')] ) {
                $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {
 	    
			 var rfc=$("#rfc").val();
			 var domicilio=$("#domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var id_formpago=$("#id_formpago").val();
						 
			  function restults(datar) {
				window.location.reload()	
			    $.unblockUI(); 	  
			   
			   }
 
            $.ajax({
            data: "rfc="+encodeURIComponent(rfc)+"&domicilio="+domicilio+"&id_estacion="+id_estacion+"&id_formpago="+id_formpago,
            type: "POST",
            dataType: "json",
            url: "enviaest.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
        } else return false;

    });


  $('#submit_agregarT').click(function(){
        //remove classes
        $('#tickets input').removeClass('error').removeClass('valid');
		$('#tickets select').removeClass('error').removeClass('valid');

        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#tickets input[type=text],select.rfc1');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
                if ($(this).attr('id')!='producto'){
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
				}
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var ticket=$("#ticket").val();
			 var fecha=$("#datepicker").val();
			 var producto=$("#producto").val();
			 var bomba=$("#bomba").val();
			 var numfactura=$("#numfactura").val();
		
			    function restults(datar) {
			 
				 if (datar.mensaje=='1'){
			     $.unblockUI();          
				 window.location.reload();	 
				 }else{
				 $.unblockUI(); 
				 alert (datar.mensaje);
				 document.getElementById('ticket').value=''
				 }
				
				 if(datar.valido==1){
				 $.unblockUI(); 
				 window.location.reload();	 
				 }

				}			 
	 
            $.ajax({
            data: "ticket="+ticket+"&fecha="+fecha+"&producto="+producto+"&bomba="+bomba+"&numfactura="+numfactura,
            type: "POST",
            dataType: "json",
            url: "bticket.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            },
    
    error: function (datar) {
       	        $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>Error de Conexion con el sistema CG.</p>', 
                timeout:   2000 
                });		  
    } 
	        }).done(function() {
              $.unblockUI(); 
           });
 
        } else return false;

    });


  $('#cancelarF').click(function(){

   var cancela = confirm("Realmente deseas Cancelar?")
	if (cancela){
		window.location.assign("cancelar.php");
	}
 });


  $('#cancelarRFC').click(function(){

   var cancela = confirm("Realmente deseas Cancelar?")
	if (cancela){
		window.location.assign("cancelarfc.php");
	}
 });
 
 



 $('#enviaemail').click(function(){
	
		//alert ("hola")
		$('#descargaarchivo').slideUp();
		$('#enviarmail').slideDown();  
		document.getElementById('agrega').style.display='block';
		 $('#enviarfactura').click(function(){
      		
 	     $('#enviarmail input').removeClass('error').removeClass('valid');
       
	    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#enviarmail input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if(($(this).attr('id')=='correo' && !emailPattern.test(value)) || ($(this).attr('id')=='cc' && !emailPattern.test(value))  ) {
                
				$(this).addClass('error');
              //  $(this).effect("shake", { times:3 }, 50);
                error++;
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {
		 var correo=$("#correo").val();
		 var numfactura=$("#numfactura").val();
		 var cc=$("#cc").val();

		  function restults(dataf) {
			 // alert (dataf.enviado+"-"+dataf.numfactura)
			 if (dataf.enviado==0){		
			  alert ("Favor de Ingresar una direccion de correo valida");	 
			  $.unblockUI(); 	
			 }else{
			  alert ("la Factura [ "+dataf.numfactura+" ] ha sido envia correctamente");		 
			  $('#enviarmail').slideUp();
              $('#descargaarchivo').slideDown();   
			  $.unblockUI(); 	
			 }
		  }
		 
		  $.ajax({
            data: "correo="+correo+"&numfactura="+numfactura+"&cc="+cc,
            type: "POST",
            dataType: "json",
            url: "enviarcorreo.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	         success: function(dataf){
            restults(dataf);
            }
	        })	 
		 
		  
		} else return false;

     }); 
   
  });

    $('#cancelaemail').click(function(){
    $('#copia input,span').remove();	
   	$('#enviarmail').slideUp();
    $('#descargaarchivo').slideDown();   

  });



 $('#submit_nip').click(function(){
        //remove classes
        $('#inputnip input').removeClass('error').removeClass('valid');

      
	    var fields = $('#inputnip input[class=rfc],select.rfc');
        var error = 0;
       
	    fields.each(function(){
            var value = $(this).val();
      
		    if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var nip=$("#nip").val();
			 var id_estacion=$("#id_estacion").val();
				
			  function restults(datar) {
					
			    if(datar.valido==0){
				alert ("Nip Invalido");
				$.unblockUI(); 
				document.getElementById('nip').value='';
				}else{
				$.unblockUI(); 
				window.location.reload()	
				}
			    	  
			   }
 
            $.ajax({
            data: "nip="+nip+"&id_estacion="+id_estacion,
            type: "POST",
            dataType: "json",
            url: "buscardespachador.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
        } else return false;

    });


/////////buscar clientes 1

 $('#submit_buscarcliente').click(function(){
        //remove classes
        $('#inputcliente input').removeClass('error').removeClass('valid');

      
	    var fields = $('#inputcliente input[id=cliente]');
        var error = 0;
       
	    fields.each(function(){
            var value = $(this).val();
      
		    if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var cliente=$("#cliente").val();
						
			  function restults(datar) {
				//alert (datar.valido)
				if(datar.valido!=0){
				
				$.unblockUI(); 	
				window.location.reload();		
								
				}else{
				
				
				 var rfc=cliente;
			     strCorrecta = rfc;
			
	           if (rfc.length == 12){
	           var valid = '^(([A-Z-&]|[a-z-&]){3})([0-9-&]{6})((([A-Z-&]|[a-z-&]|[0-9-&]){3}))';
 	           }else{
	           var valid = '^(([A-Z-&]|[a-z-&]|\s){1})(([A-Z-&]|[a-z-&]){3})([0-9-&]{6})((([A-Z-&]|[a-z-&]|[0-9-&]){3}))';
	           }
	             var validRfc=new RegExp(valid);
	             var matchArray=strCorrecta.match(validRfc);
	             
				 if (matchArray==null) {
                 alert ("Ingrese un RFC Valido");
			     $.unblockUI();
				 //$(this).addClass('error');
	             document.getElementById("cliente").value="";
			     $('#cliente').focus();
	             return false;
	             }else{
				   var cliente2=$("#cliente").val(); 
					   
					   function restult(data1) {
					    $.unblockUI(); 	
					    window.location.reload();
					   }				
				
				     $.ajax({
                     data: "rfc="+encodeURIComponent(cliente2),
                     type: "POST",
                     dataType: "json",
                     url: "rfc.php",
	                 beforeSend: function(){
			         $.blockUI({ message: $('#loading') });  
                     },
	                 success: function(data1){
                     restult(data1);
                     }
	                 }).done(function() {
                     //  $.unblockUI(); 
                     });
				     //$.unblockUI(); 	
				     //alert("No Existe el Cliente Favor de ingresar un RFC valido")	
				     //document.getElementById('cliente').value='';
				
			    	 }
				
				}
			   
			   }
 
            $.ajax({
            data: "cliente="+encodeURIComponent(cliente),
            type: "POST",
            dataType: "json",
            url: "buscarcliente.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
            //  $.unblockUI(); 
           });
 
        } else return false;

    });


/////////////parte para buscar las facturas del cliente en estacion//////////////


$('#submit_buscarcliente2').click(function(){
        //remove classes
        $('#inputcliente input').removeClass('error').removeClass('valid');
     
	    var fields = $('#inputcliente input[id=cliente]');
        var error = 0;
       
	    fields.each(function(){
            var value = $(this).val();
      
		    if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            
			   
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var cliente=$("#cliente").val();
    		
			function restults(datar) {
				
				if(datar.valido!=0){
				
				$.unblockUI(); 	
			
				$('#rfc_cliente').slideUp();
                document.getElementById('cliente').value='';	
				$('#cliente').focus();
                $("#success").load("facturaswfact.php",{f:datar.rfc}, function(response, status, xhr) {
		        if (status == "error") {
                var msg = "Sorry but there was an error: ";
                $("#success").html(msg + xhr.status + " " + xhr.statusText);
                } else if(status=='success') {
                $('#success').html(response);
                }
                else { 
				//alert(status)
				}
           });
		
			}else{
				
				$.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>No se encontraron facturas.</p>', 
                timeout:   2000 
                });
				document.getElementById('cliente').value='';	
				$('#cliente').focus();
				}
			}
			
			
			 $.ajax({
             data: "cliente="+encodeURIComponent(cliente),
             type: "POST",
             dataType: "json",
             url: "buscaclientefw.php",
	         beforeSend: function(){
             //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
             },
	         success: function(datar){
             restults(datar);
             }
	         })
        
		} else return false;

    });
	



//////////////PARA EL DESPACHADOR 

$('#submit_buscarcliente4').click(function(){
        //remove classes
        $('#inputcliente input').removeClass('error').removeClass('valid');
     
	    var fields = $('#inputcliente input[id=cliente]');
        var error = 0;
       
	    fields.each(function(){
            var value = $(this).val();
      
		    if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            
			   
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var cliente=$("#cliente").val();
    		
			function restults(datar) {
				
				if(datar.valido!=0){
				
				$.unblockUI(); 	
			
				$('#rfc_cliente').slideUp();
                document.getElementById('cliente').value='';	
				$('#cliente').focus();
                $("#success").load("facturaswfactd.php",{f:datar.rfc}, function(response, status, xhr) {
		        if (status == "error") {
                var msg = "Sorry but there was an error: ";
                $("#success").html(msg + xhr.status + " " + xhr.statusText);
                } else if(status=='success') {
                $('#success').html(response);
                }
                else { 
				//alert(status)
				}
           });
		
			}else{
				
				$.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>No se encontraron facturas.</p>', 
                timeout:   2000 
                });
				document.getElementById('cliente').value='';	
				$('#cliente').focus();
				}
			}
			
			
			 $.ajax({
             data: "cliente="+encodeURIComponent(cliente),
             type: "POST",
             dataType: "json",
             url: "buscaclientefw.php",
	         beforeSend: function(){
             //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
             },
	         success: function(datar){
             restults(datar);
             }
	         })
        
		} else return false;

    });
	


	
////////////////parte para buscar las facturas del cliente en portal//////////////


$('#submit_buscarcliente3').click(function(){
        //remove classes
        $('#inputcliente input').removeClass('error').removeClass('valid');
     
	    var fields = $('#inputcliente input[id=cliente]');
        var error = 0;
       
	    fields.each(function(){
            var value = $(this).val();
      
		    if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            
			   
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var cliente=$("#cliente").val();
    		
			function restults(datar) {
				
				if(datar.valido!=0){
				
				$.unblockUI(); 	
			
				$('#rfc_cliente').slideUp();
                document.getElementById('cliente').value='';	
				$('#cliente').focus();
                $("#success").load("facturaswportal.php",{f:datar.rfc}, function(response, status, xhr) {
		        if (status == "error") {
                var msg = "Sorry but there was an error: ";
                $("#success").html(msg + xhr.status + " " + xhr.statusText);
                } else if(status=='success') {
                $('#success').html(response);
                }
                else { 
				//alert(status)
				}
           });
		

		
		
						
				}else{
				
				$.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>No se encontraron facturas.</p>', 
                timeout:   2000 
                });
				document.getElementById('cliente').value='';	
				$('#cliente').focus();
				}
			}
			
			
			 $.ajax({
             data: "cliente="+encodeURIComponent(cliente),
             type: "POST",
             dataType: "json",
             url: "buscaclientefw.php",
	         beforeSend: function(){
             //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
             },
	         success: function(datar){
             restults(datar);
             }
	         })
        
		} else return false;

    });



//////////// PARA LAS DE PORTAL QUE BUSQUE EL DESPACHADOR 



$('#submit_buscarcliente5').click(function(){
        //remove classes
        $('#inputcliente input').removeClass('error').removeClass('valid');
     
	    var fields = $('#inputcliente input[id=cliente]');
        var error = 0;
       
	    fields.each(function(){
            var value = $(this).val();
      
		    if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            
			   
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var cliente=$("#cliente").val();
    		
			function restults(datar) {
				
				if(datar.valido!=0){
				
				$.unblockUI(); 	
			
				$('#rfc_cliente').slideUp();
                document.getElementById('cliente').value='';	
				$('#cliente').focus();
                $("#success").load("facturaswportald.php",{f:datar.rfc}, function(response, status, xhr) {
		        if (status == "error") {
                var msg = "Sorry but there was an error: ";
                $("#success").html(msg + xhr.status + " " + xhr.statusText);
                } else if(status=='success') {
                $('#success').html(response);
                }
                else { 
				//alert(status)
				}
           });
		

		
		
						
				}else{
				
				$.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>No se encontraron facturas.</p>', 
                timeout:   2000 
                });
				document.getElementById('cliente').value='';	
				$('#cliente').focus();
				}
			}
			
			
			 $.ajax({
             data: "cliente="+encodeURIComponent(cliente),
             type: "POST",
             dataType: "json",
             url: "buscaclientefw.php",
	         beforeSend: function(){
             //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
             },
	         success: function(datar){
             restults(datar);
             }
	         })
        
		} else return false;

    });




///////////////otro para agregar clientes


    $('#crearfc').click(function(){
        //remove classes
        $('#second_step input').removeClass('error').removeClass('valid');
		$('#second_step select').removeClass('error').removeClass('valid');
      
	 

        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#second_step input[class=rfc1],select.rfc1');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')] || ( $(this).attr('id')=='correo' && !emailPattern.test(value) ) ) {
            
			   if ($(this).attr('id')!='interior'){
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			   }
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var id_cliente=$("#id_cliente").val();
			 var rfc=$("#rfc").val();
			 var  nombre=$("#nombre").val();
			 var correo=$("#correo").val();
			 var telefono=$("#telefono").val();
			 var calle=$("#calle").val();
			 var exterior=$("#exterior").val();
			 var interior=$("#interior").val();
			 var cp=$("#cp").val();
			 var colonia=$("#colonia").val();
			 var localidad=$("#localidad").val();
			 var municipio=$("#municipio").val();
			 var pais=$("#pais").val();
			 var id_estado=$("#id_estado").val();
			 
			 
			 //alert($("#nombre").html());
			 
			  function restults(datar) {
				window.location.reload()	
			    $.unblockUI(); 	  
			   }
 
            $.ajax({
            data: "id_cliente="+id_cliente+"&rfc="+encodeURIComponent(rfc)+"&nombre="+encodeURIComponent(nombre)+"&correo="+correo+"&telefono="+telefono+"&calle="+calle+"&exterior="+exterior+"&interior="+interior+"&cp="+cp+"&colonia="+colonia+"&localidad="+localidad+"&municipio="+municipio+"&pais="+pais+"&id_estado="+id_estado,
            type: "POST",
            dataType: "json",
            url: "procesarfc.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
        } else return false;

    });



///////////hasta aqui


//////////// para buscar facturas 



   $('#buscar').click(function(){
   	$('#rfc_cliente').slideUp();
    $('#buscarfacturas').slideDown();   
   });
   
   $('#cancelaBusqueda').click(function(){
   	$('#buscarfacturas').slideUp();
    $('#rfc_cliente').slideDown();   
   });


  

	$('.cancelarFact').click(function(){
      var numfactura=this.name;
	  var pac=$("#pac").val();
	  
	  if(pac=='plataformas'){
	  var archivo='cancelaplataformas.php';	  
	  }else{
	  var archivo='cancelasmart.php';	  
	  }
	  
	  var procesa = confirm("Realmente Deseas CANCELAR LA FACTURA [ "+numfactura+" ]");
	   if (procesa){
		
		    function restults(datar) {
			//window.location.reload()	
			alert (datar.uuid)
			$.unblockUI(); 	  
			}
			
			$.ajax({
            data: "numfactura="+numfactura,
            type: "POST",
            dataType: "json",
            url: archivo,
	        beforeSend: function(){           
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        })
		  
	   }
	
	});
	
	
	
	
 $('#enviaemail').click(function(){
	
		//alert ("hola")
		$('#descargaarchivo').slideUp();
		
		$('#enviarmail').slideDown();  
		document.getElementById('agrega').style.display='block';
		
		
		 $('#enviarfacturaportal').click(function(){
      		
 	     $('#enviarmail input').removeClass('error').removeClass('valid');
       
	    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#enviarmail input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if(($(this).attr('id')=='correo' && !emailPattern.test(value)) || ($(this).attr('id')=='cc' && !emailPattern.test(value))  ) {
                
				$(this).addClass('error');
              //  $(this).effect("shake", { times:3 }, 50);
                error++;
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {
		 var correo=$("#correo").val();
		 var numfactura=$("#numfactura").val();
		 var cc=$("#cc").val();

		  function restults(dataf) {
			 // alert (dataf.enviado+"-"+dataf.numfactura)
			 if (dataf.enviado==0){		
			  alert ("Favor de Ingresar una direccion de correo valida");	 
			  $.unblockUI(); 	
			 }else{
			  alert ("la Factura [ "+dataf.numfactura+" ] ha sido envia correctamente");		 
			  $('#enviarmail').slideUp();
              $('#descargaarchivo').slideDown();   
			  $.unblockUI(); 	
			 }
		  }
		 
		  $.ajax({
            data: "correo="+correo+"&numfactura="+numfactura+"&cc="+cc,
            type: "POST",
            dataType: "json",
            url: "enviarcorreoportal.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	         success: function(dataf){
            restults(dataf);
            }
	        })	 
		 
		  
		} else return false;

     }); 
   
   
    $('#enviarfacturamonedero').click(function(){
  
	  		
 	     $('#enviarmail input').removeClass('error').removeClass('valid');
       
	    var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#enviarmail input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if(($(this).attr('id')=='correo' && !emailPattern.test(value)) || ($(this).attr('id')=='cc' && !emailPattern.test(value))  ) {
                
				$(this).addClass('error');
              //  $(this).effect("shake", { times:3 }, 50);
                error++;
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {
		 var correo=$("#correo").val();
		 var numfactura=$("#numfactura").val();
		 var cc=$("#cc").val();

		  function restults(dataf) {
			 // alert (dataf.enviado+"-"+dataf.numfactura)
			 if (dataf.enviado==0){		
			  alert ("Favor de Ingresar una direccion de correo valida");	 
			  $.unblockUI(); 	
			 }else{
			  alert ("la Factura [ "+dataf.numfactura+" ] ha sido envia correctamente");		 
			  $('#enviarmail').slideUp();
              $('#descargaarchivo').slideDown();   
			  $.unblockUI(); 	
			 }
		  }
		 
		  $.ajax({
            data: "correo="+correo+"&numfactura="+numfactura+"&cc="+cc,
            type: "POST",
            dataType: "json",
            url: "enviarcorreomonedero.php",
	        beforeSend: function(){
            //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
            },
	         success: function(dataf){
            restults(dataf);
            }
	        })	 
		 
		  
		} else return false;

     }); 
   
   
   
   
   
   
  });
	
	
	
	
	
//////////////para agregar servicios sin ticket////////////////

$('#submit_agregarS').click(function(){
        //remove classes
        $('#sinticket input').removeClass('error').removeClass('valid');
		$('#sinticket select').removeClass('error').removeClass('valid');

        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#sinticket input[type=text],select.rfc1');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
                //alert($(this).attr('id'))
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var producto=$("#producto").val();
			 var cantidad=$("#cantidad").val();			 
			 var tunidad=$('input:radio[name=tunidad]:checked').val();
			 var rfc=$("#rfc").val();
			 var numfactura=$("#numfactura").val();
			 var id_user=$("#id_user").val();
			 var id_estacion=$("#id_estacion").val();
			 
			    function restults(datar) {
			
				 if (datar.dato=='1'){
			     $.unblockUI();          
				 //alert(datar.dato1)
				 window.location.reload();	 
				 }else{
				 $.unblockUI(); 
				 alert ("favor de volver a agregar el servicio");
				 }
			
				}			 
	 
            $.ajax({
            data: "producto="+producto+"&cantidad="+cantidad+"&tunidad="+tunidad+"&rfc="+encodeURIComponent(rfc)+"&numfactura="+numfactura+"&id_user="+id_user+"&id_estacion="+id_estacion,
            type: "POST",
            dataType: "json",
            url: "addst.php",
	        beforeSend: function(){
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
		  
 
        } else return false;

    });


////////////////////// PARA AGREGAR ACEITE PARTE 2

$('#submit_agregarS2').click(function(){
        //remove classes
        $('#sinticket input').removeClass('error').removeClass('valid');
		$('#sinticket select').removeClass('error').removeClass('valid');

        var emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/;  
        var fields = $('#sinticket input[type=text],select.rfc1');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
                //alert($(this).attr('id'))
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var producto=$("#producto").val();
			 var cantidad=$("#cantidad").val();			 
			 var tunidad=$('input:radio[name=tunidad]:checked').val();
			 var rfc=$("#rfc").val();
			 var numfactura=$("#numfactura").val();
			 var id_user=$("#id_user").val();
			 var id_estacion=$("#id_estacion").val();
			 
			    function restults(datar) {
			
				 if (datar.dato=='1'){
			     $.unblockUI();          
				 //alert(datar.dato1)
				 window.location.reload();	 
				 }else{
				 $.unblockUI(); 
				 alert ("Favor de volver a agregar el servicio");
				 }
			
				}			 
	 
            $.ajax({
            data: "producto="+producto+"&cantidad="+cantidad+"&tunidad="+tunidad+"&rfc="+encodeURIComponent(rfc)+"&numfactura="+numfactura+"&id_user="+id_user+"&id_estacion="+id_estacion,
            type: "POST",
            dataType: "json",
            url: "addst2.php",
	        beforeSend: function(){
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
		  
 
        } else return false;

    });


////////////////////////



$('input[name=tunidad]').click(function(){

var tunidad= $('input:radio[name=tunidad]:checked').val();

if (tunidad==1){
$("#texunidad").text("Importe:");	
}else if(tunidad==2){
$("#texunidad").text("Cantidad:");	
}else{
$("#texunidad").text("Importe:");	
}


});


  $('#cancelarSin').click(function(){

   var cancela = confirm("Realmente deseas Cancelar?")
	if (cancela){
		window.location.assign("cancelarsin.php");
	}
 });



$('#procesarSinT').click(function(){
        //remove classes
        $('#facturas input').removeClass('error').removeClass('valid');
		$('#facturas select').removeClass('error').removeClass('valid');
        
		  var fields = $('#facturas select.second,input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            // alert($(this).attr('id'))
			
				if(($(this).attr('id'))=='cuenta' || ($(this).attr('id'))=='numcuenta'){
				$(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
				
				}
            } else {
                $(this).addClass('valid');
            }
        });

         if(!error) {


	         var rfc=$("#rfc").val();
			 var id_domicilio=$("#id_domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var pemex=$("#pemex").val();
			 var id_formpago=$("#id_formpago").val();
			 var numfactura=$("#numfactura").val();
			 var nticket=$("#nticket").val();
			 var numcuenta=$("#numcuenta").val();
	 
				 
			 if (nticket==0){
				alert ("Inrgese un Servicio para Procesar la Factura"); 
			 }else{
			 
			 var procesa = confirm("Realmente deseas Procesar la Factura?");

	         if (procesa){
			    
				 function restults(dataf) {
			 
			 if (dataf.mensaje){
               
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+dataf.mensaje+'</p>', 
                timeout:   2000 
                });
					 
			 }else{
				 
				 if (dataf.facturado!=0){
   
				 $.unblockUI(); 

			 	 $('#facturas').slideUp();
		         $('#descarga').slideDown();  
				 $('#progress_text').html('100% Complete');
                 $('#progress').css('width','339px');
				 $("#descarga").load("descarga.php",{f:dataf.facturado}, function(response, status, xhr) {
                     if (status == "error") {
                     var msg = "Error!, algo ha sucedido: ";
                     $("#descarga").html(msg + xhr.status + " " + xhr.statusText);
                     }	
					 
			     });
				
				
				 }else{
			
                 alert("No Se pudo Procesar la Factura, Favor de revisar los datos del cliente\n\n!Que no contenga espacios vacios entre los datos del cliente!")
                 $.unblockUI();  
                 window.location.reload();
                 }
				 
			  }
			}			 
       
            $.ajax({
            data: "rfc="+encodeURIComponent(rfc)+"&id_domicilio="+id_domicilio+"&id_estacion="+id_estacion+"&pemex="+pemex+"&id_formpago="+id_formpago+"&numfactura="+numfactura+"&numcuenta="+numcuenta,
            type: "POST",
            dataType: "json",
            url: 'procesarsint.php',
	        beforeSend: function(){
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(dataf){
            restults(dataf);
            },error: function(dataf) {
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>PAC no responde, intentelo mas tarde.</p>', 
                timeout:   2000 
                });
			}
			
			
	        })
 
         }
  
      }
	  
	     } else return false;

    });

//////////////////// PARA PROCESAR ANTICIPOS ///////////////////////////


$('#procesarAnticipos').click(function(){
        //remove classes
        $('#facturas input').removeClass('error').removeClass('valid');
		$('#facturas select').removeClass('error').removeClass('valid');
        
		  var fields = $('#facturas select.second,input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            // alert($(this).attr('id'))
			
				if(($(this).attr('id'))=='cuenta' || ($(this).attr('id'))=='numcuenta'){
				$(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
				
				}
            } else {
                $(this).addClass('valid');
            }
        });

         if(!error) {


	         var rfc=$("#rfc").val();
			 var id_domicilio=$("#id_domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var pemex=$("#pemex").val();
			 var id_formpago=$("#id_formpago").val();
			 var numfactura=$("#numfactura").val();
			 var nticket=$("#nticket").val();
			 var numcuenta=$("#numcuenta").val();
	 
				 
			 if (nticket==0){
				alert ("Inrgese un Servicio para Procesar la Factura"); 
			 }else{
			 
			 var procesa = confirm("Realmente deseas Procesar la Factura?");

	         if (procesa){
			    
				 function restults(dataf) {
			 
			 if (dataf.mensaje){
               
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+dataf.mensaje+'</p>', 
                timeout:   2000 
                });
					 
			 }else{
				 
				 if (dataf.facturado!=0){
   
				 $.unblockUI(); 

			 	 $('#facturas').slideUp();
		         $('#descarga').slideDown();  
				 $('#progress_text').html('100% Complete');
                 $('#progress').css('width','339px');
				 $("#descarga").load("descarga.php",{f:dataf.facturado}, function(response, status, xhr) {
                     if (status == "error") {
                     var msg = "Error!, algo ha sucedido: ";
                     $("#descarga").html(msg + xhr.status + " " + xhr.statusText);
                     }	
					 
			     });
				
				
				 }else{
			
                 alert("No Se pudo Procesar la Factura, Favor de revisar los datos del cliente\n\n!Que no contenga espacios vacios entre los datos del cliente!")
                 $.unblockUI();  
                 window.location.reload();
                 }
				 
			  }
			}			 
       
            $.ajax({
            data: "rfc="+encodeURIComponent(rfc)+"&id_domicilio="+id_domicilio+"&id_estacion="+id_estacion+"&pemex="+pemex+"&id_formpago="+id_formpago+"&numfactura="+numfactura+"&numcuenta="+numcuenta,
            type: "POST",
            dataType: "json",
            url: 'procesaranti.php',
	        beforeSend: function(){
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(dataf){
            restults(dataf);
            },error: function(dataf) {
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>PAC no responde, intentelo mas tarde.</p>', 
                timeout:   2000 
                });
			}
			
			
	        })
 
         }
  
      }
	  
	     } else return false;

    });



//////////////////FIN ANTICIPOS ////////////////////////////////////////



/////////////////// PARA CON ACREDITAMIENT TAR /////////////////////////////

$('#procesarTAR').click(function(){
        //remove classes
        $('#facturas input').removeClass('error').removeClass('valid');
		$('#facturas select').removeClass('error').removeClass('valid');
        
		  var fields = $('#facturas select.second,input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            // alert($(this).attr('id'))
			
				if(($(this).attr('id'))=='cuenta' || ($(this).attr('id'))=='numcuenta'){
				$(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
				
				}
            } else {
                $(this).addClass('valid');
            }
        });

         if(!error) {


	         var rfc=$("#rfc").val();
			 var id_domicilio=$("#id_domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var pemex=$("#pemex").val();
			 var id_formpago=$("#id_formpago").val();
			 var numfactura=$("#numfactura").val();
			 var nticket=$("#nticket").val();
			 var numcuenta=$("#numcuenta").val();
 
				 
			 if (nticket==0){
				alert ("Inrgese un Servicio para Procesar la Factura"); 
			 }else{
			 
			 var procesa = confirm("Realmente deseas Procesar la Factura?");

	         if (procesa){
			    
				 function restults(dataf) {
			 
			 if (dataf.mensaje){
               
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+dataf.mensaje+'</p>', 
                timeout:   2000 
                });
					 
			 }else{
				 
				 if (dataf.facturado!=0){
   
				 $.unblockUI(); 

			 	 $('#facturas').slideUp();
		         $('#descarga').slideDown();  
				 $('#progress_text').html('100% Complete');
                 $('#progress').css('width','339px');
				 $("#descarga").load("descarga.php",{f:dataf.facturado}, function(response, status, xhr) {
                     if (status == "error") {
                     var msg = "Error!, algo ha sucedido: ";
                     $("#descarga").html(msg + xhr.status + " " + xhr.statusText);
                     }	
					 
			     });
				
				
				 }else{
			
                 alert("No Se pudo Procesar la Factura, Favor de revisar los datos del cliente\n\n!Que no contenga espacios vacios entre los datos del cliente!")
                 $.unblockUI();  
                 window.location.reload();
                 }
				 
			  }
			}			 
       
            $.ajax({
            data: "rfc="+encodeURIComponent(rfc)+"&id_domicilio="+id_domicilio+"&id_estacion="+id_estacion+"&pemex="+pemex+"&id_formpago="+id_formpago+"&numfactura="+numfactura+"&numcuenta="+numcuenta,
            type: "POST",
            dataType: "json",
            url: 'procesarsint_conacre.php',
	        beforeSend: function(){
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(dataf){
            restults(dataf);
            },error: function(dataf) {
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>PAC no responde, intentelo mas tarde.</p>', 
                timeout:   2000 
                });
			}
			
			
	        })
 
         }
  
      }
	  
	     } else return false;

    });



////////////FIN DE ACREDITAMIENTO TAR /////////////////////////////////////




////////////monedero


$('#procesarMon').click(function(){
        //remove classes
        $('#facturas input').removeClass('error').removeClass('valid');
		$('#facturas select').removeClass('error').removeClass('valid');
        
		  var fields = $('#facturas select.second,input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            // alert($(this).attr('id'))
			
				if(($(this).attr('id'))=='cuenta' || ($(this).attr('id'))=='numcuenta'){
				$(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
				
				}
            } else {
                $(this).addClass('valid');
            }
        });

         if(!error) {


	         var rfc=$("#rfc").val();
			 var id_domicilio=$("#id_domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var pemex=$("#pemex").val();
			 var id_formpago=$("#id_formpago").val();
			 var numfactura=$("#numfactura").val();
			 var nticket=$("#nticket").val();
			 var numcuenta=$("#numcuenta").val();
		 
			 		 
			 if (nticket==0){
				alert ("Inrgese un Servicio para Procesar la Factura"); 
			 }else{
			 
			 var procesa = confirm("Realmente deseas Procesar la Factura?");

	         if (procesa){
			    
				 function restults(dataf) {

			 if (dataf.mensaje){
               
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+dataf.mensaje+'</p>', 
                timeout:   2000 
                });
					 
			 }else{

			     if (dataf.facturado!=0){
   
				 $.unblockUI(); 

			 	 $('#facturas').slideUp();
		         $('#descarga').slideDown();  
				 $('#progress_text').html('100% Complete');
                 $('#progress').css('width','339px');
				 $("#descarga").load("descarga.php",{f:dataf.facturado}, function(response, status, xhr) {
                     if (status == "error") {
                     var msg = "Error!, algo ha sucedido: ";
                     $("#descarga").html(msg + xhr.status + " " + xhr.statusText);
                     }	
					 
			     });
				
				
				 }else{
                 alert("No Se pudo Procesar la Factura, Favor de revisar los datos del cliente\n\n!Que no contenga espacios vacios entre los datos del cliente!")
                 $.unblockUI();  
                 window.location.reload();
                 }
			  }
			}			 
       
            $.ajax({
            data: "rfc="+encodeURIComponent(rfc)+"&id_domicilio="+id_domicilio+"&id_estacion="+id_estacion+"&pemex="+pemex+"&id_formpago="+id_formpago+"&numfactura="+numfactura+"&numcuenta="+numcuenta,
            type: "POST",
            dataType: "json",
            url: "procesarmonedero.php",
	        beforeSend: function(){
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(dataf){
            restults(dataf);
            },error: function(dataf) {
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>PAC no responde, intentelo mas tarde.</p>', 
                timeout:   2000 
                });
			}
	        })
 
         }
  
      }
	  
	     } else return false;

    });




////////////////////PROCESAR SINT Y DESPA




  $('#submit_procesar').click(function(){
        //remove classes
       $('#facturas input').removeClass('error').removeClass('valid');
		$('#facturas select').removeClass('error').removeClass('valid');
        
		  var fields = $('#facturas select.second,input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
           // alert($(this).attr('id'))
			    
				if(($(this).attr('id'))!='ticket' && ($(this).attr('id'))!='datepicker' && ($(this).attr('id'))!='cantidad'){
				$(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
				}
            } else {
                $(this).addClass('valid');
            }
        });

         if(!error) {


	         var rfc=$("#rfc").val();
			 var id_domicilio=$("#id_domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var pemex=$("#pemex").val();
			 var id_formpago=$("#id_formpago").val();
			 var serie=$("#serie").val();
			 var numfactura=$("#numfactura").val();
			 var nticket=$("#nticket").val();
			 var id_despachador=$("#id_despachador").val();
			 var numcuenta=$("#numcuenta").val();
		
			 		
			 if (nticket==0){
				alert ("Inrgese un Ticket para Procesar la Factura"); 
			 }else{
			 
			 var procesa = confirm("Realmente deseas Procesar la Factura?");

	         if (procesa){
			    
				 function restults(dataf) {

			 if (dataf.mensaje){
               
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+dataf.mensaje+'</p>', 
                timeout:   2000 
                });
					 
			 }else{
			 
			     if (dataf.facturado!=0){
   
				 $.unblockUI(); 

			 	 $('#facturas').slideUp();
		         $('#descarga').slideDown();  
				 $('#progress_text').html('100% Complete');
                 $('#progress').css('width','339px');
				 $("#descarga").load("descarga.php",{f:dataf.facturado}, function(response, status, xhr) {
                     if (status == "error") {
                     var msg = "Error!, algo ha sucedido: ";
                     $("#descarga").html(msg + xhr.status + " " + xhr.statusText);
                     }	
					 
			     });
				
				
				 }else{
                 alert("No Se pudo Procesar la Factura, Favor de revisar los datos del cliente\n\n!Que no contenga espacios vacios entre los datos del cliente!")	 
                 $.unblockUI();  
                 window.location.reload();
                 }
			  }
			}			 
            

			
            $.ajax({
            data: "rfc="+encodeURIComponent(rfc)+"&id_domicilio="+id_domicilio+"&id_estacion="+id_estacion+"&pemex="+pemex+"&id_formpago="+id_formpago+"&numfactura="+numfactura+"&serie="+serie+"&id_despachador="+id_despachador+"&numcuenta="+numcuenta,
            type: "POST",
            dataType: "json",
            url: "procesardespachador.php",
	        beforeSend: function(){
     
			 $.blockUI({ message: $('#loading') });  
            },
	         success: function(dataf){
            restults(dataf);
            },error: function(dataf) {
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>PAC no responde, intentelo mas tarde.</p>', 
                timeout:   2000 
                });
			}
	        })
 
         }
  
      }
	  
	     } else return false;

    });




  $('#submit_procesar2').click(function(){
        //remove classes
        $('#facturas input').removeClass('error').removeClass('valid');
		$('#facturas select').removeClass('error').removeClass('valid');
        
		  var fields = $('#facturas select.second,input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
           //  alert($(this).attr('id'))
			  if(($(this).attr('id'))!='ticket' && ($(this).attr('id'))!='datepicker' && ($(this).attr('id'))!='cliente1' && ($(this).attr('id'))!='cantidad'){
				$(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
				}
            } else {
                $(this).addClass('valid');
            }
        });

         if(!error) {


	         var rfc=$("#rfc").val();
			 var id_domicilio=$("#id_domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var pemex=$("#pemex").val();
			 var id_formpago=$("#id_formpago").val();
			 var serie=$("#serie").val();
			 var numfactura=$("#numfactura").val();
			 var nticket=$("#nticket").val();
			 var numcuenta=$("#numcuenta").val();
				
 
			 		 
			 if (nticket==0){
				alert ("Inrgese un Ticket para Procesar la Factura"); 
			 }else{
			 
			 var procesa = confirm("Realmente deseas Procesar la Factura?");

	         if (procesa){
			    
				 function restults(dataf) {

			 if (dataf.mensaje){
               
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+dataf.mensaje+'</p>', 
                timeout:   2000 
                });
					 
			 }else{

			 
			     if (dataf.facturado!=0){
                 //alert(dataf.facturado)
				 $.unblockUI(); 

			 	 $('#facturas').slideUp();
		         $('#descarga').slideDown();  
				 $('#progress_text').html('100% Complete');
                 $('#progress').css('width','339px');
				 $("#descarga").load("descarga.php",{f:dataf.facturado}, function(response, status, xhr) {
                     if (status == "error") {
                     var msg = "Error!, algo ha sucedido: ";
                     $("#descarga").html(msg + xhr.status + " " + xhr.statusText);
                     }	
					 
			     });
				
				
				 }else{
                 alert("No Se pudo Procesar la Factura, Favor de revisar los datos del cliente\n\n!Que no contenga espacios vacios entre los datos del cliente!")
                 $.unblockUI();  
                 window.location.reload();
                 }
			  }
			}			 
       
            $.ajax({
            data: "rfc="+encodeURIComponent(rfc)+"&id_domicilio="+id_domicilio+"&id_estacion="+id_estacion+"&pemex="+pemex+"&id_formpago="+id_formpago+"&numfactura="+numfactura+"&serie="+serie+"&numcuenta="+numcuenta,
            type: "POST",
            dataType: "json",
            url: "procesarfacturista.php",
	        beforeSend: function(){     
			 $.blockUI({ message: $('#loading') });  
            },
	         success: function(dataf){
            restults(dataf);
            },error: function(dataf) {
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>PAC no responde, intentelo mas tarde.</p>', 
                timeout:   2000 
                });
			}
	        })
 
         }
  
      }
	  
	     } else return false;

    });








/////////////////











//////// regresar al home 


  $('#home').click(function(){

   var inicio = confirm("Realmente deseas regresar?")
	if (inicio){
		window.location.assign("cancelarfc.php");
	}
 });
 
 
///////////tipo de facturacion

	
$('#sin').click(function(){

    $('#sintiket').slideUp();
    $('#ingresenip').slideDown();   
 
 });
	
$('#cancelasin').click(function(){
 
    $('#ingresenip').slideUp();
    $('#sintiket').slideDown();
	document.getElementById('nipestacion').value='';   
 
 });	

 $('#envianip').click(function(){
 
 var nipestacion=$("#nipestacion").val();
 var idestacion=$("#idestacion").val();
              
	if (nipestacion==''){
	
	   $.blockUI({ 
       theme:     true, 
       title:    'Alerta: Sistema Facturacion', 
       message:  '<p>Favor de ingresar un nip Valido.</p>', 
       timeout:   2000 
       });
	   
	}else{
		
		    function restults(datar) {
			
			  if(datar.valido=='0'){
			   	   $.unblockUI();
				   $.blockUI({ 
                   theme:     true, 
                   title:    'Alerta: Sistema Facturacion', 
                   message:  '<p>Favor de ingresar un nip Valido.</p>', 
                   timeout:   2000 
                   });
				   document.getElementById('nipestacion').value='';  
			    
			  }else{
			    window.location.reload();	
			  }
			
			}
	        
			
			$.ajax({
            data: "nipestacion="+nipestacion+"&idestacion="+idestacion,
            type: "POST",
            dataType: "json",
            url: "validanip.php",
	        beforeSend: function(){           
			$.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        })
	
	}
 
 });


$('#anti').click(function(){

    $('#anticipos').slideUp();
    $('#ingresenip2').slideDown();   
 
 });	
	

$('#cancelaanti').click(function(){
 
    $('#ingresenip2').slideUp();
    $('#anticipos').slideDown();
	document.getElementById('nipestacion2').value='';   
 
 });

	
 $('#envianip2').click(function(){
 
 var nipestacion=$("#nipestacion2").val();
 var idestacion=$("#idestacion").val();
              
	if (nipestacion==''){
	
	   $.blockUI({ 
       theme:     true, 
       title:    'Alerta: Sistema Facturacion', 
       message:  '<p>Favor de ingresar un nip Valido.</p>', 
       timeout:   2000 
       });
	   
	}else{
		
		    function restults(datar) {
			
			  if(datar.valido=='0'){
			   	   $.unblockUI();
				   $.blockUI({ 
                   theme:     true, 
                   title:    'Alerta: Sistema Facturacion', 
                   message:  '<p>Favor de ingresar un nip Valido.</p>', 
                   timeout:   2000 
                   });
				   document.getElementById('nipestacion2').value='';  
			    
			  }else{
			    window.location.reload();	
			  }
			
			}
	        
			
			$.ajax({
            data: "nipestacion="+nipestacion+"&idestacion="+idestacion,
            type: "POST",
            dataType: "json",
            url: "validanip2.php",
	        beforeSend: function(){           
			$.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        })
	
	}
 
 });


 $('#cancelamon').click(function(){
 
    $('#camposmon').slideUp();
    $('#botones').slideDown();
	document.getElementById('foliocfdi').value=''; 
	document.getElementById('rfcautorizado').value='';   
 
 });	
	
 

  $('.tipofactura').click(function(){
      var tventana=this.name;
		if (tventana=='monedero'){

    $('#botones').slideUp();
    $('#camposmon').slideDown();
		
		}else{
		  function restults(datar) {
			
				window.location.reload()	
		  
			   }
	
	        $.ajax({
            data: "tventana="+tventana,
            type: "POST",
            dataType: "json",
            url: "tipofact.php",
	        beforeSend: function(){           
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        })
		}
    });
  
   $('#continuamon').click(function(){
	
	var tventana=$("#tipofact").val();
	var foliocfdi=$("#foliocfdi").val();
	var rfcautorizado=$("#rfcautorizado").val();
		
	if(foliocfdi=='' || rfcautorizado==''){	
     	   
		$.blockUI({ 
        theme:     true, 
        title:    'Alerta: Sistema Facturacion', 
        message:  '<p>Favor de completar los datos para continuar.</p>', 
        timeout:   1000 
        });
		
	}else{
	        
			function restults(datar) {
			
			 window.location.reload();	
		  
			}
	
	        $.ajax({
            data: "tventana="+tventana+"&foliocfdi="+foliocfdi+"&rfcautorizado="+rfcautorizado,
            type: "POST",
            dataType: "json",
            url: "tipofact.php",
	        beforeSend: function(){           
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        })	
	
	}
 
   });
	
  $('#cancelarMon').click(function(){

   var cancela = confirm("Realmente deseas Cancelar?")
	if (cancela){
		window.location.assign("cancelarmon.php");
	}
 });
	
	
 $('#addaceites').click(function(){

   	$('#tickets').slideUp();
    $('#aceites').slideDown(); 
	document.getElementById('ticket').value='';  

 });	
	

  $('#addtickets').click(function(){

   	$('#aceites').slideUp();
    $('#tickets').slideDown(); 
	document.getElementById('cantidad').value='';  
	document.getElementById('producto').options.selectedIndex = 0;

 });

////////////////para liberar el ticket


$('#liberaticket').click(function(){
        //remove classes
        $('#ticket input').removeClass('error').removeClass('valid');
     
	    var fields = $('#inputcliente input[id=ticket]');
        var error = 0;
       
	    fields.each(function(){
            var value = $(this).val();
      
		    if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            
			   
			    $(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                
                error++;
			
            } else {
                $(this).addClass('valid');
            }
        });

        if(!error) {

 	         var ticket=$("#ticket").val();
    		
			function restults(datar) {
	
	
	            $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+datar.mensaje+'.</p>', 
                timeout:   3000 
                });
				document.getElementById('ticket').value='';	
				$('#ticket').focus();
	

			}
			
			
			 $.ajax({
             data: "ticket="+ticket,
             type: "POST",
             dataType: "json",
             url: "liberaticket.php",
	         beforeSend: function(){
             //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
             },
	         success: function(datar){
             restults(datar);
             }
	         })
        
		} else return false;

    });

//////////////////	


////////////////para eliminar servicios sintickets y monedero

$('.eliminaservicio').click(function(){

 var id_servicio=this.name;


	function restults(datar) {
	
	 if(datar==0){
	            $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+datar.mensaje+'.</p>', 
                timeout:   3000 
                });

	 }else{
                $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+datar.mensaje+'.</p>', 
                timeout:   2000 
                });		 
                window.location.reload();		 
	 }

			}

             $.ajax({
             data: "id_servicio="+id_servicio,
             type: "POST",
             dataType: "json",
             url: "deletesinticket.php",
	         beforeSend: function(){
             //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
             },
	         success: function(datar){
             restults(datar);
             }
	         })
 
 
});
/////////////


////////////////para eliminar servicios contickets

$('.eliminaservicio1').click(function(){

 var id_servicio=this.name;


	function restults(datar) {
	
	 if(datar==0){
	            $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+datar.mensaje+'.</p>', 
                timeout:   3000 
                });

	 }else{
                $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+datar.mensaje+'.</p>', 
                timeout:   2000 
                });		 
                window.location.reload();		 
	 }

			}

             $.ajax({
             data: "id_servicio="+id_servicio,
             type: "POST",
             dataType: "json",
             url: "deleteconticket.php",
	         beforeSend: function(){
             //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
             },
	         success: function(datar){
             restults(datar);
             }
	         })
 
 
});
/////////////

///////////////AGREGAR COMPLEMENTO INE //////////////

$('#agregarine').click(function(){

var tipoproceso=$("#tipoProceso").val();

if (tipocomite == 'Ejecutivo Nacional' ){

var tipocomite=$("#tipoComite").val();
var idcontabilidad=$("#idContabilidad").val();
var midata= "tipoproceso="+tipoproceso+"&tipocomite="+tipocomite+"&idcontabilidad="+idcontabilidad
	
}else if (tipoproceso=='Campaña' || tipoproceso=='Precampaña' ) {

var ambito=$("#ambito").val();
var claveentidad=$("#claveentidad").val();
var idcontabilidad=$("#idContabilidad").val();
var midata= "tipoproceso="+tipoproceso+"&tipocomite="+tipocomite+"&idcontabilidad="+idcontabilidad+"&claveentidad="+claveentidad+"&ambito="+ambito

}else{

var tipocomite=$("#tipoComite").val();
var idcontabilidad=$("#idContabilidad").val();
var claveentidad=$("#claveentidad").val();
var midata= "tipoproceso="+tipoproceso+"&tipocomite="+tipocomite+"&idcontabilidad="+idcontabilidad+"&claveentidad="+claveentidad
	
}



	function restults(datar) {
	
	 if(datar.inne==0){
	            $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+datar.mensaje+'.</p>', 
                timeout:   3000 
                });
                
	 }else{
                
				$.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+datar.mensaje+'.</p>', 
                timeout:   2000 
                });	
                window.location.reload();	
                		 
	 }

			}

             $.ajax({
             data: midata,
             type: "POST",
             dataType: "json",
             url: "addine.php",
	         beforeSend: function(){
             //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
             },
	         success: function(datar){
             restults(datar);
             }
	         })
 
 
});


//////////////

//TMBRAR INNES ///////


$('#procesarSinTinne').click(function(){
        //remove classes
        $('#facturas input').removeClass('error').removeClass('valid');
		$('#facturas select').removeClass('error').removeClass('valid');
        
		  var fields = $('#facturas select.second,input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            // alert($(this).attr('id'))
			
				if(($(this).attr('id'))=='cuenta' || ($(this).attr('id'))=='numcuenta'){
				$(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
				
				}
            } else {
                $(this).addClass('valid');
            }
        });

         if(!error) {


	         var rfc=$("#rfc").val();
			 var id_domicilio=$("#id_domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var pemex=$("#pemex").val();
			 var id_formpago=$("#id_formpago").val();
			 var numfactura=$("#numfactura").val();
			 var nticket=$("#nticket").val();
			 var numcuenta=$("#numcuenta").val();
	 
				 
			 if (nticket==0){
				alert ("Inrgese un Servicio para Procesar la Factura"); 
			 }else{
			 
			 var procesa = confirm("Realmente deseas Procesar la Factura?");

	         if (procesa){
			    
				 function restults(dataf) {
			 
			 if (dataf.mensaje){
               
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+dataf.mensaje+'</p>', 
                timeout:   2000 
                });
					 
			 }else{
				 
				 if (dataf.facturado!=0){
   
				 $.unblockUI(); 

			 	 $('#facturas').slideUp();
		         $('#descarga').slideDown();  
				 $('#progress_text').html('100% Complete');
                 $('#progress').css('width','339px');
				 $("#descarga").load("descarga.php",{f:dataf.facturado}, function(response, status, xhr) {
                     if (status == "error") {
                     var msg = "Error!, algo ha sucedido: ";
                     $("#descarga").html(msg + xhr.status + " " + xhr.statusText);
                     }	
					 
			     });
				
				
				 }else{
			
                 alert("No Se pudo Procesar la Factura, Favor de revisar los datos del cliente\n\n!Que no contenga espacios vacios entre los datos del cliente!")
                 $.unblockUI();  
                 window.location.reload();
                 }
				 
			  }
			}			 
       
            $.ajax({
            data: "rfc="+encodeURIComponent(rfc)+"&id_domicilio="+id_domicilio+"&id_estacion="+id_estacion+"&pemex="+pemex+"&id_formpago="+id_formpago+"&numfactura="+numfactura+"&numcuenta="+numcuenta,
            type: "POST",
            dataType: "json",
            url: 'procesarsintinne1.php',
	        beforeSend: function(){
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(dataf){
            restults(dataf);
            },error: function(dataf) {
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>PAC no responde, intentelo mas tarde.</p>', 
                timeout:   2000 
                });
			}
			
			
	        })
 
         }
  
      }
	  
	     } else return false;

    });



$('#procesarSinTinne1').click(function(){
        //remove classes
        $('#facturas input').removeClass('error').removeClass('valid');
		$('#facturas select').removeClass('error').removeClass('valid');
        
		  var fields = $('#facturas select.second,input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            // alert($(this).attr('id'))
			
				if(($(this).attr('id'))=='cuenta' || ($(this).attr('id'))=='numcuenta'){
				$(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
				
				}
            } else {
                $(this).addClass('valid');
            }
        });

         if(!error) {


	         var rfc=$("#rfc").val();
			 var id_domicilio=$("#id_domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var pemex=$("#pemex").val();
			 var id_formpago=$("#id_formpago").val();
			 var numfactura=$("#numfactura").val();
			 var nticket=$("#nticket").val();
			 var numcuenta=$("#numcuenta").val();
	 
				 
			 if (nticket==0){
				alert ("Inrgese un Servicio para Procesar la Factura"); 
			 }else{
			 
			 var procesa = confirm("Realmente deseas Procesar la Factura?");

	         if (procesa){
			    
				 function restults(dataf) {
			 
			 if (dataf.mensaje){
               
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+dataf.mensaje+'</p>', 
                timeout:   2000 
                });
					 
			 }else{
				 
				 if (dataf.facturado!=0){
   
				 $.unblockUI(); 

			 	 $('#facturas').slideUp();
		         $('#descarga').slideDown();  
				 $('#progress_text').html('100% Complete');
                 $('#progress').css('width','339px');
				 $("#descarga").load("descarga.php",{f:dataf.facturado}, function(response, status, xhr) {
                     if (status == "error") {
                     var msg = "Error!, algo ha sucedido: ";
                     $("#descarga").html(msg + xhr.status + " " + xhr.statusText);
                     }	
					 
			     });
				
				
				 }else{
			
                 alert("No Se pudo Procesar la Factura, Favor de revisar los datos del cliente\n\n!Que no contenga espacios vacios entre los datos del cliente!")
                 $.unblockUI();  
                 window.location.reload();
                 }
				 
			  }
			}			 
       
            $.ajax({
            data: "rfc="+encodeURIComponent(rfc)+"&id_domicilio="+id_domicilio+"&id_estacion="+id_estacion+"&pemex="+pemex+"&id_formpago="+id_formpago+"&numfactura="+numfactura+"&numcuenta="+numcuenta,
            type: "POST",
            dataType: "json",
            url: 'procesarsintinne2.php',
	        beforeSend: function(){
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(dataf){
            restults(dataf);
            },error: function(dataf) {
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>PAC no responde, intentelo mas tarde.</p>', 
                timeout:   2000 
                });
			}
			
			
	        })
 
         }
  
      }
	  
	     } else return false;

    });



$('#procesarSinTinne2').click(function(){
        //remove classes
        $('#facturas input').removeClass('error').removeClass('valid');
		$('#facturas select').removeClass('error').removeClass('valid');
        
		  var fields = $('#facturas select.second,input[type=text]');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
            if( value.length<1 || value==field_values[$(this).attr('id')]  ) {
            // alert($(this).attr('id'))
			
				if(($(this).attr('id'))=='cuenta' || ($(this).attr('id'))=='numcuenta'){
				$(this).addClass('error');
                $(this).effect("shake", { times:3 }, 50);
                error++;
				
				}
            } else {
                $(this).addClass('valid');
            }
        });

         if(!error) {


	         var rfc=$("#rfc").val();
			 var id_domicilio=$("#id_domicilio").val();
			 var id_estacion=$("#id_estacion").val();
			 var pemex=$("#pemex").val();
			 var id_formpago=$("#id_formpago").val();
			 var numfactura=$("#numfactura").val();
			 var nticket=$("#nticket").val();
			 var numcuenta=$("#numcuenta").val();
	 
				 
			 if (nticket==0){
				alert ("Inrgese un Servicio para Procesar la Factura"); 
			 }else{
			 
			 var procesa = confirm("Realmente deseas Procesar la Factura?");

	         if (procesa){
			    
				 function restults(dataf) {
			 
			 if (dataf.mensaje){
               
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+dataf.mensaje+'</p>', 
                timeout:   2000 
                });
					 
			 }else{
				 
				 if (dataf.facturado!=0){
   
				 $.unblockUI(); 

			 	 $('#facturas').slideUp();
		         $('#descarga').slideDown();  
				 $('#progress_text').html('100% Complete');
                 $('#progress').css('width','339px');
				 $("#descarga").load("descarga.php",{f:dataf.facturado}, function(response, status, xhr) {
                     if (status == "error") {
                     var msg = "Error!, algo ha sucedido: ";
                     $("#descarga").html(msg + xhr.status + " " + xhr.statusText);
                     }	
					 
			     });
				
				
				 }else{
			
                 alert("No Se pudo Procesar la Factura, Favor de revisar los datos del cliente\n\n!Que no contenga espacios vacios entre los datos del cliente!")
                 $.unblockUI();  
                 window.location.reload();
                 }
				 
			  }
			}			 
       
            $.ajax({
            data: "rfc="+encodeURIComponent(rfc)+"&id_domicilio="+id_domicilio+"&id_estacion="+id_estacion+"&pemex="+pemex+"&id_formpago="+id_formpago+"&numfactura="+numfactura+"&numcuenta="+numcuenta,
            type: "POST",
            dataType: "json",
            url: 'procesarsintinne3.php',
	        beforeSend: function(){
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(dataf){
            restults(dataf);
            },error: function(dataf) {
			    $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>PAC no responde, intentelo mas tarde.</p>', 
                timeout:   2000 
                });
			}
			
			
	        })
 
         }
  
      }
	  
	     } else return false;

    });


/////////////////////

////////////AGREGAR CAMPO PARA COMENTARIOS//////////

	 $('#showcomentarios').click(function(){
		$('#sinticket').slideUp();
		$('#aceites').slideUp();
		$('#tickets').slideUp();
		$('#tablapartida').slideUp();
		$('#partida').slideUp();
		$('#formpago').slideUp();
		$('#tabfact').slideUp();
		$('#addcoment').slideDown();   

	    });
		
	 $('#cancelacoment').click(function(){
		$('#sinticket').slideDown();
		$('#aceites').slideUp();
		$('#tickets').slideDown();
		$('#tablapartida').slideDown();
		$('#partida').slideDown();
		$('#formpago').slideDown();
		$('#tabfact').slideDown();
		$('#addcoment').slideUp();   

	    });		
		
		$('#addcomentarios').click(function(){
		
		var comentarios=$("#comentarios").val();
	    var comentario=$("#comentario").val();
		
		function restults(datar) {

	         if(datar.coment==0){
	            $.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+datar.mensaje+'.</p>', 
                timeout:   3000 
                });
                
	        }else{
                
				$.blockUI({ 
                theme:     true, 
                title:    'Alerta: Sistema Facturacion', 
                message:  '<p>'+datar.mensaje+'.</p>', 
                timeout:   2000 
                });	
		     
		        $('#sinticket').slideDown();
		        $('#aceites').slideUp();
		        $('#tickets').slideDown();
		        $('#tablapartida').slideDown();
		        $('#partida').slideDown();
	 	        $('#formpago').slideDown();
		        $('#tabfact').slideDown();
		        $('#addcoment').slideUp();   
                		 
	        }

		}

             $.ajax({
             data: "comentarios="+comentarios+"&comentario="+comentario,
             type: "POST",
             dataType: "json",
             url: "addcomentarios.php",
	         beforeSend: function(){
             //$.blockUI();
			 $.blockUI({ message: $('#loading') });  
             },
	         success: function(datar){
             restults(datar);
             }
	         })
 		
		});

////////////

	
});