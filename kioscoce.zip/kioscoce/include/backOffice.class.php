<?
@session_start();
class backOffice
{
	  var $tabla="";
	  var $excluye="";
	  var $salida=array();
	  var $siguienteId="";
	  var $mostrarDato=array();
	  var $Ultimo_Id=0;
 
	function redirecciona($url)
	{
		echo '<script languaje="javascript">location.href=\''.$url.'\';</script>';
	}
	
	function describeTabla($tabla, $excluye="")
	{
		$this->tabla=$tabla;
		$this->excluye=$excluye;
		$salida		=	array();
		$qDescribe	=	"DESCRIBE $tabla";
		$rDescribe	=	mysql_query($qDescribe) OR die("<p>$rDescribe</p><p>".mysql_error()."</p>");
	
		while(	$dDescribe	=	mysql_fetch_row($rDescribe)	)
		{
			if( (is_array($excluye) && !in_array($dDescribe[0],$excluye)) || (!is_array($excluye) && $excluye != $dDescribe[0]) )
				$salida[]	=	$dDescribe[0];
		}
		$this->salida= $salida;
	}
	
	function manipulaDatos($tabla, $indice, $datos,$valorIndice=0,$url)
	{
		$this->describeTabla($tabla,$excluye);
		$query			=	"";
		foreach($this->salida as $clave)
		 if(isset($_POST[$clave]))
			$query		.=	(($query=="")?"":",")."$clave='".$datos[$clave]."'";
	    if($valorIndice!=0)
		   $query		=	"UPDATE $tabla SET ".$query." WHERE ($indice='".$datos[$indice]."')";
		else
		   $query		=	"INSERT INTO $tabla SET $query";
		   $res_query		=	mysql_query($query) OR die("<p>$query</p><p>".mysql_error()."</p>");
		$this->Ultimo_Id=mysql_insert_id();
  	}
	
function manipulaDatos1($tabla, $indice, $datos,$valorIndice=0,$url)
	{
		$this->describeTabla($tabla,$excluye);
		$query			=	"";
		foreach($this->salida as $clave)
		 if(isset($_POST[$clave]))
			$query		.=	(($query=="")?"":",")."$clave='".$datos[$clave]."'";
	    if($valorIndice!=0)
		   $query		=	"UPDATE $tabla SET ".$query." WHERE ($indice='".$datos[$indice]."')";
		else
		 $query		=	"UPDATE $tabla SET ".$query." WHERE ($indice='".$datos[$indice]."')";
		   $res_query		=	mysql_query($query) OR die("<p>$query</p><p>".mysql_error()."</p>");
	$this->Ultimo_Id=mysql_insert_id();

	}  
	
	
	function eliminarRegistro($tabla,$indice,$valor)
	{
		$q_eliminar	=	"DELETE FROM $tabla WHERE ($indice='".$valor."') LIMIT 1";
		$r_eliminar	=	mysql_query($q_eliminar) OR die("<p>$q_eliminar</p><p>".mysql_error()."</p>");	
	}
	
	function mostrarRegistro($tabla,$indice,$valor)
	{
		$query_dato	=	"SELECT * FROM $tabla WHERE ($indice='".$valor."')";
		$res_dato	=	mysql_query($query_dato) OR die("<p>$query_dato</p><p>".mysql_error()."</p>");
		$this->mostrarDato		=	mysql_fetch_assoc($res_dato);
	}
	
	function alert($mensaje)
	{
		echo '<script languaje="javascript">alert(\''.$mensaje.'\');</script>';
	}
	
	
	function paginar($link, $paginas, $pagina,$mensaje)
	{
       echo '   
		  	 <table align="center" cellspacing="0" cellpadding="0" border="0">
              <tr>';
                  if(isset($pagina) && $pagina>1)
                     echo '<td><a href="'.$link.'&amp;pagina='.($pagina-1).'" class="Paginador" align="right"><img src="images/paginador_03.jpg" border="0"/></td>';
	              if(isset($pagina) && $pagina==1)
                     echo '<td><a href="'.$link.'&amp;pagina='.($pagina).'" class="Paginador" align="right"><img src="images/paginador_03.jpg" border="0"/></a></td>';
			
			if ($paginas > 1)
				{
					for ($i=1;$i<=$paginas;$i++)
					{
					  if($i<$paginas) 
					  {
						if($pagina!=$i) 
						  echo '<td class="Paginador"><a href="'.$link.'&pagina='.$i.'" class="Paginador"> <font size=\"1px\">'.$i.'</font> </a></td><td class="Paginador">&nbsp;<span class="separador">l</span>&nbsp;</td>';
						else
						 echo '<td class="Paginador2">'.$i.'</td><td class="Paginador">&nbsp;<span class="separador">l</span></td>'; 
					  }			   
					  else
					  {
						if($pagina!=$i) 
						  echo '<td class="Paginador"><a href="'.$link.'&pagina='.$i.'" class="Paginador"> <font size=\"1px\">'.$i.'</font></a></td>';
						else
						  echo '<td class="Paginador2">'.$i.'</td>'; 
					  } 
				} }
				else 
				  if(!$paginas) 
					echo $mensaje;			  
          
		  
		  echo '<td>';
                 if(($pagina<$paginas || !isset($pagina)) && $paginas>1)
                  echo '<a href="'.$link.'&pagina='.($pagina+1).'" class="Paginador" align="left"><img src="images/paginador_06.jpg" border="0"/></a>';
                 if($pagina==$paginas)
                  echo '<a href="'.$link.'&pagina='.($pagina).'" class="Paginador" align="left"><img src="images/paginador_06.jpg" border="0"/></a>';          
		  echo '</td>
              </tr>
            </table>	';
     }
	 
	 
	 function fecha($fecha)
	 {
	 	$fecha=explode("-",$fecha);
		return $fecha[2]."-".$fecha[1]."-".$fecha[0];
	 }
	 
	 
	 function cadenaAleatoria($longitud)
	 {
		$keychars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
		// RANDOM KEY GENERATOR
		$randkey = "";
		$max=strlen($keychars)-1;
		for ($i=0;$i<$longitud;$i++) 
			$randkey .= substr($keychars, rand(0, $max), 1);
		return $randkey;	
	 }

//GENERA EL SELECTED PADRE
function generaContenido($tabla,$id_select,$campo = "",$flagDependiente = true)
{
	$qConsulta	=	"SELECT * FROM $tabla";
	if($tabla == "estado")
	$qConsulta	.=	" ORDER BY nombre ASC";
	
	$consulta=mysql_query($qConsulta);
	// Voy imprimiendo el primer select compuesto por los paises
	if($flagDependiente)
		echo "<select name='".$id_select."' id='".$id_select."' class='contenido' onChange='cargaContenido(this.id,".$_REQUEST['seccion'].")' style='width:260px;'>";
	else
		echo "<select name='".$id_select."' id='".$id_select."' class='contenido' style='width:260px;'>";
	echo "<option value='0'>Elige</option>";
	while($registro = mysql_fetch_row($consulta))
	{
	    $selected="";
		if($registro[0]==$campo)
			$selected="selected";
		//else if(!empty($idSeleccionado) && $registro[0] == $idSeleccionado)
		//	$selected="selected";
		echo "<option value='".$registro[0]."' ".$selected.">".$registro[1]."</option>";
	}
	echo "</select>";
} 

//TABLA, ID DEL SELECT, NAME DEL SELECT, ID DEL OPTION, NAME DEL OPTION, VALOR DEL ID
function generaSelectPadre($tabla,$idselect,$nameselect,$idoption,$nameoption,$valorid)
{
	$consulta=mysql_query("SELECT * FROM $tabla WHERE 1 ORDER BY nombre");
	$select ="<select name='".$nameselect."' id='".$idselect."'  style='width:205px;' onChange='cargaContenido(this.id)'>";
	$select.="<option value='0'>Elige</option>";
	
	while($registro=mysql_fetch_assoc($consulta))
	{
		if($valorid==$registro[$idoption])
			$selected="selected";	   
		else 
		    $selected="";
		$select.="<option value='".$registro[$idoption]."' '".$selected."'>".$registro[$nameoption]."</option>";
	}
	$select.="</select>";
	return $select;
}

	function obtenerDato($indice,$tabla,$campoIndice)
		{
		
		 $qDato="SELECT * FROM $tabla WHERE $campoIndice='".$indice."'";
		
		 $rDato=mysql_query($qDato);
		
		 $dDato=mysql_fetch_row($rDato);
		
		 return $salida=array($dDato[1],$dDato[2],$dDato[3]);
		
		}
}
?>