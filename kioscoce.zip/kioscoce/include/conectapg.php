<?
function conectar(){
        $host="192.168.200.23";
        $port="5432";
	$db="Combu_Express";
	$user="openerp";
	$pass="open23&ce16#.";
	$conexion =pg_connect("host=$host port=$port dbname=$db user=$user password=$pass") or die("Error al conectar con la base de datos".pg_error());
	return  $conexion;
	}
?>