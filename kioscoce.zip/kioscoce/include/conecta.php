<?php
define("SERVER","localhost");
define("USER","root");
define("PASSWORD","");
define("BD","facturacion2");
$db_link =@mysql_connect(SERVER, USER, PASSWORD) OR die("Error de conexi�n: " . mysql_error());
@mysql_select_db(BD,$db_link);
?>