<?
/////////////////////////////////////////////////////////////////////////////////////
//                                *************                                    //
//                                **  NOTAS  **                                    //
//                                *************                                    //
//  *Array que vincula los IDs de los selects declarados en el HTML con el nombre  //
//  de la tabla donde se encuentra su contenido.                                   //
//                 ---------------------------------------------                   //                                
//  *Si utilizamos mas select�s dependientes en el sistema solo debemos ir         //
//   agregando el nombre del select padre, seguido del nombre del select           //
//   dependiente en el arreglo $listadoSelects.                                    // 
//                 ---------------------------------------------                   // 
//  *Es necesario tambien darle un valor a la variable $id (que est� en la         //
//   consulta m�s abajo) para asegurarnos de que el select cargue correctamente    //
//   los datos adem�s de evitar un error en la consulta. Esto cada que agreguemos  //
//   nuevos select�s dependientes en el sistema.                                   //
//                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////
$listadoSelects=array(
"marca"=>"marca",
"modelo"=>"modelo",
"estado"=>"estado",
"ciudad"=>"ciudad",
"marca_auto"=>"marca_auto",
"submarca_auto"=>"submarca_auto"
);

function validaSelect($selectDestino)
{
	// Se valida que el select enviado via GET exista
	global $listadoSelects;
	if(isset($listadoSelects[$selectDestino])) return true;
	else return false;
}

function validaOpcion($opcionSeleccionada)
{
	// Se valida que la opcion seleccionada por el usuario en el select tenga un valor numerico
	if(is_numeric($opcionSeleccionada)) return true;
	else return false;
}

$selectDestino=$_GET["select"]; $opcionSeleccionada=$_GET["opcion"];

if(validaSelect($selectDestino) && validaOpcion($opcionSeleccionada))
{
	$tabla=$listadoSelects[$selectDestino];
	//TABLA,ID PRINCIPAL,ID DE RELACION,NOMBRE DEL CAMPO...
	if ($tabla=="ciudad"){$id="id_ciudad"; $idRel="id_estado"; $campo="nombre";}
	if ($tabla=="modelo"){$id="id_modelo"; $idRel="id_marca";   $campo="nombre";}
	if ($tabla=="submarca_auto"){$id="id_submarca"; $idRel="id_marca"; $campo="nombre";}
	include 'conecta.php';
	$consulta=mysql_query("SELECT * FROM $tabla WHERE $idRel='$opcionSeleccionada' ORDER BY nombre") or die(mysql_error());
	// Comienzo a imprimir el select
	echo "<select name='".$selectDestino."' id='".$selectDestino."'>";
	echo "<option value='0'>Elige</option>";
	while($registro=mysql_fetch_assoc($consulta))
	{
		// Convierto los caracteres conflictivos a sus entidades HTML correspondientes para su correcta visualizacion
		$registro[$campo]=($registro[$campo]);
		// Imprimo las opciones del select
		echo "<option value='".$registro[$id]."'>".($registro[$campo])."</option>";
	}			
	echo "</select>";
}
?>