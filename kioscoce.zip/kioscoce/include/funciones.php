<?php
@session_start();
if(!isset($_SESSION['id_user']))
{
	sleep(2);
	header("Location: http://" . $_SERVER['HTTP_HOST'] . dirname($_SERVER['PHP_SELF']) . "index.php");
 echo "Acceso Restringido:<a href='logout.php'> Redireccionar..</a>";
 exit();
}

require_once("conecta.php");
define("RUTA_IMAGENES","img/");
define("IMAGEN_BANNER",RUTA_IMAGENES."sistema_techno_04.jpg");
define("IMAGEN_MOSTRAR",RUTA_IMAGENES."mostrar.jpg");
define("IMAGEN_MODIFICAR",RUTA_IMAGENES."editar.jpg");
define("IMAGEN_ELIMINAR",RUTA_IMAGENES."eliminar.jpg");
echo '<script language="javascript">
		var listadoSelects=new Array();';	

switch($_REQUEST['seccion'])

{
	case x: 
			echo 'listadoSelects[0]="id_marca";
			listadoSelects[1]="id_modelo";';
			break;
	case 8: 
			echo 'listadoSelects[0]="id_marca";
			listadoSelects[1]="id_submarca";';
			break;
			
	case 15: 
			echo 'listadoSelects[0]="id_estado";
			listadoSelects[1]="id_ciudad";';
			break;
	case 17: 
			echo 'listadoSelects[0]="id_estado";
			listadoSelects[1]="id_ciudad";';
			break;			

	case 2: 
			echo 'listadoSelects[0]="id_estado";
			listadoSelects[1]="id_ciudad";';
			break;
}

echo '</script>';



function rellenaSelect($tabla,$indice,$campo,$campo_comparacion,$addOption="")
{
    $salida="";
	$qSelect="SELECT * FROM $tabla WHERE 1";
	$rSelect=mysql_query($qSelect);
	while($dSelect=mysql_fetch_assoc($rSelect))
	{
	 $selected="";
	 if($campo_comparacion==$dSelect[$indice])
	  $selected="selected";
	  $salida.='<option value="'.$dSelect[$indice].'" '.$selected.'>'.$dSelect[$campo].'</option>';
	}
	if($addOption!="")
	  $salida.='<option value="0" selected>'.$addOption.'</option>';	
	return $salida;	
}





// Array que vincula los IDs de los selects declarados en el HTML con el nombre de la tabla donde se encuentra su contenido

if($_REQUEST['seccion']==8)
{
	$listadoSelects=array(
	"id_marca"=>"marca_auto",
	"id_submarca"=>"submarca_auto"
	);
	
	$campo = "id_marca";
}

if($_REQUEST['seccion']==2)

{
	$listadoSelects=array(
	"id_estado"=>"estado",
	"id_ciudad"=>"ciudad"
	);

	$campo = "id_estado";
}


if($_REQUEST['seccion']==15)
{
	$listadoSelects=array(
	"id_estado"=>"estado",
	"id_ciudad"=>"ciudad"
	);

	$campo = "id_estado";
}

if($_REQUEST['seccion']==17)
{
	$listadoSelects=array(
	"id_estado"=>"estado",
	"id_ciudad"=>"ciudad"
	);

	$campo = "id_estado";
}


if($_REQUEST['seccion']==x)

{
	$listadoSelects=array(

	"id_marca"=>"marca",
	"id_modelo"=>"modelo"

	);

	$campo = "id_marca";
}





function validaSelect($selectDestino)

{
	// Se valida que el select enviado via GET exista

	global $listadoSelects;

	if(isset($listadoSelects[$selectDestino])) return true;

	else return false;
}



function validaOpcion($opcionSeleccionada)

{

	// Se valida que la opcion seleccionada por el usuario en el select tenga un valor numerico

	if(is_numeric($opcionSeleccionada)) return true;

	else return false;

}



$selectDestino=$_GET["select"];   $opcionSeleccionada=$_GET["opcion"];   $datoSelect=$_GET["datoSelect"];

if(validaSelect($selectDestino) && validaOpcion($opcionSeleccionada))

{

	$tabla=$listadoSelects[$selectDestino];

	$consulta="SELECT * FROM  ".$listadoSelects[$selectDestino]." WHERE ".$campo." ='$opcionSeleccionada' ";
	if($listadoSelects[$selectDestino] == 'ciudad')
	$consulta.=" ORDER BY nombre ASC";

	$resultado=mysql_query($consulta);

	// Comienzo a imprimir el select

	echo "<select name='".$selectDestino."' id='".$selectDestino."' onChange='cargaContenido(this.id)' class='contenido'>";

	echo "<option value='0'>Elige</option>";

	while($registro=mysql_fetch_row($resultado))

	{

	     $selected="";

		// Convierto los caracteres conflictivos a sus entidades HTML correspondientes para su correcta visualizacion

		$registro[1]=htmlentities($registro[1]);

		// Imprimo las opciones del select

		if($datoSelect==$registro[0])

		  $selected="selected";

		echo "<option value='".$registro[0]."' ".$selected.">".$registro[1]."</option>";

	}			

	echo "</select>";

}







//GENERA EL SELECTED PADRE
function generaContenido($tabla,$id_select,$campo = "",$flagDependiente = true)
{
	$qConsulta	=	"SELECT * FROM $tabla";
	if($tabla == "estado")
	$qConsulta	.=	" ORDER BY nombre ASC";
	
	$consulta=mysql_query($qConsulta);
	// Voy imprimiendo el primer select compuesto por los paises
	if($flagDependiente)
		echo "<select name='".$id_select."' id='".$id_select."' class='contenido' onChange='cargaContenido(this.id,".$_REQUEST['seccion'].")'>";
	else
		echo "<select name='".$id_select."' id='".$id_select."' class='contenido'>";
	echo "<option value='0'>Elige</option>";
	while($registro = mysql_fetch_row($consulta))
	{
	    $selected="";
		if($registro[0]==$campo)
			$selected="selected";
		//else if(!empty($idSeleccionado) && $registro[0] == $idSeleccionado)
		//	$selected="selected";
		echo "<option value='".$registro[0]."' ".$selected.">".$registro[1]."</option>";
	}
	echo "</select>";
}




function reportePendiente()

{

    $mensaje=

	'<form name="form2" method="post" action="admin.php">
	 <table align="center" width="70%">
		<tr>
		  <td colspan="6" class="titulos cabecera" align="center">ASIGNAR TECNICO</td>
	    </tr>		
		<tr>
		  <td colspan="6" ></td>
	    </tr>	
		<tr>
		  <td colspan="6" class="titulos cabecera">REPORTES LEVANTADOS (Sin t�cnico asigando)</td>
	    </tr>
		<tr>
		  <td class="titulos">Id</td>
		  <td class="titulos">Fecha</td>
		  <td class="titulos">Cliente</td>
		  <td class="titulos">Modelo</td>
		  <td class="titulos">Equipo</td>
		  <td class="titulos">Tecnico</td>
	    </tr>';



	$qReporte="SELECT reporte.id_reporte, reporte.fecha_reporte, cliente.nombre, copiadora.numero_serie,copiadora.id_modelo FROM reporte INNER JOIN (cliente INNER JOIN (copiadora INNER JOIN modelo )) ON reporte.id_cliente=cliente.id_cliente AND reporte.id_copiadora=copiadora.id_copiadora AND copiadora.id_modelo=modelo.id_modelo  WHERE reporte.id_tecnico=0";
	$rReporte=mysql_query($qReporte);
	while($dReporte=mysql_fetch_row($rReporte))
	{
	$qModelo="SELECT * FROM modelo WHERE id_modelo=".$dReporte[4]."";
	$rModelo=mysql_query($qModelo);
	$dModelo=mysql_fetch_assoc($rModelo);
	    $mensaje.='		
		 <tr>
		  <td class="titulos">'.$dReporte[0].'</td>
		  <td class="titulos">'.$dReporte[1].'</td>
		  <td class="titulos">'.$dReporte[2].'</td>
		  <td class="titulos">'.$dModelo['nombre'].'</td>
		  <td class="titulos">'.$dReporte[3].'</td>  
		  <td class="titulos" >
		  <select name="id_tecnico[]" class="titulos">
		  '.rellenaSelect("tecnico","id_tecnico","nombre","id_tecnico","Ninguno").'
		  </select><input type="hidden" name="id_reporte[]" value="'.$dReporte[0].'"> 
		  </td>		  
	    </tr>';
	}
	$mensaje.='
	    <tr>
		  <td></td>
		  <td></td>
		  <td></td>
		  <td class="titulos cabecera" align="left"><input type="submit" name="asignar" value="Asignar" class="titulos"></td>
	    </tr>
		</table>
	</form>
';

	echo $mensaje;

}

function reporteFaltaAsignar()
{

    $mensaje=

	'<form name="form" method="post" action="admin.php">

	 <table align="center" width="52%">

		<tr>

		  <td colspan="4" class="titulos cabecera" align="center">AVISOS!!!</td>

	    </tr>		

		<tr>

		  <td colspan="4" ></td>

	    </tr>	

		<tr>

		 <td class="titulos cabecera" align="center">
		  	<a href="admin.php?seccion=3&accion=verpendientes" class="titulos cabecera" title="Ir a asignar t�cnicos">
				<b><font color="#FF0000" size="5">EXISTEN REPORTES SIN TECNICO ASIGNADO</font></b>
			</a>
		</td>

	    </tr>

		<tr>

		  <td height="25" class="titulos"></td>

	    </tr>';	
	$qReporte="SELECT * FROM reporte INNER JOIN (cliente INNER JOIN (copiadora INNER JOIN modelo )) ON reporte.id_cliente=cliente.id_cliente AND reporte.id_copiadora=copiadora.id_copiadora AND copiadora.id_modelo=modelo.id_modelo  WHERE reporte.id_tecnico=0";
	$rReporte=mysql_query($qReporte);
	$mensaje.='	    
		</table>
		</form>';
	if($dReporte=mysql_fetch_row($rReporte))
	{
		echo $mensaje;
	}
}


function mostrarDato($tabla, $indice,$valorIndice, $campos="*")
{	
	$q="SELECT $campos FROM $tabla WHERE $indice=$valorIndice";
	$r=mysql_query($q);
	$d=mysql_fetch_assoc($r);
	return $d;
}

function muestraFecha($fecha)
{
	$meses=array("Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic");
	$cadena=explode("-",$fecha);
	if($cadena[1]==00)
	//return $formato="Fecha inv�lida";	
	return $formato="No tiene veh�culo asignado";
	return $formato=$cadena[2]."-".$meses[$cadena[1]-1]."-".$cadena[0];
}

function fecha_letras($fecha)
{
	if(empty($fecha))
		return "No aplica";
	$meses	=	array(" ","Ene","Feb","Mar","Abr","May","Jun","Jul","Ago","Sep","Oct","Nov","Dic");
	$letra	=	explode("-", $fecha);
	$mes	=	num_mes($fecha);
	$anio=$letra[0]{2}.$letra[0]{3};
	$nueva_fecha	=	$letra[2]."/".$letra[1]."/".$letra[0];
	return $nueva_fecha;
}

function cortaCadena($cadena,$longitud)
{
	$texto=substr($cadena,0,$longitud);
	return $texto;
}

function num_mes($fecha){

$meses_m = explode("-", $fecha);

   	$m =  $meses_m[1];
	$posicion = strpos($m,'0');
	
	if($posicion === false || $posicion == 1)
	return	$m =  $meses_m[1];
	else{
		$dias_d	=	explode(0,$m);
	return	$m =  $dias_d[1];
    }

}
?>