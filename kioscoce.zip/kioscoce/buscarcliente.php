<?php
error_reporting (E_ALL & ~E_STRICT ^ E_NOTICE );
session_start();
$cliente =$_POST['cliente'];
$var=explode("-",$cliente);
$rfc=$var[0];

  include("include/conecta.php");
  
  $sql=mysql_query("select id_cliente,rfc,nombre from clientes where rfc='$rfc'");
  $dDatos=@mysql_fetch_assoc($sql);
  
  if(!empty($dDatos['rfc'])){
  $jsondata['valido']=1;
  $jsondata['rfc']=$dDatos['rfc'];;
  $_SESSION['rfc'] =$dDatos['rfc'];
  }else{ 
  $jsondata['valido']=0;
 // $_SESSION['rfc'] =$rfc;  
  }
 
  $jsondata['rfc']=$dDatos['rfc'];
  echo json_encode($jsondata);
  @mysql_close($db_link);
?>