<?php

	
if(isset($_POST['cveest'])&& isset($_POST['password']))
	
{
 
	 	  
require_once('config.inc_fa_33.php');
		  

$password =$_POST['password'];
$cveest =$_POST['cveest'];
         


$sql = "SELECT despachadores.id FROM `despachadores` left outer join `estaciones` on estaciones.id=despachadores.id_estacion where despachadores.nip='$password' and estaciones.pemex='$cveest' ";
  
$statement = $connection->prepare($sql);
		  
$statement->bindParam(':password',$password, PDO::PARAM_STR);
 
$statement->bindParam(':cveest',$cveest, PDO::PARAM_STR);
          
$statement->execute();
          
if($statement->rowCount())
          {
				
$row_all = $statement->fetchall(PDO::FETCH_ASSOC);
				
header('Content-type: application/json');
   		  		
echo json_encode($row_all);
          		
         
 }  
         
 elseif(!$statement->rowCount())
         
 {
			 
 echo "no rows";         
 }
	
}
		
  
?>
