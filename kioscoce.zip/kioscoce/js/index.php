<?
header("location: ../index.php");
?>
