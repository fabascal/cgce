<?php
(int) $id =1;// $_GET['id'];
if($id > 0) {
   process($id);
  }
 
function process($id) {
   $db = mysql_connect('localhost', 'estrella_co', 'CAcuestrella');
   if (!$db) {
     die('Could not connect: ' . mysql_error());
    }
   if (!mysql_select_db('admin_co')) {
     die('Could not select database: ' . mysql_error());
    }   
   $result = mysql_query("SELECT * FROM usuario WHERE id_usuario=".$id);
   if (!$result) {
     die('Could not query:' . mysql_error());
    }
 
   $row = mysql_fetch_object($result);
   $jsondata['numvale'] = $row->id_usaurio;
  
 
   echo json_encode($jsondata);
   mysql_close($db);
 }
echo process();

 
?>