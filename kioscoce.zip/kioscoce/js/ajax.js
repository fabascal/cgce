function restults(data) {
    // $("div.info").show();

	document.getElementById('numtel_busca').value=''; 
	document.getElementById('name_tel').value=data.nombre; 
	document.getElementById('numtel').value=data.numtel; 
   
    
 }
 
 function restults1(data) {
  var compara =document.getElementById('nombre1').value;  
  var nombre2=data.nombre2;
  var nombre=data.nombre1;  
 

 if (data.nombre2==compara )  {
alert (" [ "+data.nombre2+" ] "+"\n\n"+"Y A   E S T A   C A P T U R A D O   "+"\n"+"F A V O R   D E   V E R I F I C A R");
 document.getElementById('nombre1').value=''; 
 }else{
    if (data.nombre1==null || data.nombre1=='' )  {
		
		
		
	}else{
		
		
		function restults5(data) {
    // $("div.info").show();

	document.getElementById('numtel_busca').value=''; 
	document.getElementById('nombre1').value=data.nombre1; 
	document.getElementById('numtel').value=data.numtel; 
   
    
 }
		
    var algo= document.getElementById('nombre1').value;

	 	
		 fb.start('nombres.php?nombre1='+algo, 'width:700 height:500 scrolling:si innerBorder:3 contentBackgroundColor:#ffffe7 colorTheme:yellow padding:12 cornerRadius:4 enableDragResize:true scrolling:si  disableScroll:false modal:false  caption:`Colaboradores` showClose:false showOuterClose:false' );
        

	 
	 }
	// alert (data.nombre1);  ESTE AJAX ES PARA VERIFICAR SI YA EXISTE EL NOMBRE
	//document.getElementById('nombre').value=data.nombre1;  
 }
 }
 
 
$(document).ready(function(){
$("#numtel_busca").blur(function(){
  $.ajax({
    data: "numtel="+document.getElementById('numtel_busca').value,
    type: "GET",
    dataType: "json",
    url: "numtel.php",
    success: function(data){
       restults(data);
     }
   });
  });

$("#nombre1").blur(function(){
  $.ajax({
    data: "nombre1="+document.getElementById('nombre1').value,
    type: "GET",
    dataType: "json",
	url: "nombre_col.php",
	success: function(data){
    restults1(data);
     }
	 
   });
  });



});