// JavaScript Document
function restults(data) {
    // $("div.info").show();
	//alert(data.telcasa);
	document.getElementById('interior').value=data.interior;

	
 }
$(document).ready(function(){
$("#compara1").blur(function(){
  $.ajax({
    data: "interior="+document.getElementById('compara1').value,
    type: "GET",
    dataType: "json",
    url: "valida_interior.php",
    success: function(data){
       restults(data);
     }
   });
  });
});