// JavaScript Document

fb.DOMReady(function() {
	var menu = fb$('main_menu'),
		lis = [], li,
		kids = menu.childNodes,
		i = kids.length;
	while (i--) {
		li = kids[i];
		if (li.nodeName === 'LI') {
			li.onmouseover = function() {
				setActive(this);
			};
			li.onmouseout = function() {
				clearActive();
			};
			li.ontouchstart = function() {
				this.onmouseover = this.onmouseout = null;
				setActive(this);
			};
			lis.push(li);
		}
	}
	fb.addEvent(document, 'touchstart', function(e) {
		if (!fb.nodeContains(menu, e.target)) clearActive();
	});
	function setActive(li) {
		clearActive();
		if (!/active/.test(li.className)) li.className += (li.className ? ' ' : '') + 'active';
	}
	function clearActive() {
		var i = lis.length;
		while (i--) lis[i].className = lis[i].className.replace(/\s?active/g, '');
	}
	
	var links = menu.getElementsByTagName('A'),
		link, li,
		i = links.length;
	while (i--) {
		link = links[i];
		if (links[i].href.indexOf(location.href) > -1) {
			li = link.parentNode.parentNode.parentNode;
			if (li.nodeName !== 'LI') li = link.parentNode;
			li.className += (li.className ? ' ' : '') + 'current';
			break;
		}
	}

});