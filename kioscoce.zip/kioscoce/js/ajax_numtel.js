// JavaScript Document
function restults(data) {
    // $("div.info").show();
	//alert(data.telcasa);
	document.getElementById('existe').value=data.telcasa;
	document.getElementById('nombre1').value=data.nombre1;
	document.getElementById('numcol').value=data.numcol;
	document.getElementById('tipo').value=data.tipo;
	
 }
$(document).ready(function(){
$("#compara").blur(function(){
  $.ajax({
    data: "telcasa="+document.getElementById('compara').value,
    type: "GET",
    dataType: "json",
    url: "valida_telefono.php",
    success: function(data){
       restults(data);
     }
   });
  });
});