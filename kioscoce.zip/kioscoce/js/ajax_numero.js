// JavaScript Document
function restults(data) {
    // $("div.info").show();
	//alert(data.telcasa);
	document.getElementById('exterior').value=data.exterior;

	
 }
$(document).ready(function(){
$("#compara1").blur(function(){
  $.ajax({
    data: "exterior="+document.getElementById('compara1').value,
    type: "GET",
    dataType: "json",
    url: "valida_exterior.php",
    success: function(data){
       restults(data);
     }
   });
  });
});