function restults(data) {
	var numcol=data.numcol;
	 
	if (numcol=='' || numcol==null){
		 
    document.getElementById('nombre2').value='';
	document.getElementById('numcol2').value='';
  	document.getElementById('nombre1').value=''; 
	document.getElementById('num').value=''; 
	document.getElementById('domicilio1').value='';
	document.getElementById('telcasa').value='';
	document.getElementById('exterior').value='';
	document.getElementById('colonia').value='';
	document.getElementById('municipio').value='';
	document.getElementById('guardar').disabled = true; 	 
		 
			 alert ("No se encontraron Coincidencias trate de nuevo");
			
		}else{ 
	
	document.getElementById('numcol2').value='';
	document.getElementById('nombre2').value='';
  	document.getElementById('nombre1').value=data.nombre1; 
	document.getElementById('num').value=data.numcol; 
	document.getElementById('numcol').value=data.numcol;
	document.getElementById('domicilio1').value=data.domicilio1;
	document.getElementById('telcasa').value=data.telcasa;
	document.getElementById('exterior').value=data.exterior;
	document.getElementById('colonia').value=data.colonia;
	document.getElementById('municipio').value=data.municipio; 
	document.getElementById('guardar').disabled = false; 
             }

    
 
    
 }
 
 function restults1(data) {
	 
	var nombre=data.nombre1;
	 
	if (nombre=='' || nombre==null){
	document.getElementById('guardar').disabled = true; 	 
			 alert ("No se encontraron Coincidencias trate de nuevo");
			
    document.getElementById('numcol2').value=''; 
	document.getElementById('nombre2').value='';
  	document.getElementById('nombre1').value=''; 
	document.getElementById('num').value=''; 
	document.getElementById('domicilio1').value='';
	document.getElementById('telcasa').value='';
	document.getElementById('exterior').value='';
	document.getElementById('colonia').value='';
	document.getElementById('municipio').value='';
		
		
		}else{ 
	document.getElementById('guardar').disabled = false; 
	document.getElementById('numcol2').value='';
	document.getElementById('nombre2').value='';
  	document.getElementById('nombre1').value=data.nombre1; 
	document.getElementById('num').value=data.numcol; 
	document.getElementById('numcol').value=data.numcol;
	document.getElementById('domicilio1').value=data.domicilio1;
	document.getElementById('telcasa').value=data.telcasa;
	document.getElementById('exterior').value=data.exterior;
	document.getElementById('colonia').value=data.colonia;
	document.getElementById('municipio').value=data.municipio; 
             }

 }
 
 
$(document).ready(function(){
$("#numcol2").blur(function(){
  $.ajax({
    data: "numcol="+document.getElementById('numcol2').value,
    type: "GET",
    dataType: "json",
    url: "busca_num.php",
    success: function(data){
       restults(data);
     }
   });
  });

$("#nombre2").blur(function(){
  $.ajax({
    data: "nombre1="+document.getElementById('nombre2').value,
    type: "GET",
    dataType: "json",
	url: "busca_nombre.php",
	success: function(data){
    restults1(data);
     }
	 
   });
  });



});