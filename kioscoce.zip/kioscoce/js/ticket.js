// JavaScript Document

$(function(){

	$("#imprime").click(function (){
	$("div#myPrintArea").printArea();
	});
	 document.getElementById('muestraticket').style.display="none"; 

	
	$('#button').click(function(){
     
	 $('#tickets input').removeClass('error').removeClass('valid');
	 $('#tickets select').removeClass('error').removeClass('valid');
	 
	
        var fields = $('#tickets input[type=text],select');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
       if( value.length<1 || value==fields[$(this).attr('id')]  ) {
          // alert ([$(this).attr('id')])
			    $(this).addClass('error');
               // $(this).effect("shake", { times:3 }, 50);
                
                error++;
            } else {
                $(this).addClass('valid');
            }
        });
	  if(!error) {
 	    
			 var nticket=$("#nticket").val();
			 var id_estacion=$("#id_estacion").val();

			
			  function restults(datar) {
				
				if(datar.mensaje!=1){
				alert (datar.mensaje);
				document.getElementById('nticket').value=""; 
				document.getElementById('id_estacion').options.selectedIndex = 0;
				$('#tickets select').removeClass('error').removeClass('valid');
				 $.unblockUI();
				}else{
				$.unblockUI();
				document.getElementById('nticket').value=""; 
				document.getElementById('id_estacion').options.selectedIndex = 0;
				$('#tickets select').removeClass('error').removeClass('valid'); 
				document.getElementById('muestraticket').style.display="block";
				$('#fecha').text(datar.fecha);
				$('#unitario').text(datar.unitario);
				$('#folio').text(datar.folio);
				$('#cantidad').text(datar.cantidad);
				$('#monto').text(datar.monto);
				$('#estacion').text(datar.estacion);
				$('#letras').text(datar.letras);
				$('#empresa').text(datar.empresa);
				$('#cveest').text(datar.cveest);
				$('#dom').text(datar.dom);
				$('#col').text(datar.col);
				$('#rfc').text(datar.rfc);
				$('#tel').text(datar.tel);
				}
			   }
 
            $.ajax({
            data: "nticket="+nticket+'&id_estacion='+id_estacion,
            type: "POST",
            dataType: "json",
            url: "buscaticket.php",
	        beforeSend: function(){
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
  
        } else return false;
	 
    });
	
	
$('#buscarticket').click(function(){
     
	 $('#tickets input').removeClass('error').removeClass('valid');
	 $('#tickets select').removeClass('error').removeClass('valid');
	 
	
        var fields = $('#tickets input[type=text],select');
        var error = 0;
        fields.each(function(){
            var value = $(this).val();
       if( value.length<1 || value==fields[$(this).attr('id')]  ) {
          // alert ([$(this).attr('id')])
			    $(this).addClass('error');
               // $(this).effect("shake", { times:3 }, 50);
                
                error++;
            } else {
                $(this).addClass('valid');
            }
        });
	  if(!error) {
 	    
			 var nticket=$("#nticket").val();
			 var id_estacion=$("#id_estacion").val();

			
			  function restults(datar) {
				
				if(datar.mensaje!=1){
				alert (datar.mensaje);
				document.getElementById('nticket').value=""; 
				document.getElementById('id_estacion').options.selectedIndex = 0;
				$('#tickets select').removeClass('error').removeClass('valid');
				 $.unblockUI();
				}else{
				$.unblockUI();
				document.getElementById('nticket').value=""; 
				document.getElementById('id_estacion').options.selectedIndex = 0;
				$('#tickets select').removeClass('error').removeClass('valid'); 
				document.getElementById('muestraticket').style.display="block";
				$('#fecha').text(datar.fecha);
				$('#unitario').text(datar.unitario);
				$('#folio').text(datar.folio);
				$('#cantidad').text(datar.cantidad);
				$('#monto').text(datar.monto);
				$('#estacion').text(datar.estacion);
				$('#letras').text(datar.letras);
				$('#empresa').text(datar.empresa);
				$('#cveest').text(datar.cveest);
				$('#dom').text(datar.dom);
				$('#col').text(datar.col);
				$('#rfc').text(datar.rfc);
				$('#tel').text(datar.tel);
				}
			   }
 
            $.ajax({
            data: "nticket="+nticket+'&id_estacion='+id_estacion,
            type: "POST",
            dataType: "json",
            url: "buscaticket.php",
	        beforeSend: function(){
			 $.blockUI({ message: $('#loading') });  
            },
	        success: function(datar){
            restults(datar);
            }
	        }).done(function() {
              $.unblockUI(); 
           });
 
  
        } else return false;
	 
    });
	
});