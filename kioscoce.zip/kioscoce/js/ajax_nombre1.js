// JavaScript Document
function restults(data) {
    // $("div.info").show();
   // alert ("hola");
	 alert (data.nombre1);
	document.getElementById('nombre1').value=data.nombre1;  
	//document.getElementById('tipo').value=data.tipo; 
	//document.getElementById('numcol').value=data.numcol; 
   
    
 }
$(document).ready(function(){
$("#nombre1").blur(function(){
  $.ajax_nombre1({
    data: "nombre1="+document.getElementById('nombre1').value,
    type: "GET",
    dataType: "json",
    url: "nombre_col.php",
    success: function(data){
       restults(data);
     }
   });
  });
});