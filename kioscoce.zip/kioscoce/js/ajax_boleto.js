// JavaScript Document
function restults(data) {
 
	
		document.getElementById('numboleto').value=data.numboleto;
		document.getElementById('radio').value=data.radio;
	  //  alert(data.numboleto+data.radio);
	
 }
$(document).ready(function(){
$("#boleto").blur(function(){
  $.ajax({
    data: "boleto="+document.getElementById('boleto').value+"&radio="+document.getElementById('radio').value,
    type: "GET",
    dataType: "json",
    url: "procesar.php",
    success: function(data){
       restults(data);
     }
   });
  });
});
