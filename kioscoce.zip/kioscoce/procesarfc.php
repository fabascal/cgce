<?php
error_reporting (E_ALL & ~E_STRICT ^ E_NOTICE );
@session_start();
$id_cliente =trim($_POST['id_cliente']);
$rfc =strtoupper(trim($_POST['rfc']));
$nombre =addslashes(strtoupper(trim($_POST['nombre'])));
$correo =trim($_POST['correo']);
$telefono =trim($_POST['telefono']);
$calle =strtoupper(trim($_POST['calle']));
$exterior =trim($_POST['exterior']);
$interior =trim($_POST['interior']);
$cp =trim($_POST['cp']);
$colonia =strtoupper(trim($_POST['colonia']));
$localidad =strtoupper(trim($_POST['localidad']));
$municipio =strtoupper(trim($_POST['municipio']));
$pais =strtoupper(trim($_POST['pais']));
$id_estado =trim($_POST['id_estado']);
$fecha_alta=date("Y-m-d H:i:s");


  include("include/conecta.php");
  
$rf=mysql_query("select rfc from clientes where rfc='$rfc'"); 
$f=mysql_fetch_assoc($rf); 
  
  if (empty($f['rfc'])){
  $sql=mysql_query("insert into clientes (rfc,nombre,correo,telefono,fecha_alta)value ('$rfc','$nombre','$correo','$telefono','$fecha_alta')");
  $id_cliente=mysql_insert_id();
  unset($_SESSION['rfc2']);
  }else{
  $sql=mysql_query("update clientes set nombre='$nombre',correo='$correo',telefono='$telefono',fecha_modificacion='$fecha_alta' where rfc='$rfc'");	   
  }
  $sql=mysql_query("insert into domicilio (id_cliente,calle,exterior,interior,cp,colonia,localidad,municipio,pais,id_estado,fecha_alta)value('$id_cliente','$calle','$exterior','$interior','$cp','$colonia','$localidad','$municipio','$pais','$id_estado','$fecha_alta') ");   
	 
	$_SESSION['rfc'] = $rfc;
	$_SESSION['progreso']=2; 

  echo json_encode($jsondata);
  @mysql_close($db_link);
?>