package com.epson.epos2_germanyfiscalelement;

public class PurchaseItems {
    private String itemCode;
    private String itemName;
    private float itemValue;
    private int itemCount;

    public PurchaseItems initItem(String itemCode, String itemName, float itemValue)
    {
        if(itemCode != null) {
            this.itemCode = itemCode;
        }
        if(itemName != null) {
            this.itemName = itemName;
        }
        this.itemValue = itemValue;
        this.itemCount = 0;
        return this;
    }

    public void setItemCode(String itemCode)
    {
        if(itemCode != null) {
            this.itemCode = itemCode;
        }
    }

    public String getItemCode()
    {
        return this.itemCode;
    }


    public void setItemName(String itemName)
    {
        if(itemName != null) {
            this.itemName = itemName;
        }
    }

    public String getItemName()
    {
        return this.itemName;
    }


    public void setItemValue(float itemValue)
    {
        this.itemValue = itemValue;
    }

    public float getItemValue()
    {
        return this.itemValue;
    }

    public  void setItemCount(int itemCount)
    {
        this.itemCount = itemCount;
    }

    public int getItemCount()
    {
        return this.itemCount;
    }
}
