package com.epson.epos2_germanyfiscalelement;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ScrollView;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.concurrent.Semaphore;
import org.json.JSONObject;

import com.epson.epos2.germanyfiscalelement.GermanyFiscalElement;

import static com.epson.epos2_germanyfiscalelement.MainActivity.targetGermanyFiscalElement;

public class AuditingFragment extends GermanyFiscalElementFragment  implements View.OnClickListener{

    private View rootView;
    private Button mBtnOutput = null;
    private Object queueForSDK = null;
    private Semaphore gfeSemaphore = null;
    public Epos2SdkMgr sdkManager = null;
    public Epos2SdkMgrListener sdkMgrListener = null;
    private String challenge = "";
    private boolean isAllExportData = false;
    private int responseLimitTime = 10000;


    public static AuditingFragment newInstance() {
        return new AuditingFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_auditing, container, false);
        mBtnOutput = rootView.findViewById(R.id.btnOutput);
        mBtnOutput.setOnClickListener(this);
        return rootView;
    }

    @Override
    public void onDestroyView() {
        destroyAuditingFragment();
        super.onDestroyView();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        if(rootView != null){
            if (isVisibleToUser) {
                initializeAuditingFragment();
            } else {
                destroyAuditingFragment();
            }
        }
    }
    public void initializeAuditingFragment(){
        mTextGermanyFiscalElement = rootView.findViewById(R.id.textView_auditingText);
        mScrollView = rootView.findViewById(R.id.scrollView_auditing);
        gfeSemaphore = new Semaphore(1);
        queueForSDK = new Object();
        sdkMgrListener = new Epos2SdkMgrListener();
        sdkMgrListener.setListener(this);
        sdkManager = Epos2SdkMgr.newInstance(sdkMgrListener);

        synchronized (queueForSDK){
            sdkManager.initializeGfeObject(getActivity());
        }
    }

    public void destroyAuditingFragment(){
        mTextGermanyFiscalElement.setText("");
        gfeSemaphore =null;
        queueForSDK = null;
        gfeSemaphore = null;
        if(sdkMgrListener != null){
            sdkMgrListener.removeListener();
            sdkMgrListener.setListener(null);
            sdkMgrListener = null;
        }
        challenge = null;
        sdkManager = null;

    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btnOutput:
                onOutput();
                break;
            default:
                // Do nothing
                break;
        }
    }

    private void onOutput(){
        new Thread (() -> {
            synchronized (queueForSDK) {
                beginProgress(getActivity().getString(R.string.progress_msg));

                boolean result = sdkManager.connectGermanyFiscalElement(targetGermanyFiscalElement);
                if(result == true){
                    isAllExportData = false;
                    result = operateAuthenticateUserForAdmin();
                    if(result == true) {
                        result = operateUpdateTime();
                        if (result == true) {
                            result = operateArchiveExport();
                            if (result == true) {
                                operateGetExportData();
                                operateFinalizeExport();
                            }
                        }
                        operateLogOutForAdmin();
                    }
                    if (result == true) {
                        operateGetLogMessageCertificate();
                    }
                    sdkManager.disconnectGermanyFiscalElement();
                }
                endProgress();
            }
        }).start();
    }

    private boolean operateAuthenticateUserForAdmin()
    {
        // GetChallenge
        boolean result = operateGetChallenge(sdkManager, getString(R.string.administrator));
        if(result == true) {
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName());
            if(result == true) {
                // Hash calculationTime
                String secretKey = getString(R.string.secretKey);
                String input = challenge + secretKey;
                String hash = calculateHash(input);

                result = operateAuthenticateUserForAdmin(sdkManager, hash);
                if(result == true) {
                    result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName());
                }
            }
        }
        return result;
    }

    private boolean operateLogOutForAdmin()
    {
        boolean result = operateLogOutForAdmin(sdkManager);
        if(result == true) {
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName());
        }
        return result;
    }

    private boolean operateArchiveExport()
    {
        String jsonFunc_tmp= getString(R.string.operate_func_archiveExport);
        String userId = getString(R.string.administrator);

        String jsonFunc_archiveExport = String.format(jsonFunc_tmp, userId);
        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_archiveExport, GermanyFiscalElement.PARAM_DEFAULT, getActivity());
        if(result == true) {
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName());
        }
        return result;
    }

    private boolean operateGetExportData()
    {
        String jsonFunc_tmp= getString(R.string.operate_func_getExportData);
        String userId = getString(R.string.administrator);

        String jsonFunc_getExportData = String.format(jsonFunc_tmp, userId);
        boolean result = true;
        while (!isAllExportData) {
            result = sdkManager.operateGermanyFiscalElement(jsonFunc_getExportData, GermanyFiscalElement.PARAM_DEFAULT, getActivity());
            if(result == true) {
                result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName());
            }
        }

        return result;
    }

    private boolean operateFinalizeExport()
    {
        String jsonFunc_tmp= getString(R.string.operate_func_finalizeExport);
        String userId = getString(R.string.administrator);

        String jsonFunc_finalizeExport = String.format(jsonFunc_tmp, userId);

        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_finalizeExport, GermanyFiscalElement.PARAM_DEFAULT, getActivity());
        if(result == true) {
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName());
        }
        return result;
    }

    private boolean operateGetLogMessageCertificate() {
        String jsonFunc_getLogMessageCertificate = getString(R.string.operate_func_getLogMessageCertificate);
        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_getLogMessageCertificate, GermanyFiscalElement.PARAM_DEFAULT, getActivity());
        if (result == true) {
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName());
        }
        return result;
    }

    private boolean operateUpdateTime()
    {
        String jsonFunc_tmp = getString(R.string.operate_func_updateTime);
        String userId = getString(R.string.administrator);
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ss'Z'");
        String newDateTime = formatter.format(date);

        String jsonFunc_updateTime = String.format((String)jsonFunc_tmp, userId, newDateTime);

        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_updateTime, GermanyFiscalElement.PARAM_DEFAULT, getActivity());
        if(result == true){
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName());
        }
        return result;
    }

    private boolean waitCallbackEvent(String method){
        boolean result = true;
        synchronized (gfeSemaphore) {
            try {
                gfeSemaphore.wait(responseLimitTime);
            } catch (Exception e) {
                sdkManager.showError(getActivity().getString(R.string.error_msg), method);
                result = false;
            }
        }
        return result;
    }

    @Override
    public void onGfeReceiveEPOS2SDKManager(final GermanyFiscalElement GfeObj, final int code, final String data){
        String viewText = String.format("onGfeReceive:\n");
        viewText += String.format("  code:%s\n", sdkManager.getEposErrorText(code));
        viewText += String.format("  data:%s\n", data);
        appendTextView(viewText);

        JSONObject json = parseJson(data);
        String result = getJsonString(json, "result");
        if(result.equals("EXECUTION_OK")) {
            String function = getJsonString(json, "function");

            if(function.equals("GetChallenge")) {
                String tmpChallenge = getJsonString(getJsonOutputInfo(json), "challenge");
                if(tmpChallenge != null){
                    challenge = tmpChallenge;
                }
            }

            if(function.equals("GetExportData")) {
                String exportStatus = getJsonString(getJsonOutputInfo(json), "exportStatus");
                if(exportStatus.equals("EXPORT_COMPLETE")){
                    isAllExportData = true;
                }
            }
        }
        synchronized (gfeSemaphore){
            gfeSemaphore.notify();
        }
    }

    @Override
    public void onLogEPOS2SDKManager(final String apiLog){
        if(apiLog != null){
            appendTextView(apiLog);
        }
    }

    private void appendTextView(String text){
        if(text == null){
            return;
        }
        getActivity().runOnUiThread(new Runnable() {
            public synchronized void run() {
                mTextGermanyFiscalElement.append(text);
                mScrollView.post(new Runnable(){
                    public void run()
                    {
                        mScrollView.fullScroll(ScrollView.FOCUS_DOWN);
                    }
                });
            }
        });
    }
}
