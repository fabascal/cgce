package com.epson.epos2_germanyfiscalelement;

import com.epson.epos2.barcodescanner.BarcodeScanner;
import com.epson.epos2.discovery.DeviceInfo;
import com.epson.epos2.germanyfiscalelement.GermanyFiscalElement;
import com.epson.epos2.linedisplay.LineDisplay;
import com.epson.epos2.printer.FirmwareInfo;
import com.epson.epos2.printer.Printer;
import com.epson.epos2.printer.PrinterStatusInfo;
import java.util.ArrayList;

public interface Epos2SdkMgrListenerInterface {
    void onDiscoveryResult(final DeviceInfo deviceInfo);
    void onGfeReceiveEPOS2SDKManager(final GermanyFiscalElement GfeObj, final int code, final String printJobId);
    void onPtrReceiveResult(final Printer printerObj, final int code, final PrinterStatusInfo status, final String printJobId);
    void onFirmwareListDownloadResult(final int code, FirmwareInfo[]firmwareList);
    void onFirmwareInformationReceiveResult(FirmwareInfo firmwareInfo);
    void onFirmwareUpdateProgressResult(String task, float progress);
    void onFirmwareUpdateResult(final int code, int maxWaitTime);
    void onUpdateVerifyResult(final int code);
    void onDispReceiveResult(final LineDisplay LineDisplayObj, final int code);
    void onScanDataResult(final BarcodeScanner scanObj, final String data);
    void onLogEPOS2SDKManager(final String apiLog);
    void onConnectionResult(final Object printerObj, final int code);
}
