package com.epson.epos2_germanyfiscalelement;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ScrollView;

import java.util.concurrent.Semaphore;

import com.epson.epos2.germanyfiscalelement.GermanyFiscalElement;
import static com.epson.epos2_germanyfiscalelement.MainActivity.targetGermanyFiscalElement;

public class StorageInfoFragment extends GermanyFiscalElementFragment implements View.OnClickListener {

    private View rootView;
    private Button mBtnOutput = null;
    private Object queueForSDK = null;
    private Semaphore gfeSemaphore = null;
    public Epos2SdkMgr sdkManager = null;
    public Epos2SdkMgrListener sdkMgrListener = null;
    private int responseLimitTime = 10000;

    public static StorageInfoFragment newInstance() {
        return new StorageInfoFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_storageinfo, container, false);
        mBtnOutput = rootView.findViewById(R.id.btnStorageInfo);
        mBtnOutput.setOnClickListener(this);
        return rootView;
    }
    @Override
    public void onDestroyView() {
        destroyStorageInfoFragment();
        super.onDestroyView();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        if(rootView != null){
            if (isVisibleToUser) {
                initializeStorageInfoFragment();
            } else {
                destroyStorageInfoFragment();
            }
        }
    }
    public void initializeStorageInfoFragment(){
        mTextGermanyFiscalElement = rootView.findViewById(R.id.textView_storageInfoText);
        mScrollView = rootView.findViewById(R.id.scrollView_storageInfo);
        gfeSemaphore = new Semaphore(1);
        queueForSDK = new Object();
        sdkMgrListener = new Epos2SdkMgrListener();
        sdkMgrListener.setListener(this);
        sdkManager = Epos2SdkMgr.newInstance(sdkMgrListener);

        synchronized (queueForSDK){
            sdkManager.initializeGfeObject(getActivity());
        }
    }

    public void destroyStorageInfoFragment(){
        mTextGermanyFiscalElement.setText("");
        gfeSemaphore =null;
        queueForSDK = null;
        gfeSemaphore = null;
        if(sdkMgrListener != null){
            sdkMgrListener.removeListener();
            sdkMgrListener.setListener(null);
            sdkMgrListener = null;
        }
        sdkManager = null;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btnStorageInfo:
                onGetStorageInfo();
                break;
            default:
                // Do nothing
                break;
        }
    }

    private void onGetStorageInfo(){
        new Thread (() -> {
            synchronized (queueForSDK) {
                beginProgress(getActivity().getString(R.string.progress_msg));
                if(sdkManager.connectGermanyFiscalElement(targetGermanyFiscalElement)){
                    String jsonFunc_getStorageInfo = getString(R.string.operate_func_getStorageInfo);
                    if(sdkManager.operateGermanyFiscalElement(jsonFunc_getStorageInfo, GermanyFiscalElement.PARAM_DEFAULT, getActivity()))
                    {
                        synchronized (gfeSemaphore) {
                            try {
                                gfeSemaphore.wait(responseLimitTime);
                            } catch (Exception e) {
                                sdkManager.showError(getActivity().getString(R.string.error_msg), new Object() {
                                }.getClass().getEnclosingMethod().getName());
                            }
                        }
                    }
                    sdkManager.disconnectGermanyFiscalElement();
                }
                endProgress();
            }
        }).start();
    }

    @Override
    public void onGfeReceiveEPOS2SDKManager(final GermanyFiscalElement GfeObj, final int code, final String data){
        String viewText = String.format("onGfeReceive:\n");
        viewText += String.format("  code:%s\n", sdkManager.getEposErrorText(code));
        viewText += String.format("  data:%s\n", data);
        appendTextView(viewText);

        synchronized (gfeSemaphore){
            gfeSemaphore.notify();
        }
    }

    @Override
    public void onLogEPOS2SDKManager(final String apiLog){
        if(apiLog != null){
            appendTextView(apiLog);
        }
    }

    private void appendTextView(String text){
        if(text == null){
            return;
        }
        getActivity().runOnUiThread(new Runnable() {
            public synchronized void run() {
                mTextGermanyFiscalElement.append(text);
                mScrollView.post(new Runnable(){
                    public void run()
                    {
                        mScrollView.fullScroll(ScrollView.FOCUS_DOWN);
                    }
                });
            }
        });
    }
}
