package com.epson.epos2_germanyfiscalelement;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import com.epson.epos2.Epos2CallbackCode;
import com.epson.epos2.barcodescanner.BarcodeScanner;
import com.epson.epos2.discovery.*;
import com.epson.epos2.Epos2Exception;
import com.epson.epos2.printer.*;
import com.epson.epos2.linedisplay.*;
import com.epson.epos2.germanyfiscalelement.*;
import com.epson.epos2.barcodescanner.*;
import com.epson.epos2.ConnectionListener;


public class Epos2SdkMgr {

    private static final int DISPLAY_LINE_MAX = 20;
    private Printer mPrinter = null;
    private LineDisplay mLineDisplay = null;
    private GermanyFiscalElement mGermanyFiscalElement = null;
    private BarcodeScanner mBarcodeScanner = null;
    private Epos2SdkMgrListener sdkMgrListener = null;

    public static Epos2SdkMgr newInstance(Epos2SdkMgrListener listener ) {
        return new Epos2SdkMgr(listener);
    }

    public Epos2SdkMgr(Epos2SdkMgrListener listener){
        this.sdkMgrListener = listener;
    }

    //Note:If you call "start" API, please call "stop" API.
    //After calling "start" API, you should not call any API in ePOS-SDK until you call "stop" API.
    public boolean startDiscovery(Context context, FilterOption option) {
        int errCode = 0;
        boolean result = true;
        try {
            Discovery.start(context, option, mDiscoveryListener);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean stopDiscovery() throws Epos2Exception {
        int errCode = 0;
        boolean result = true;
        try {
            Discovery.stop();
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public DiscoveryListener mDiscoveryListener = new DiscoveryListener() {
        @Override
        public void onDiscovery(final DeviceInfo deviceInfo) {
            sdkMgrListener.onDiscovery(deviceInfo);
        }
    };

    public boolean initializeGfeObject(Context context) {
        int errCode = 0;
        boolean result = true;
        if(mGermanyFiscalElement != null){
            finalizeGfeObject();
        }
        try {
            mGermanyFiscalElement = new GermanyFiscalElement(context);
            mGermanyFiscalElement.setReceiveEventListener(mGfeReceiveListener);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public void finalizeGfeObject() {
        if (mGermanyFiscalElement == null) {
            return;
        }
        mGermanyFiscalElement.setReceiveEventListener(null);
        mGermanyFiscalElement = null;
    }

    public boolean connectGermanyFiscalElement(String target) {
        int errCode = 0;
        boolean result = true;
        if (mGermanyFiscalElement == null) {
            return false;
        }
        try {
            mGermanyFiscalElement.connect(target, Printer.PARAM_DEFAULT);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean disconnectGermanyFiscalElement() {
        int errCode = 0;
        boolean result = true;
        int count = 0;
        if (mGermanyFiscalElement == null) {
            return false;
        }

        do{
            try {
                count++;
                mGermanyFiscalElement.disconnect();
                result = true;
            } catch (Epos2Exception e) {
                errCode = e.getErrorStatus();
                result = false;
                if(errCode == Epos2Exception.ERR_PROCESSING){
                    try{Thread.sleep(500);}catch(Exception ex){}
                }
            }
            showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        }while(errCode == Epos2Exception.ERR_PROCESSING && count <= 4);
        return result;
    }

    public boolean operateGermanyFiscalElement(String jsonFunc, int timeout, Context context) {
        int errCode = 0;
        boolean result = true;
        int count = 0;
        if (mGermanyFiscalElement == null || jsonFunc == null) {
            return false;
        }

        String jsonPrefix = context.getString(R.string.operate_func_prefix);
        String jsonSuffix = context.getString(R.string.operate_func_suffix);
        String json = String.format("%s%s%s", jsonPrefix, jsonFunc, jsonSuffix);

        do{
            try {
                count++;
                mGermanyFiscalElement.operate(json, timeout);
                result = true;
            } catch (Epos2Exception e) {
                errCode = e.getErrorStatus();
                result = false;
                if(errCode == Epos2Exception.ERR_PROCESSING){
                    try{Thread.sleep(200);}catch(Exception ex){}
                }
            }
            showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        }while(errCode == Epos2Exception.ERR_PROCESSING && count <= 50);
        return result;
    }

    public com.epson.epos2.germanyfiscalelement.ReceiveListener mGfeReceiveListener = new com.epson.epos2.germanyfiscalelement.ReceiveListener() {
        @Override
        public void onGfeReceive(final GermanyFiscalElement GfeObj, final int code, final String printJobId) {
            sdkMgrListener.onGfeReceive(GfeObj, code, printJobId);
        }
    };

    public boolean initializePrinterObject(Context context, int printerSeries) {
        int errCode = 0;
        boolean result = true;
       if(mPrinter != null){
           finalizePrinterObject();
       }
       try {
           mPrinter = new Printer(printerSeries, Printer.LANG_EN, context);
           mPrinter.setReceiveEventListener(mReceiveListener);
           mPrinter.setConnectionEventListener(mConnectionListener);
        } catch (Epos2Exception e) {
           errCode = e.getErrorStatus();
           result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public void finalizePrinterObject() {
        if (mPrinter == null) {
            return;
        }
        mPrinter.setReceiveEventListener(null);
        mPrinter.setConnectionEventListener(null);
        mPrinter = null;
    }

    public boolean connectPrinter(String target) {
        int errCode = 0;
        boolean result = true;
        if (mPrinter == null) {
            return false;
        }
        try {
            mPrinter.connect(target, Printer.PARAM_DEFAULT);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean disconnectPrinter() {
        int errCode = 0;
        boolean result = true;
        int count = 0;
        if (mPrinter == null) {
            return false;
        }

        do{
            try {
                count++;
                mPrinter.disconnect();
                result = true;
            } catch (Epos2Exception e) {
                errCode = e.getErrorStatus();
                result = false;
                if(errCode == Epos2Exception.ERR_PROCESSING){
                    try{Thread.sleep(500);}catch(Exception ex){}
                }
            }
            showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        }while(errCode == Epos2Exception.ERR_PROCESSING && count <= 4);
        return result;
    }

    public boolean sendDataPrinter() {
        int errCode = 0;
        boolean result = true;
        int count = 0;
        if (mPrinter == null) {
            return false;
        }

        do{
            try {
                count++;
                mPrinter.sendData(Printer.PARAM_DEFAULT);
                result = true;
            } catch (Epos2Exception e) {
                errCode = e.getErrorStatus();
                result = false;
                if(errCode == Epos2Exception.ERR_PROCESSING){
                    try{Thread.sleep(200);}catch(Exception ex){}
                }
            }
            showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        }while(errCode == Epos2Exception.ERR_PROCESSING && count <= 50);
       return result;
    }

    public boolean clearCommandBufferPrinter() {
        if (mPrinter == null) {
            return false;
        }
            mPrinter.clearCommandBuffer();
            showErrorEpos(0, new Object(){}.getClass().getEnclosingMethod().getName());
            return true;
    }

    public boolean addFeedLinePrinter(int line) {
        int errCode = 0;
        boolean result = true;
        if (mPrinter == null) {
            return false;
        }
        try {
            mPrinter.addFeedLine(line);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }


    public boolean addTextAlignPrinter(int align) {
        int errCode = 0;
        boolean result = true;
        if (mPrinter == null) {
            return false;
        }
        try {
            mPrinter.addTextAlign(align);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean addTextSizePrinter(int width, int height) {
        int errCode = 0;
        boolean result = true;
        if (mPrinter == null) {
            return false;
        }
        try {
            mPrinter.addTextSize(width, height);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean addTextPrinter(String text) {
        int errCode = 0;
        boolean result = true;
        if (mPrinter == null || text == null) {
            return false;
        }

        try {
            mPrinter.addText(text);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean addImagePrinter(Context context) {
        int errCode = 0;
        boolean result = true;
        if (mPrinter == null || context == null) {
            return false;
        }

        Bitmap logoData = BitmapFactory.decodeResource(context.getResources(), R.drawable.store);
        try {
            mPrinter.addImage(logoData, 0, 0,
                    logoData.getWidth(),
                    logoData.getHeight(),
                    Printer.COLOR_1,
                    Printer.MODE_MONO,
                    Printer.HALFTONE_DITHER,
                    Printer.PARAM_DEFAULT,
                    Printer.COMPRESS_AUTO);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean addBarcodePrinter() {
        int errCode = 0;
        boolean result = true;
        final int barcodeWidth = 2;
        final int barcodeHeight = 100;
        if (mPrinter == null) {
            return false;
        }

        try {
            mPrinter.addBarcode("01209457",
                    Printer.BARCODE_CODE39,
                    Printer.HRI_BELOW,
                    Printer.FONT_A,
                    barcodeWidth,
                    barcodeHeight);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean addCutPrinter() {
        int errCode = 0;
        boolean result = true;
        if (mPrinter == null) {
            return false;
        }
        try {
            mPrinter.addCut(Printer.CUT_FEED);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean addPulsePrinter() {
        int errCode = 0;
        boolean result = true;
        if (mPrinter == null) {
            return false;
        }
        try {
            mPrinter.addPulse(Printer.PARAM_DEFAULT, Printer.PARAM_DEFAULT);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean getPrinterFirmwareInfo(long timeout) {
        int errCode = 0;
        boolean result = true;
        if (mPrinter == null) {
            return false;
        }
        try {
            mPrinter.getPrinterFirmwareInfo((int)timeout, mFirmwareUpdateListener);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean downloadFirmwareList(String firmwareUpdatePrinterModel,String firmwareUpdateOption) {
        int errCode = 0;
        boolean result = true;
        if (mPrinter == null || firmwareUpdatePrinterModel == null || firmwareUpdateOption == null) {
            return false;
        }
        try {
            mPrinter.downloadFirmwareList(firmwareUpdatePrinterModel,firmwareUpdateOption,mFirmwareUpdateListener);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean updateFirmware(FirmwareInfo targetFirmwareInfo, Context context) {
        if(targetFirmwareInfo == null) {
            return false;
        }

        int errCode = 0;
        boolean result = true;
        if (mPrinter == null) {
            return result;
        }
        try {
            mPrinter.updateFirmware(targetFirmwareInfo, mFirmwareUpdateListener, context);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
            showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        }
        return result;
    }

    public boolean verifyUpdate(FirmwareInfo targetFirmwareInfo) {
        int errCode = 0;
        boolean result = true;
        if (mPrinter == null) {
            return false;
        }
        try {
            mPrinter.verifyUpdate(targetFirmwareInfo, mFirmwareUpdateListener);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    private com.epson.epos2.printer.ReceiveListener mReceiveListener = new com.epson.epos2.printer.ReceiveListener() {
        @Override
        public void onPtrReceive(final Printer printerObj, final int code, final PrinterStatusInfo status, final String printJobId) {
            showCallbackResult(code, new Object(){}.getClass().getEnclosingMethod().getName());
            sdkMgrListener.onPtrReceive(printerObj, code, status, printJobId);
        }
    };

    private com.epson.epos2.printer.FirmwareUpdateListener mFirmwareUpdateListener = new com.epson.epos2.printer.FirmwareUpdateListener() {
        @Override
        public void onReceiveFirmwareInformation(FirmwareInfo firmwareInfo){
            sdkMgrListener.onFirmwareInformationReceive(firmwareInfo);
        }

        @Override
        public void onDownloadFirmwareList(int code, FirmwareInfo[] firmwareInfoList){
            showCallbackResult(code, new Object(){}.getClass().getEnclosingMethod().getName());
            sdkMgrListener.onFirmwareListDownload(code, firmwareInfoList);
        }

        @Override
        public void onUpdateFirmware(int code, int maxWaitTime){
            showCallbackResult(code, new Object(){}.getClass().getEnclosingMethod().getName());
            sdkMgrListener.onFirmwareUpdate(code, maxWaitTime);
        }

        @Override
        public void onFirmwareUpdateProgress(String task, float progress){
            sdkMgrListener.onFirmwareUpdateProgress(task, progress);
        }

        @Override
        public void onUpdateVerify(int code){
            showCallbackResult(code, new Object(){}.getClass().getEnclosingMethod().getName());
            sdkMgrListener.onUpdateVerify(code);
        }
    };

    public boolean initializeDisplayObject(Context context) {
        int errCode = 0;
        boolean result = true;
        if(mLineDisplay != null){
            finalizeDisplayObject();
        }
        try {
            mLineDisplay = new LineDisplay(0, context);
            mLineDisplay.setReceiveEventListener(mLineDisplayReceiveListener);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public void finalizeDisplayObject() {
        if (mLineDisplay == null) {
            return;
        }
        mLineDisplay.setReceiveEventListener(null);
        mLineDisplay = null;
        return;
    }

    public boolean connectLineDisplay(String target) {
        int errCode = 0;
        boolean result = true;
        if (mLineDisplay == null) {
            return false;
        }

        try {
            mLineDisplay.connect(target, LineDisplay.PARAM_DEFAULT);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }


    public boolean disconnectLineDisplay() {
        int errCode = 0;
        boolean result = true;
        int count = 0;
        if (mLineDisplay == null) {
            return false;
        }

        do{
            try {
                count++;
                mLineDisplay.disconnect();
                result = true;
            } catch (Epos2Exception e) {
                errCode = e.getErrorStatus();
                result = false;
                if(errCode == Epos2Exception.ERR_PROCESSING){
                    try{Thread.sleep(500);}catch(Exception ex){}
                }
            }
            showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        }while(errCode == Epos2Exception.ERR_PROCESSING && count <= 4);
        return result;
    }

    public boolean sendDataLineDisplay() {
        int errCode = 0;
        boolean result = true;
        int count = 0;
        if (mLineDisplay == null) {
            return false;
        }

        do{
            try {
                count++;
                mLineDisplay.sendData();
                result = true;
            } catch (Epos2Exception e) {
                errCode = e.getErrorStatus();
                result = false;
                if(errCode == Epos2Exception.ERR_PROCESSING){
                    try{Thread.sleep(200);}catch(Exception ex){}
                }
            }
            showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        }while(errCode == Epos2Exception.ERR_PROCESSING && count <= 50);
         mLineDisplay.clearCommandBuffer();
        return result;
    }

    public boolean addInitializeLineDisplay() {
        int errCode = 0;
        boolean result = true;
        if (mLineDisplay == null) {
            return false;
        }

        try {
            mLineDisplay.addInitialize();
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean addSetCursorPositionLineDisplay(int x, int y) {
        int errCode = 0;
        boolean result = true;
        if (mLineDisplay == null) {
            return false;
        }
        try {
            mLineDisplay.addSetCursorPosition(x, y);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean addTextLineDisplay(String data) {
        int errCode = 0;
        boolean result = true;
        if (mLineDisplay == null || data == null) {
            return false;
        }

        try {
            mLineDisplay.addText(data);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean indicateDisplay(String data) {
        boolean result = true;
       if (data == null) {
            return false;
        }
        result = addInitializeLineDisplay();
        if(result == true){
            result = addSetCursorPositionLineDisplay(1, 1);
            if(result == true){
                result = addTextLineDisplay(data);
                if(result == true){
                    result = sendDataLineDisplay();
                }
            }
        }
        return result;
    }

    private com.epson.epos2.linedisplay.ReceiveListener mLineDisplayReceiveListener = new com.epson.epos2.linedisplay.ReceiveListener() {
        @Override
        public void onDispReceive(final LineDisplay LineDisplayObj, final int code) {
            sdkMgrListener.onDispReceive(LineDisplayObj, code);
        }
    };

    public boolean initializeScannerObject(Context context) {
        int errCode = 0;
        boolean result = true;
        if(mBarcodeScanner != null){
            finalizeScannerObject();
        }
        try {
            mBarcodeScanner = new BarcodeScanner(context);
            mBarcodeScanner.setScanEventListener(mScanListener);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public void finalizeScannerObject() {
        if (mBarcodeScanner == null) {
            return;
        }
        mBarcodeScanner.setScanEventListener(null);
        mBarcodeScanner = null;
    }


    public boolean connectBarcodeScanner(String target) {
        int errCode = 0;
        boolean result = true;
        if (mBarcodeScanner == null) {
            return false;
        }

        try {
            mBarcodeScanner.connect(target, Printer.PARAM_DEFAULT);
        } catch (Epos2Exception e) {
            errCode = e.getErrorStatus();
            result = false;
        }
        showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        return result;
    }

    public boolean disconnectBarcodeScanner() {
        int errCode = 0;
        boolean result = true;
        int count = 0;
        if (mBarcodeScanner == null) {
            return false;
        }

        do{
            try {
                count++;
                mBarcodeScanner.disconnect();
                result = true;
            } catch (Epos2Exception e) {
                errCode = e.getErrorStatus();
                result = false;
                if(errCode == Epos2Exception.ERR_PROCESSING){
                    try{Thread.sleep(500);}catch(Exception ex){}
                }
            }
            showErrorEpos(errCode, new Object(){}.getClass().getEnclosingMethod().getName());
        }while(errCode == Epos2Exception.ERR_PROCESSING && count <= 4);
        return result;
    }


    private ScanListener mScanListener = new ScanListener() {
        @Override
        public void onScanData(final BarcodeScanner scanObj, final String data) {
            sdkMgrListener.onScanData(scanObj, data);
        }
    };

    private ConnectionListener mConnectionListener = new ConnectionListener() {
        @Override
        public void onConnection(final Object printerObj, final int code) {
            sdkMgrListener.onConnection(printerObj, code);
        }
    };

    public void onApiLog(String apiLog){
        sdkMgrListener.onApiLog(apiLog);
    }

    public void showErrorEpos(int resultCode, String method)
    {
        String msg = String.format("Method:%s\n  Result:%s\n", method,getEposExceptionText(resultCode));

        if (sdkMgrListener != null) {
            onApiLog(msg);
        }
    }

    public void showCallbackResult(int code, String method)
    {
        String msg = String.format("Method:%s\nStatus:%s\n", method, getEposErrorText(code));
        if (sdkMgrListener != null) {
            onApiLog(msg);
        }
    }

    public void showError(String errorDetail,  String method)
    {
        String msg = String.format("%Method:%s\n%s\n", method, errorDetail);

        if (sdkMgrListener != null) {
            onApiLog(msg);
        }
    }

    //convert Epos2Printer Error to text
    public static String getEposExceptionText(int state) {
        String return_text;
        switch (state) {
            case 0:
                return_text = "SUCCESS";
                break;
            case Epos2Exception.ERR_PARAM:
                return_text = "ERR_PARAM";
                break;
            case Epos2Exception.ERR_CONNECT:
                return_text = "ERR_CONNECT";
                break;
            case Epos2Exception.ERR_TIMEOUT:
                return_text = "ERR_TIMEOUT";
                break;
            case Epos2Exception.ERR_MEMORY:
                return_text = "ERR_MEMORY";
                break;
            case Epos2Exception.ERR_ILLEGAL:
                return_text = "ERR_ILLEGAL";
                break;
            case Epos2Exception.ERR_PROCESSING:
                return_text = "ERR_PROCESSING";
                break;
            case Epos2Exception.ERR_NOT_FOUND:
                return_text = "ERR_NOT_FOUND";
                break;
            case Epos2Exception.ERR_IN_USE:
                return_text = "ERR_IN_USE";
                break;
            case Epos2Exception.ERR_TYPE_INVALID:
                return_text = "ERR_TYPE_INVALID";
                break;
            case Epos2Exception.ERR_DISCONNECT:
                return_text = "ERR_DISCONNECT";
                break;
            case Epos2Exception.ERR_ALREADY_OPENED:
                return_text = "ERR_ALREADY_OPENED";
                break;
            case Epos2Exception.ERR_ALREADY_USED:
                return_text = "ERR_ALREADY_USED";
                break;
            case Epos2Exception.ERR_BOX_COUNT_OVER:
                return_text = "ERR_BOX_COUNT_OVER";
                break;
            case Epos2Exception.ERR_BOX_CLIENT_OVER:
                return_text = "ERR_BOX_CLIENT_OVER";
                break;
            case Epos2Exception.ERR_UNSUPPORTED:
                return_text = "ERR_UNSUPPORTED";
                break;
            case Epos2Exception.ERR_FAILURE:
                return_text = "ERR_FAILURE";
                break;
            default:
                return_text = String.format("%d", state);
                break;
        }
        return return_text;
    }

    //convert Epos2 Result code to text
    public static String getEposErrorText(int state) {
        String return_text = "";
        switch (state) {
            case Epos2CallbackCode.CODE_SUCCESS:
                return_text = "SUCCESS";
                break;
            case Epos2CallbackCode.CODE_ERR_TIMEOUT:
                return_text = "ERR_TIMEOUT";
                break;
            case Epos2CallbackCode.CODE_ERR_NOT_FOUND:
                return_text = "ERR_NOT_FOUND";
                break;
            case Epos2CallbackCode.CODE_ERR_AUTORECOVER:
                return_text = "ERR_AUTORECOVER";
                break;
            case Epos2CallbackCode.CODE_ERR_COVER_OPEN:
                return_text = "ERR_COVER_OPEN";
                break;
            case Epos2CallbackCode.CODE_ERR_CUTTER:
                return_text = "ERR_CUTTER";
                break;
            case Epos2CallbackCode.CODE_ERR_MECHANICAL:
                return_text = "ERR_MECHANICAL";
                break;
            case Epos2CallbackCode.CODE_ERR_EMPTY:
                return_text = "ERR_EMPTY";
                break;
            case Epos2CallbackCode.CODE_ERR_UNRECOVERABLE:
                return_text = "ERR_UNRECOVERABLE";
                break;
            case Epos2CallbackCode.CODE_ERR_SYSTEM:
                return_text = "ERR_SYSTEM";
                break;
            case Epos2CallbackCode.CODE_ERR_PORT:
                return_text = "ERR_PORT";
                break;
            case Epos2CallbackCode.CODE_ERR_INVALID_WINDOW:
                return_text = "ERR_INVALID_WINDOW";
                break;
            case Epos2CallbackCode.CODE_ERR_JOB_NOT_FOUND:
                return_text = "ERR_JOB_NOT_FOUND";
                break;
            case Epos2CallbackCode.CODE_PRINTING:
                return_text = "PRINTING";
                break;
            case Epos2CallbackCode.CODE_ERR_SPOOLER:
                return_text = "ERR_SPOOLER";
                break;
            case Epos2CallbackCode.CODE_ERR_BATTERY_LOW:
                return_text = "ERR_BATTERY_LOW";
                break;
            case Epos2CallbackCode.CODE_ERR_TOO_MANY_REQUESTS:
                return_text = "ERR_TOO_MANY_REQUESTS";
                break;
            case Epos2CallbackCode.CODE_ERR_REQUEST_ENTITY_TOO_LARGE:
                return_text = "ERR_REQUEST_ENTITY_TOO_LARGE";
                break;
            case Epos2CallbackCode.CODE_CANCELED:
                return_text = "CANCELED";
                break;
            case Epos2CallbackCode.CODE_ERR_NO_MICR_DATA:
                return_text = "ERR_NO_MICR_DATA";
                break;
            case Epos2CallbackCode.CODE_ERR_ILLEGAL_LENGTH:
                return_text = "ERR_ILLEGAL_LENGTH";
                break;
            case Epos2CallbackCode.CODE_ERR_NO_MAGNETIC_DATA:
                return_text = "ERR_NO_MAGNETIC_DATA";
                break;
            case Epos2CallbackCode.CODE_ERR_RECOGNITION:
                return_text = "ERR_RECOGNITION";
                break;
            case Epos2CallbackCode.CODE_ERR_READ:
                return_text = "ERR_READ";
                break;
            case Epos2CallbackCode.CODE_ERR_NOISE_DETECTED:
                return_text = "ERR_NOISE_DETECTED";
                break;
            case Epos2CallbackCode.CODE_ERR_PAPER_JAM:
                return_text = "ERR_PAPER_JAM";
                break;
            case Epos2CallbackCode.CODE_ERR_PAPER_PULLED_OUT:
                return_text = "ERR_PAPER_PULLED_OUT";
                break;
            case Epos2CallbackCode.CODE_ERR_CANCEL_FAILED:
                return_text = "ERR_CANCEL_FAILED";
                break;
            case Epos2CallbackCode.CODE_ERR_PAPER_TYPE:
                return_text = "ERR_PAPER_TYPE";
                break;
            case Epos2CallbackCode.CODE_ERR_WAIT_INSERTION:
                return_text = "ERR_WAIT_INSERTION";
                break;
            case Epos2CallbackCode.CODE_ERR_ILLEGAL:
                return_text = "ERR_ILLEGAL";
                break;
            case Epos2CallbackCode.CODE_ERR_INSERTED:
                return_text = "ERR_INSERTED";
                break;
            case Epos2CallbackCode.CODE_ERR_WAIT_REMOVAL:
                return_text = "ERR_WAIT_REMOVAL";
                break;
            case Epos2CallbackCode.CODE_ERR_DEVICE_BUSY:
                return_text = "ERR_DEVICE_BUSY";
                break;
            case Epos2CallbackCode.CODE_ERR_GET_JSON_SIZE:
                return_text = "ERR_GET_JSON_SIZE";
                break;
            case Epos2CallbackCode.CODE_ERR_IN_USE:
                return_text = "ERR_IN_USE";
                break;
            case Epos2CallbackCode.CODE_ERR_CONNECT:
                return_text = "ERR_CONNECT";
                break;
            case Epos2CallbackCode.CODE_ERR_DISCONNECT:
                return_text = "ERR_DISCONNECT";
                break;
            case Epos2CallbackCode.CODE_ERR_DIFFERENT_MODEL:
                return_text = "ERR_DIFFERENT_MODEL";
                break;
            case Epos2CallbackCode.CODE_ERR_DIFFERENT_VERSION:
                return_text = "ERR_DIFFERENT_VERSION";
                break;
            case Epos2CallbackCode.CODE_ERR_MEMORY:
                return_text = "ERR_MEMORY";
                break;
            case Epos2CallbackCode.CODE_ERR_PROCESSING:
                return_text = "ERR_PROCESSING";
                break;
            case Epos2CallbackCode.CODE_ERR_DATA_CORRUPTED:
                return_text = "ERR_DATA_CORRUPTED";
                break;
            case Epos2CallbackCode.CODE_ERR_PARAM:
                return_text = "ERR_PARAM";
                break;
            case Epos2CallbackCode.CODE_RETRY:
                return_text = "ERR_RETRY";
                break;
            case Epos2CallbackCode.CODE_ERR_FAILURE:
                return_text = "ERR_FAILURE";
                break;
            default:
                return_text = String.format("%d", state);
                break;
        }
        return return_text;
    }

}
