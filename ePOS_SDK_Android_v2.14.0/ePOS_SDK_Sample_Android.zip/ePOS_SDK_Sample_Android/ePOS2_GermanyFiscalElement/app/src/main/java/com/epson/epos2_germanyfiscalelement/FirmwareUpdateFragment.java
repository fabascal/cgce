package com.epson.epos2_germanyfiscalelement;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import java.util.ArrayList;

import com.epson.epos2.Epos2CallbackCode;
import com.epson.epos2.printer.FirmwareInfo;
import com.epson.epos2.printer.Printer;

import static com.epson.epos2_germanyfiscalelement.MainActivity.targetPrinter;
import static com.epson.epos2_germanyfiscalelement.MainActivity.printerSeries;

public class FirmwareUpdateFragment extends GermanyFiscalElementFragment implements View.OnClickListener, AdapterView.OnItemSelectedListener {

    private View rootView;
    private TextView mTextCurrentFirmware = null;
    private static Spinner mSpnList = null;
    private EditText mEditPrinterModel = null;
    private EditText mEditOption = null;
    private Button mBtnGetPrinterFirmware = null;
    private Button mBtnDownloadFirmwareList = null;
    private Button mBtnUpdateFirmware = null;
    private Object queueForSDK = null;
    public Epos2SdkMgr sdkManager = null;
    public Epos2SdkMgrListener sdkMgrListener = null;
    private FirmwareInfo targetFirmwareInfo = null;
    private FirmwareInfo[] firmwareInfoList = null;

    public static FirmwareUpdateFragment newInstance() {
        return new FirmwareUpdateFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        rootView = inflater.inflate(R.layout.fragment_firmwareupdate, container, false);
        mTextCurrentFirmware = rootView.findViewById(R.id.textCurrentFirmware);
        mBtnGetPrinterFirmware = rootView.findViewById(R.id.btnGetPrinterFirmware);
        mBtnDownloadFirmwareList = rootView.findViewById(R.id.btnDownloadFirmwareList);
        mBtnUpdateFirmware = rootView.findViewById(R.id.btnUpdateFirmware);
        mEditPrinterModel = rootView.findViewById(R.id.edtPrinterModel);
        mEditOption = rootView.findViewById(R.id.edtOption);

        mSpnList = rootView.findViewById(R.id.spnFirmwareList);
        ArrayAdapter<SpnModelsItem> listAdapter = new ArrayAdapter<SpnModelsItem>(getActivity(), android.R.layout.simple_spinner_item);
        listAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        listAdapter.add(new SpnModelsItem("-", 0));
        mSpnList.setAdapter(listAdapter);
        mSpnList.setSelection(0);
        mSpnList.setOnItemSelectedListener(this);

        mBtnGetPrinterFirmware.setOnClickListener(this);
        mBtnDownloadFirmwareList.setOnClickListener(this);
        mBtnUpdateFirmware.setOnClickListener(this);
        mBtnUpdateFirmware.setEnabled(false);
        mBtnDownloadFirmwareList.setEnabled(false);
        mBtnGetPrinterFirmware.setEnabled(false);

        return rootView;
    }

    @Override
    public void onDestroyView() {
        destroyFirmwareUpdateFragment();
        super.onDestroyView();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        if(rootView != null){
            if (isVisibleToUser) {
                initializeFirmwareUpdateFragment();
            } else {
                destroyFirmwareUpdateFragment();
            }
        }
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (parent.getId()) {
            case R.id.spnFirmwareList:
                if(firmwareInfoList != null){
                    targetFirmwareInfo = firmwareInfoList[position];
                } else {
                    targetFirmwareInfo = null;
                }
                break;
            default:
                break;
        }
    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        ;
    }

    public void initializeFirmwareUpdateFragment(){
        mTextGermanyFiscalElement = rootView.findViewById(R.id.textView_firmwareUpdateText);
        mScrollView = rootView.findViewById(R.id.scrollView_firmwareUpdate);
        queueForSDK = new Object();
        sdkMgrListener = new Epos2SdkMgrListener();
        sdkMgrListener.setListener(this);
        sdkManager = Epos2SdkMgr.newInstance(sdkMgrListener);
        synchronized (queueForSDK){
            sdkManager.initializePrinterObject(getActivity(), printerSeries);
            new Thread (() -> {
                beginProgress(getActivity().getString(R.string.progress_msg));
                if(!targetPrinter.contains("[") && sdkManager.connectPrinter(targetPrinter)) {
                    getActivity().runOnUiThread(new Runnable() {
                        public synchronized void run() {
                            mBtnDownloadFirmwareList.setEnabled(true);
                            mBtnGetPrinterFirmware.setEnabled(true);
                        }
                    });
                }
                endProgress();
            }).start();
        }
    }

    public void destroyFirmwareUpdateFragment(){
        sdkManager.disconnectPrinter();
        mBtnUpdateFirmware.setEnabled(false);
        mBtnDownloadFirmwareList.setEnabled(false);
        mBtnGetPrinterFirmware.setEnabled(false);

        mTextGermanyFiscalElement.setText("");
        queueForSDK = null;

        if(sdkMgrListener != null){
            sdkMgrListener.removeListener();
            sdkMgrListener.setListener(null);
            sdkMgrListener = null;
        }
        sdkManager = null;
    }

    @Override
    public void onClick(View v) {

        switch (v.getId()) {
            case R.id.btnGetPrinterFirmware:
                //get firmversion
                getPrinterFirmware();
               break;
            case R.id.btnDownloadFirmwareList:
                //download firm
                downloadFirmwareList();
                break;
            case R.id.btnUpdateFirmware:
                //update firm
                updateFirmware();
                break;
            default:
                // Do nothing
                break;
        }
    }

    private String notesMessage() {
        String ss = String.format("1. %s\n", getActivity().getString(R.string.note1_1));
        ss += String.format("   %s\n", getActivity().getString(R.string.note1_2));
        ss += String.format("   %s\n\n", getActivity().getString(R.string.note1_3));
        ss += String.format("2. %s\n\n", getActivity().getString(R.string.note2));
        ss += String.format("3. %s\n\n", getActivity().getString(R.string.note3));
        ss += String.format("4. %s\n\n", getActivity().getString(R.string.note4));
        ss += String.format("5. %s\n\n", getActivity().getString(R.string.note5));
        ss += String.format("6. %s\n\n", getActivity().getString(R.string.note6));
        ss += String.format("7. %s\n\n", getActivity().getString(R.string.note7));
        ss += String.format("8. %s\n\n", getActivity().getString(R.string.note8));
        ss += String.format("9. %s\n\n", getActivity().getString(R.string.note9));
        return ss;
    }

    private boolean getPrinterFirmware() {
        new Thread (() -> {
            synchronized (queueForSDK){
                beginProgress(getActivity().getString(R.string.progress_msg));
                if(!sdkManager.getPrinterFirmwareInfo(Printer.PARAM_DEFAULT)){
                    endProgress();
                }
            }
        }).start();
        return true;
    }

    private boolean downloadFirmwareList()
    {
        new Thread (() -> {
            synchronized (queueForSDK) {
                beginProgress(getActivity().getString(R.string.progress_msg));
                if (!sdkManager.downloadFirmwareList(mEditPrinterModel.getText().toString(),mEditOption.getText().toString())){
                    endProgress();
                }
            }
        }).start();
        return true;
    }

    private boolean updateFirmware()
    {
        new Thread (() -> {
            synchronized (queueForSDK) {
                beginProgress(getActivity().getString(R.string.progress_msg));
                if (!sdkManager.updateFirmware(targetFirmwareInfo, getContext())) {
                    endProgress();
                }
            }
        }).start();
        return true;
    }

    @Override
    public void onFirmwareInformationReceiveResult(FirmwareInfo firmwareInfo){
        new Thread (() -> {
        synchronized (queueForSDK) {
            setCurrentFirmwareText(firmwareInfo.getVersion());
            endProgress();
        }
        }).start();
    }

    @Override
    public void onFirmwareListDownloadResult(final int code, FirmwareInfo[] firmwareList){
        new Thread (() -> {
            synchronized (queueForSDK) {
                firmwareInfoList = firmwareList;
                updateFirmwareList();
                getActivity().runOnUiThread(new Runnable() {
                    public synchronized void run() {
                        mBtnUpdateFirmware.setEnabled(true);
                    }
                });
                endProgress();
            }
        }).start();
    }

    @Override
    public void onFirmwareUpdateResult(final int code, int maxWaitTime){
        new Thread (() -> {
            synchronized (queueForSDK){
                if(code != Epos2CallbackCode.CODE_SUCCESS){
                    endProgress();
                    return;
                }

                updateWaitingMessage(getActivity().getString(R.string.reconnect_message));

                sdkManager.disconnectPrinter();
                try{
                    Thread.sleep(maxWaitTime * 1000);
                }catch (Exception e){
                    ;
                }
                if(!sdkManager.connectPrinter(targetPrinter)) {
                    endProgress();
                    return;
                }

                updateWaitingMessage(getActivity().getString(R.string.verify_message));

                // Verify firmware version.
                sdkManager.verifyUpdate(targetFirmwareInfo);
            }
        }).start();
    }

    @Override
    public void onFirmwareUpdateProgressResult(String task, float progress){
        updateWaitingMessage(task, progress*100);
    }

    @Override
    public void onUpdateVerifyResult(final int code){
        new Thread (() -> {
            synchronized (queueForSDK){
                endProgress();
            }
        }).start();
    }

    @Override
    public void onLogEPOS2SDKManager(final String apiLog){
        if(apiLog != null){
            appendTextView(apiLog);
        }
    }

    private void appendTextView(String text){
        if(text == null){
            return;
        }
        getActivity().runOnUiThread(new Runnable() {
            public synchronized void run() {
                mTextGermanyFiscalElement.append(text);
                mScrollView.post(new Runnable(){
                    public void run()
                    {
                        mScrollView.fullScroll(ScrollView.FOCUS_DOWN);
                    }
                });
            }
        });
    }

    private void updateWaitingMessage(String msg){
        String progressMsg = String.format("%s\n\n%s", msg, notesMessage());
        changeProgress(progressMsg);
    }
    private void updateWaitingMessage(String msg, float count){
        String progressMsg = String.format("%s: %3.2f%%\n\n%s", msg, count, notesMessage());
        changeProgress(progressMsg);
    }
    private void setCurrentFirmwareText(String version){
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mTextCurrentFirmware.setText(version);
            }
        });
    }
    private void updateFirmwareList(){
        if(firmwareInfoList == null) {
            return;
        }

        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ArrayList<String> firmwareVersionList = new ArrayList<String>();
                ArrayAdapter<SpnModelsItem> listAdapter = new ArrayAdapter<SpnModelsItem>(getActivity(), android.R.layout.simple_spinner_item);
                listAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

                int firmwareListCount = firmwareInfoList.length;
                for (int i = 0; i < firmwareListCount; i++) {
                    String version = firmwareInfoList[i].getVersion();
                    firmwareVersionList.add(version);
                    listAdapter.add(new SpnModelsItem(version, i));
                }

                mSpnList.setAdapter(listAdapter);
                mSpnList.setSelection(0);
                mBtnUpdateFirmware.setEnabled(true);
            }
        });
    }
}
