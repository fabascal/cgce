package com.epson.epos2_germanyfiscalelement;

import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;

import java.util.concurrent.Semaphore;
import org.json.JSONObject;

import com.epson.epos2.germanyfiscalelement.GermanyFiscalElement;
import com.epson.epos2.printer.Printer;

import static com.epson.epos2_germanyfiscalelement.MainActivity.targetBarcodeScanner;
import static com.epson.epos2_germanyfiscalelement.MainActivity.targetGermanyFiscalElement;
import static com.epson.epos2_germanyfiscalelement.MainActivity.targetLineDisplay;
import static com.epson.epos2_germanyfiscalelement.MainActivity.targetPrinter;
import static com.epson.epos2_germanyfiscalelement.MainActivity.printerSeries;
import static com.epson.epos2_germanyfiscalelement.MainActivity.clientId;

public class SettingFragment extends GermanyFiscalElementFragment implements View.OnClickListener, TextView.OnEditorActionListener, AdapterView.OnItemSelectedListener{

    private View rootView = null;
    private static Spinner mSpnSeries = null;
    private Button mBtnSelectPrinter = null;
    private Button mBtnSetup = null;
    private EditText mTextTargetPrinter = null;
    private EditText mTextTargetGermanyFiscalElement = null;
    private EditText mTextTargetLineDisplay = null;
    private EditText mTextTargetBarcodeScanner = null;
    private EditText mTextClientId = null;
    private Semaphore gfeSemaphore = null;
    private final int responseLimitTimeDefault = 10000;
    private Object queueForSDK = null;
    public Epos2SdkMgr sdkManager = null;
    public Epos2SdkMgrListener sdkMgrListener = null;
    private String tseInitializationState = "";
    private String challenge = "";

    public static SettingFragment newInstance() {
        return new SettingFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_setting, container, false);
        mBtnSelectPrinter = (Button) rootView.findViewById(R.id.btnSelectPrinter);
        mBtnSetup = (Button) rootView.findViewById(R.id.btnSetup);
        mSpnSeries = rootView.findViewById(R.id.spnModel);
        ArrayAdapter<SpnModelsItem> seriesAdapter = new ArrayAdapter<SpnModelsItem>(getActivity(), android.R.layout.simple_spinner_item);
        seriesAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        seriesAdapter.add(new SpnModelsItem(getString(R.string.printerSeries_m30), Printer.TM_M30));
        seriesAdapter.add(new SpnModelsItem(getString(R.string.printerSeries_t88), Printer.TM_T88));
        seriesAdapter.add(new SpnModelsItem(getString(R.string.printerSeries_m30ii), Printer.TM_M30II));
        mSpnSeries.setAdapter(seriesAdapter);
        mSpnSeries.setSelection(0);
        printerSeries = Printer.TM_M30;
        mBtnSelectPrinter.setOnClickListener(this);
        mBtnSetup.setOnClickListener(this);
        mSpnSeries.setOnItemSelectedListener(this);

        mTextTargetPrinter = (EditText)  rootView.findViewById(R.id.editText_target_printer);
        mTextTargetGermanyFiscalElement = (EditText) rootView.findViewById(R.id.editText_target_gfe);
        mTextTargetLineDisplay = (EditText) rootView.findViewById(R.id.editText_target_display);
        mTextTargetBarcodeScanner = (EditText) rootView.findViewById(R.id.editText_target_scanner);
        mTextClientId = (EditText) rootView.findViewById(R.id.editText_clientId);
        clientId = mTextClientId.getText().toString();
        initializeSettingFragment();
        mTextTargetPrinter.setOnEditorActionListener(this);
        mTextTargetGermanyFiscalElement.setOnEditorActionListener(this);
        mTextTargetLineDisplay.setOnEditorActionListener(this);
        mTextTargetBarcodeScanner.setOnEditorActionListener(this);
        mTextClientId.setOnEditorActionListener(this);

        return rootView;
    }

    @Override
    public void onDestroyView() {
        destroySettingFragment();
        super.onDestroyView();
    }
    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        if(rootView != null){
            if (isVisibleToUser) {
                initializeSettingFragment();
            } else {
                destroySettingFragment();
            }
        }
    }

    @Override
    public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
        if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_NEXT) {
            setTargetDevice();
            return true;
        }
        return false;
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
        switch (position) {
            case 0:
                printerSeries = Printer.TM_M30;
                break;
            case 1:
                printerSeries = Printer.TM_T88;
                break;
            case 2:
                printerSeries = Printer.TM_M30II;
                break;
            default:
                printerSeries = Printer.TM_M30;
                break;
        }

    }

    @Override
    public void onNothingSelected(AdapterView<?> parent) {
        ;
    }

    public void initializeSettingFragment(){
        mTextGermanyFiscalElement = rootView.findViewById(R.id.textView_settingText);
        mScrollView = rootView.findViewById(R.id.scrollView_setting);
        setTargetDevice();
        queueForSDK = new Object();
        gfeSemaphore = new Semaphore(1);
        sdkMgrListener = new Epos2SdkMgrListener();
        sdkMgrListener.setListener(this);
        sdkManager = Epos2SdkMgr.newInstance(sdkMgrListener);
        synchronized (queueForSDK){
            sdkManager.initializeGfeObject(getActivity());
        }
    }

    public void destroySettingFragment(){
        mTextGermanyFiscalElement.setText("");
        queueForSDK = null;
        gfeSemaphore = null;
        if(sdkMgrListener != null){
            sdkMgrListener.removeListener();
            sdkMgrListener.setListener(null);
            sdkMgrListener = null;
        }
        sdkManager = null;
    }

    @Override
    public void onClick(View v) {
        Intent intent;
        switch (v.getId()) {
            case R.id.btnSelectPrinter:
                intent = new Intent(getActivity(), DiscoveryActivity.class);
                startActivityForResult(intent, 0);
                break;
            case R.id.btnSetup:
                setup();
            default:
                // Do nothing
                break;
        }
    }

    @Override
    public void onActivityResult(int requestCode, final int resultCode, final Intent data) {
        if (data != null && resultCode == -1) {
            mTextTargetPrinter.setText(data.getStringExtra(getString(R.string.title_target_printer)));
            mTextTargetGermanyFiscalElement.setText(data.getStringExtra(getString(R.string.title_target_gfe)));
            mTextTargetLineDisplay.setText(data.getStringExtra(getString(R.string.title_target_display)));
            mTextTargetBarcodeScanner.setText(data.getStringExtra(getString(R.string.title_target_scanner)));
            setTargetDevice();
        }
    }

    private void setTargetDevice(){
        targetPrinter = mTextTargetPrinter.getText().toString();
        targetGermanyFiscalElement = mTextTargetGermanyFiscalElement.getText().toString();
        targetLineDisplay = mTextTargetLineDisplay.getText().toString();
        targetBarcodeScanner = mTextTargetBarcodeScanner.getText().toString();
        clientId = mTextClientId.getText().toString();
    }

    private boolean operateGetStorageInfo()
    {
        String jsonFunc_getStorageInfo = getString(R.string.operate_func_getStorageInfo);
        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_getStorageInfo, GermanyFiscalElement.PARAM_DEFAULT, getActivity());
        if(result == true){
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName(), GermanyFiscalElement.PARAM_DEFAULT);
        }
        return result;
    }


    private boolean operateSetUp()
    {
        String jsonFunc_tmp= getString(R.string.operate_func_setup);
        String puk = getString(R.string.puk);
        String adminPin = getString(R.string.adminPin);
        String timeAdminPin = getString(R.string.timeAdminPin);

        String jsonFunc_setup = String.format((String)jsonFunc_tmp, puk, adminPin ,timeAdminPin);

        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_setup, 120000, getActivity());
        if(result == true){
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName(), 120000);
        }
        return result;
    }

    private boolean operateSetUpForPrinter()
    {
        String jsonFunc_setupForPrinter =  getString(R.string.operate_func_setupForPrinter);

        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_setupForPrinter, GermanyFiscalElement.PARAM_DEFAULT, getActivity());
        if(result == true){
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName(), GermanyFiscalElement.PARAM_DEFAULT);
        }

        return result;
    }


    private boolean operateAuthenticateUserForAdmin()
    {
        // GetChallenge
        boolean result = operateGetChallenge(sdkManager, getString(R.string.administrator));
        if(result == true) {
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName(), GermanyFiscalElement.PARAM_DEFAULT);
        }

        // Hash calculation
        if(tseInitializationState == null || result == false) {
            return false;
        }
        String secretKey;
        if(tseInitializationState.equals("UNINITIALIZED")) {
            secretKey = getString(R.string.defaultSecretKey);
        } else if(tseInitializationState.equals("INITIALIZED")) {
            secretKey = getString(R.string.secretKey);
        } else {
            return false;
        }
        String input = challenge + secretKey;
        String hash= calculateHash(input);

        result = operateAuthenticateUserForAdmin(sdkManager, hash);
        if(result == true){
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName(), GermanyFiscalElement.PARAM_DEFAULT);
        }

        return result;
    }

    private boolean operateLogOutForAdmin()
    {
        boolean result = operateLogOutForAdmin(sdkManager);
        if(result == true){
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName(), GermanyFiscalElement.PARAM_DEFAULT);
        }

        return result;
    }

    private boolean operateRegisterSecretKey()
    {
        String jsonFunc_tmp= getString(R.string.operate_func_registerSecretKey);
        String userId = getString(R.string.administrator);
        String secretKey = getString(R.string.secretKey);
        String jsonFunc_registerSecretKey = String.format((String)jsonFunc_tmp, userId, secretKey);

        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_registerSecretKey, GermanyFiscalElement.PARAM_DEFAULT, getActivity());
        if(result == true){
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName(), GermanyFiscalElement.PARAM_DEFAULT);
        }

        return result;
    }

    private boolean operateRegisterClientId()
    {
        String jsonFunc_tmp= getString(R.string.operate_func_registerClient);
        String userId = getString(R.string.administrator);
        String jsonFunc_registerClientId = String.format((String)jsonFunc_tmp, userId, clientId);

        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_registerClientId, GermanyFiscalElement.PARAM_DEFAULT, getActivity());
        if(result == true){
            result = waitCallbackEvent(new Object(){}.getClass().getEnclosingMethod().getName(), GermanyFiscalElement.PARAM_DEFAULT);
        }

        return result;
    }

    private void setup(){

        new Thread (() -> {
            synchronized (queueForSDK) {
                beginProgress(getActivity().getString(R.string.progress_msg));

                boolean result = sdkManager.connectGermanyFiscalElement(targetGermanyFiscalElement);
                if (result == true) {
                    result = operateGetStorageInfo();
                    if (result == true) {
                        result = operateSetUp();
                        if (result == true) {
                            result = operateAuthenticateUserForAdmin();
                            if (result == true) {
                                result = operateSetUpForPrinter();
                                if(result == true){
                                    result = operateRegisterSecretKey();
                                    if (result == true) {
                                        operateRegisterClientId();
                                    }
                                }
                                operateLogOutForAdmin();
                            }
                        }
                    }
                    sdkManager.disconnectGermanyFiscalElement();
                }
                endProgress();
            }
        }).start();
    }

    private boolean waitCallbackEvent(String method, int timeout){
        if(method == null){
            return false;
        }
        synchronized (gfeSemaphore) {
            int responseTimeout;
            if(timeout == GermanyFiscalElement.PARAM_DEFAULT) {
                responseTimeout = responseLimitTimeDefault;
            } else {
                responseTimeout = timeout;
            }
            try {
                gfeSemaphore.wait(responseTimeout);
            } catch (Exception e) {
                sdkManager.showError(getActivity().getString(R.string.error_msg), method);
                return false;
            }
        }
        return true;
    }

    @Override
    public void onGfeReceiveEPOS2SDKManager(final GermanyFiscalElement GfeObj, final int code, final String data){
        String viewText = String.format("onGfeReceive:\n");
        viewText += String.format("  code:%s\n", sdkManager.getEposErrorText(code));
        viewText += String.format("  data:%s\n", data);
        appendTextView(viewText);

        JSONObject json = parseJson(data);
        String result = getJsonString(json, "result");
        if(result.equals("EXECUTION_OK")) {
            String function = getJsonString(json, "function");

            if(function.equals("GetStorageInfo")) {

                JSONObject tmpJson = (getJsonOutputInfo(json));
                String tseInitialization = getJsonString(getJsonTseInformation(tmpJson), "tseInitializationState");
                tseInitializationState = tseInitialization;
            }

            if(function.equals("GetChallenge")) {
                String tmpChallenge = getJsonString(getJsonOutputInfo(json), "challenge");
                if(tmpChallenge != null) {
                    challenge = tmpChallenge;
                }
            }
        }
        synchronized (gfeSemaphore){
            gfeSemaphore.notify();
        }
    }

    @Override
    public void onLogEPOS2SDKManager(final String message){
        if(message != null){
            appendTextView(message);
        }
    }

    private void appendTextView(String text){
        if(text == null){
            return;
        }
        getActivity().runOnUiThread(new Runnable() {
            public synchronized void run() {
                mTextGermanyFiscalElement.append(text);
                mScrollView.post(new Runnable(){
                    public void run()
                    {
                        mScrollView.fullScroll(ScrollView.FOCUS_DOWN);
                    }
                });
            }
        });
    }
}


