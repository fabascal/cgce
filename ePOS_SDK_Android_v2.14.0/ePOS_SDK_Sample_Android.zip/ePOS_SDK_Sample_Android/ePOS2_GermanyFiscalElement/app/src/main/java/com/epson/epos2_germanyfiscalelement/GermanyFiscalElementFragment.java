package com.epson.epos2_germanyfiscalelement;

import android.app.ProgressDialog;
import android.support.v4.app.Fragment;
import android.util.Base64;
import android.widget.ScrollView;
import android.widget.TextView;
import java.math.BigInteger;
import java.security.MessageDigest;
import java.util.ArrayList;

import org.json.JSONObject;

import com.epson.epos2.barcodescanner.BarcodeScanner;
import com.epson.epos2.discovery.DeviceInfo;
import com.epson.epos2.germanyfiscalelement.*;
import com.epson.epos2.linedisplay.LineDisplay;
import com.epson.epos2.printer.FirmwareInfo;
import com.epson.epos2.printer.Printer;
import com.epson.epos2.printer.PrinterStatusInfo;
import static com.epson.epos2_germanyfiscalelement.MainActivity.clientId;

public class GermanyFiscalElementFragment extends Fragment implements Epos2SdkMgrListenerInterface{

    public ProgressDialog mProgressDialog = null;
    public TextView mTextGermanyFiscalElement = null;
    public ScrollView mScrollView = null;
    public GermanyFiscalElementFragment() {
    }

    //Indicator
    // Begin progress dialog
    public void beginProgress(String msg){
        if(mProgressDialog != null){
            changeProgress(msg);
            return;
        }

        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mProgressDialog = new ProgressDialog(getActivity());
                mProgressDialog.setIndeterminate(true);
                mProgressDialog.setCanceledOnTouchOutside(false);
                mProgressDialog.setMessage(msg);
                mProgressDialog.show();
            }
        });
    }

    // Change progress dialog
    public void changeProgress(String msg){
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mProgressDialog.setMessage(msg);
                mProgressDialog.show();
            }
        });
    }

    // End progress dialog
    protected void endProgress(){
        getActivity().runOnUiThread(new Runnable() {
            @Override
            public void run() {
                mProgressDialog.dismiss();
                mProgressDialog = null;
            }
        });
    }

    public boolean operateGetChallenge(Epos2SdkMgr sdkManager, String userId)
    {
        String jsonFunc_tmp= getString(R.string.operate_func_getChallenge);

        String jsonFunc_getChallenge = String.format((String)jsonFunc_tmp, userId);
        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_getChallenge, GermanyFiscalElement.PARAM_DEFAULT, getActivity());

        return result;
    }

    public boolean operateAuthenticateUserForAdmin(Epos2SdkMgr sdkManager, String hash)
    {
        String jsonFunc_tmp = getString(R.string.operate_func_authenticateUserForAdmin);
        String userId = getString(R.string.administrator);
        String pin = getString(R.string.adminPin);

        String jsonFunc_authenticateUserForAdmin = String.format((String)jsonFunc_tmp, userId, pin, hash);
        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_authenticateUserForAdmin,GermanyFiscalElement.PARAM_DEFAULT, getActivity());

        return result;
    }

    public boolean operateLogOutForAdmin(Epos2SdkMgr sdkManager)
    {
        String jsonFunc_tmp = getString(R.string.operate_func_logOutForAdmin);
        String userId = getString(R.string.administrator);

        String jsonFunc_logOutForAdmin = String.format((String)jsonFunc_tmp, userId, getActivity());
        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_logOutForAdmin, GermanyFiscalElement.PARAM_DEFAULT, getActivity());

        return result;
    }

    public boolean operateAuthenticateUserForTimeAdmin(Epos2SdkMgr sdkManager, String hash)
    {
        String jsonFunc_tmp= getString(R.string.operate_func_authenticateUserForTimeAdmin);
        String pin = getString(R.string.timeAdminPin);

        String jsonFunc_authenticateUserForTimeAdmin = String.format((String)jsonFunc_tmp, clientId, pin ,hash);
        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_authenticateUserForTimeAdmin, GermanyFiscalElement.PARAM_DEFAULT, getActivity());
        return result;
    }

    public boolean operateLogOutForTimeAdmin(Epos2SdkMgr sdkManager)
    {
        String jsonFunc_tmp= getString(R.string.operate_func_logOutForTimeAdmin);

        String jsonFunc_logOutForTimeAdmin = String.format((String)jsonFunc_tmp, clientId, getActivity());
        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_logOutForTimeAdmin, GermanyFiscalElement.PARAM_DEFAULT, getActivity());

        return result;
    }

    public String convertBase64String(byte[] data) {
        String base64EncodedString = "";
        if (data == null) {
            return null;
        }
        try{
            byte[] encode = Base64.encode(data, Base64.NO_WRAP);
            base64EncodedString = new String(encode, "UTF-8");
        }catch (Exception e){
        }
        return base64EncodedString;
    }

    public String calculateHash(String input)
    {
        String hashString = null;
        if(input == null) {
            return null;
        }
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-256");
            byte[] result = digest.digest(input.getBytes());
            String sha256 = String.format("%040x", new BigInteger(1, result));
            hashString = convertBase64String(hexStringToByteArray(sha256));
        } catch (Exception e){
        }
        return hashString;
    }

    public JSONObject parseJson(String targetJson)
    {
        JSONObject json = null;
        if(targetJson == null) {
            return null;
        }
        try{
            String utf8EncodedString = new String(targetJson.getBytes("UTF-8"), "UTF-8");
            json = new JSONObject(utf8EncodedString);
        }catch (Exception e){
        }
        return json;
    }

    public String getJsonString(JSONObject json, String key)
    {
        String jsonString = null;
        if(json == null || key == null)
        {
            return null;
        }

        try{
            jsonString = json.getString(key);
        }catch (Exception e){
        }
        return jsonString;
    }

    public JSONObject getJsonOutputInfo(JSONObject json)
    {
        JSONObject jsonOutputInfo = null;
        if(json == null)
        {
            return null;
        }
        try{
            jsonOutputInfo = json.getJSONObject("output");
        }catch (Exception e){
        }

        return jsonOutputInfo;
    }

    public JSONObject getJsonTseInformation(JSONObject json)
    {
        JSONObject jsonTseInformation = null;
        if(json == null)
        {
            return null;
        }
        try{
            jsonTseInformation = json.getJSONObject("tseInformation");
        }catch (Exception e){
        }

        return jsonTseInformation;
    }

    private static byte[] hexStringToByteArray(String s) {
        if(s == null){
            return null;
        }
        int len = s.length();
        byte[] data = new byte[len/2];

        for(int i = 0; i < len; i+=2){
            data[i/2] = (byte) ((Character.digit(s.charAt(i), 16) << 4) + Character.digit(s.charAt(i+1), 16));
        }

        return data;
    }

    @Override
    public void onDiscoveryResult(final DeviceInfo deviceInfo){
        /* do nothing. */
    }
    @Override
    public void onGfeReceiveEPOS2SDKManager(final GermanyFiscalElement GfeObj, final int code, final String data){
        /* do nothing. */
    }
    @Override
    public void onPtrReceiveResult(final Printer printerObj, final int code, final PrinterStatusInfo status, final String printJobId){
        /* do nothing. */
    }
    @Override
    public void onFirmwareListDownloadResult(final int code, FirmwareInfo[] firmwareList){
        /* do nothing. */
    }
    @Override
    public void onFirmwareInformationReceiveResult(FirmwareInfo firmwareInfo){
        /* do nothing. */
    }
    @Override
    public void onFirmwareUpdateProgressResult(String task, float progress){
        /* do nothing. */
    }
    @Override
    public void onFirmwareUpdateResult(final int code, int maxWaitTime){
        /* do nothing. */
    }
    @Override
    public void onUpdateVerifyResult(final int code){
        /* do nothing. */
    }
    @Override
    public void onDispReceiveResult(final LineDisplay LineDisplayObj, final int code){
        /* do nothing. */
    }
    @Override
    public void onScanDataResult(final BarcodeScanner scanObj, final String data){
        /* do nothing. */
    }
    @Override
    public void onLogEPOS2SDKManager(final String apiLog){
        /* do nothing. */
    }
    @Override
    public void onConnectionResult(final Object printerObj, final int code){
        /* do nothing. */
    }
}
