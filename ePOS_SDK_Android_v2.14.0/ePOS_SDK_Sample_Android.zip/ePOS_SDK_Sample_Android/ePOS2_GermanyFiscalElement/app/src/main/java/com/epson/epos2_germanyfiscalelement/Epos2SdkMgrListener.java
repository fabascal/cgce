package com.epson.epos2_germanyfiscalelement;

import com.epson.epos2.barcodescanner.BarcodeScanner;
import com.epson.epos2.discovery.DeviceInfo;
import com.epson.epos2.germanyfiscalelement.GermanyFiscalElement;
import com.epson.epos2.linedisplay.LineDisplay;
import com.epson.epos2.printer.FirmwareInfo;
import com.epson.epos2.printer.Printer;
import com.epson.epos2.printer.PrinterStatusInfo;

import java.util.ArrayList;

public class Epos2SdkMgrListener {
    private Epos2SdkMgrListenerInterface listenerInterface;

    public void setListener(Epos2SdkMgrListenerInterface listenerInterface){
        this.listenerInterface = listenerInterface;
    }

    public void removeListener(){
        this.listenerInterface = null;
    }

    public void onDiscovery(final DeviceInfo deviceInfo) {
        this.listenerInterface.onDiscoveryResult(deviceInfo);
    }

    public void onGfeReceive(final GermanyFiscalElement GfeObj, final int code, final String printJobId) {
        this.listenerInterface.onGfeReceiveEPOS2SDKManager(GfeObj, code, printJobId);
    }

    public void onPtrReceive(final Printer printerObj, final int code, final PrinterStatusInfo status, final String printJobId) {
        this.listenerInterface.onPtrReceiveResult(printerObj, code, status, printJobId);
    }

    public void onFirmwareListDownload(final int code, FirmwareInfo[] firmwareList) {
        this.listenerInterface.onFirmwareListDownloadResult(code, firmwareList);
    }

    public void onFirmwareInformationReceive(FirmwareInfo firmwareInfo) {
        this.listenerInterface.onFirmwareInformationReceiveResult(firmwareInfo);
    }

    public void onFirmwareUpdate(final int code, int maxWaitTime) {
        this.listenerInterface.onFirmwareUpdateResult(code, maxWaitTime);
    }

    public void onFirmwareUpdateProgress(String task, float progress) {
        this.listenerInterface.onFirmwareUpdateProgressResult(task, progress);
    }

    public void onUpdateVerify(final int code) {
        this.listenerInterface.onUpdateVerifyResult(code);
    }

    public void onDispReceive(final LineDisplay LineDisplayObj, final int code) {
        this.listenerInterface.onDispReceiveResult(LineDisplayObj, code);
    }

    public void onScanData(final BarcodeScanner scanObj, final String data) {
        this.listenerInterface.onScanDataResult(scanObj, data);
    }

    public void onApiLog(String apiLog){
        this.listenerInterface.onLogEPOS2SDKManager(apiLog);
    }

    public void onConnection(final Object printerObj, final int code) {

        this.listenerInterface.onConnectionResult(printerObj, code);
    }
}

