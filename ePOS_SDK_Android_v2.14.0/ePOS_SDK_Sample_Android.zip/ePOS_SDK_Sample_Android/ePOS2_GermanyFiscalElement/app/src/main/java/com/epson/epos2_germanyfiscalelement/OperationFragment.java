package com.epson.epos2_germanyfiscalelement;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ScrollView;
import android.widget.ToggleButton;

import com.epson.epos2.barcodescanner.BarcodeScanner;
import com.epson.epos2.germanyfiscalelement.GermanyFiscalElement;
import com.epson.epos2.linedisplay.LineDisplay;
import com.epson.epos2.printer.Printer;
import com.epson.epos2.printer.PrinterStatusInfo;

import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.ReentrantLock;
import java.util.Date;
import java.text.SimpleDateFormat;
import org.json.JSONObject;
import static com.epson.epos2_germanyfiscalelement.MainActivity.targetBarcodeScanner;
import static com.epson.epos2_germanyfiscalelement.MainActivity.targetGermanyFiscalElement;
import static com.epson.epos2_germanyfiscalelement.MainActivity.targetLineDisplay;
import static com.epson.epos2_germanyfiscalelement.MainActivity.targetPrinter;
import static com.epson.epos2_germanyfiscalelement.MainActivity.printerSeries;
import static com.epson.epos2_germanyfiscalelement.MainActivity.clientId;

public class OperationFragment extends GermanyFiscalElementFragment implements View.OnClickListener{

    private View rootView;
    private Button mBtnOpenStore = null;
    private Button mBtnCloseStore = null;
    private Button mBtnItem1 = null;
    private Button mBtnItem2 = null;
    private Button mBtnItem3 = null;
    private Button mBtnItem4 = null;
    private Button mBtnItem5 = null;
    private Button mBtnItem6 = null;
    private Button mBtnItem7 = null;
    private Button mBtnItem8 = null;
    private Button mBtnItem9 = null;
    private Button mBtnItem10 = null;
    private Button mBtnCheck = null;
    private boolean isCompletedStartTransaction = false;
    private boolean isEnabledLineDisplay = false;
    private boolean isEnabledBarcodeScanner = false;
    private Object queueForSDK = null;
    private Semaphore gfeSemaphore = null;
    private Semaphore prnSemaphore = null;
    private Semaphore dspSemaphore = null;
    private Semaphore timerSemaphore = null;
    private Thread timerThread = null;
    private int responseLimitTime = 10000;
    private int registrationLimitTime = 30000;
    private PurchaseItemList itemList = null;
    private String challenge = "";
    private String signature = "";
    private String startDateTime = "";
    private String endDateTime = "";
    private int transactionNumber = 0;

    private ReentrantLock timerLock = null;
    private ReentrantLock startTransactionLock = null;
    public Epos2SdkMgr sdkManager = null;
    public Epos2SdkMgrListener sdkMgrListener = null;

    public static OperationFragment newInstance() {
        return new OperationFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // Inflate the layout for this fragment
        rootView = inflater.inflate(R.layout.fragment_operation, container, false);
        mBtnOpenStore = (Button) rootView.findViewById(R.id.btnOpenStore);
        mBtnCloseStore = (Button) rootView.findViewById(R.id.btnCloseStore);
        mBtnItem1 = (Button) rootView.findViewById(R.id.btnItem1);
        mBtnItem2 = (Button) rootView.findViewById(R.id.btnItem2);
        mBtnItem3 = (Button) rootView.findViewById(R.id.btnItem3);
        mBtnItem4 = (Button) rootView.findViewById(R.id.btnItem4);
        mBtnItem5 = (Button) rootView.findViewById(R.id.btnItem5);
        mBtnItem6 = (Button) rootView.findViewById(R.id.btnItem6);
        mBtnItem7 = (Button) rootView.findViewById(R.id.btnItem7);
        mBtnItem8 = (Button) rootView.findViewById(R.id.btnItem8);
        mBtnItem9 = (Button) rootView.findViewById(R.id.btnItem9);
        mBtnItem10 = (Button) rootView.findViewById(R.id.btnItem10);
        mBtnCheck = (Button) rootView.findViewById(R.id.btnCheck);
        mBtnOpenStore.setOnClickListener(this);
        mBtnCloseStore.setOnClickListener(this);
        mBtnItem1.setOnClickListener(this);
        mBtnItem2.setOnClickListener(this);
        mBtnItem3.setOnClickListener(this);
        mBtnItem4.setOnClickListener(this);
        mBtnItem5.setOnClickListener(this);
        mBtnItem6.setOnClickListener(this);
        mBtnItem7.setOnClickListener(this);
        mBtnItem8.setOnClickListener(this);
        mBtnItem9.setOnClickListener(this);
        mBtnItem10.setOnClickListener(this);
        mBtnCheck.setOnClickListener(this);
        return rootView;
    }

   @Override
    public void onDestroyView() {
        destroyOperateFragment();
        super.onDestroyView();
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {
        if(rootView != null){
            if (isVisibleToUser) {
                initializeOperateFragment();
            } else {
                destroyOperateFragment();
            }
        }
    }

    public void initializeOperateFragment(){
        mTextGermanyFiscalElement = rootView.findViewById(R.id.textView_operationText);
        mScrollView = rootView.findViewById(R.id.scrollView_operation);
        buttonItemInit();
        timerLock = new ReentrantLock();
        startTransactionLock = new ReentrantLock();
        gfeSemaphore = new Semaphore(1);
        prnSemaphore = new Semaphore(1);
        dspSemaphore = new Semaphore(1);
        timerSemaphore = new Semaphore(1);
        itemList = new PurchaseItemList();
        itemList.init(getActivity());
        isCompletedStartTransaction = false;
        queueForSDK = new Object();
        sdkMgrListener = new Epos2SdkMgrListener();
        sdkMgrListener.setListener(this);
        sdkManager = Epos2SdkMgr.newInstance(sdkMgrListener);

        synchronized (queueForSDK){
            sdkManager.initializePrinterObject(getActivity(), printerSeries);
            sdkManager.initializeGfeObject(getActivity());
            sdkManager.initializeDisplayObject(getActivity());
            sdkManager.initializeScannerObject(getActivity());
        }
    }

    public void destroyOperateFragment(){
        buttonItemInit();
        mTextGermanyFiscalElement.setText("");
        if(queueForSDK != null){
            synchronized (queueForSDK){
                finalizeAllDevices();
            }
        }
        timerLock = null;
        startTransactionLock = null;
        gfeSemaphore = null;
        prnSemaphore = null;
        dspSemaphore = null;
        timerSemaphore = null;
        if(itemList != null){
            itemList.finalize();
        }
        itemList = null;
        challenge = null;
        queueForSDK = null;
        if(sdkMgrListener != null){
            sdkMgrListener.removeListener();
            sdkMgrListener.setListener(null);
            sdkMgrListener = null;
        }
        sdkManager = null;
    }

    private void buttonItemInit()
    {
        mBtnOpenStore.setEnabled(true);
        mBtnCloseStore.setEnabled(false);
        mBtnCheck.setEnabled(false);
        buttonItemEnable(false);
    }

    private void buttonItemEnable( boolean enable)
    {
        if(enable) {
            mBtnItem1.setEnabled(true);
            mBtnItem2.setEnabled(true);
            mBtnItem3.setEnabled(true);
            mBtnItem4.setEnabled(true);
            mBtnItem5.setEnabled(true);
            mBtnItem6.setEnabled(true);
            mBtnItem7.setEnabled(true);
            mBtnItem8.setEnabled(true);
            mBtnItem9.setEnabled(true);
            mBtnItem10.setEnabled(true);
        } else {
            mBtnItem1.setEnabled(false);
            mBtnItem2.setEnabled(false);
            mBtnItem3.setEnabled(false);
            mBtnItem4.setEnabled(false);
            mBtnItem5.setEnabled(false);
            mBtnItem6.setEnabled(false);
            mBtnItem7.setEnabled(false);
            mBtnItem8.setEnabled(false);
            mBtnItem9.setEnabled(false);
            mBtnItem10.setEnabled(false);
        }
    }

    private boolean enqueueStartTransaction()
    {
        new Thread (() -> {
            startTransactionLock.lock();
            if(!isCompletedStartTransaction) {
                beginProgress(getActivity().getString(R.string.progress_msg));
                synchronized (queueForSDK) {
                    operateStartTransaction();
                    endProgress();
                }
            }
            if(startTransactionLock.isHeldByCurrentThread()){
                startTransactionLock.unlock();
            }
        }).start();
        return true;
    }

    private boolean startTimeMeasurement()
    {
        if(isCompletedStartTransaction){
            timerThread = new Thread(() -> {
                if(timerLock.tryLock()) {
                    waitCallbackEvent(timerSemaphore, registrationLimitTime, new Object() {}.getClass().getEnclosingMethod().getName());
                    synchronized (queueForSDK) {
                        operateUpdateTransaction();
                        if(timerLock.isHeldByCurrentThread()){
                            timerLock.unlock();
                        }
                    }
                }
            });
            timerThread.start();
        }
        return true;
    }

    private void finalizeAllDevices()
    {
        sdkManager.finalizeGfeObject();
        sdkManager.finalizePrinterObject();
        if(isEnabledBarcodeScanner){
            sdkManager.finalizeScannerObject();
        }
        if(isEnabledLineDisplay){
            sdkManager.finalizeDisplayObject();
        }
    }

    private boolean disconnectAllDevices()
    {
        Boolean result = true;

        if(!sdkManager.disconnectGermanyFiscalElement()) {
            result = false;
        }

        if(!sdkManager.disconnectPrinter()){
            result = false;
        }

        if(isEnabledBarcodeScanner){
            if(!sdkManager.disconnectBarcodeScanner()){
                result = false;
            }
        }

        if(isEnabledLineDisplay){
            if(!sdkManager.disconnectLineDisplay()){
                result = false;
            }
        }
        return result;
    }

    private boolean operateUpdateTime()
    {
        String jsonFunc_tmp = getString(R.string.operate_func_updateTime);
        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat( "yyyy-MM-dd'T'HH:mm:ss'Z'");
        String newDateTime = formatter.format(date);

        String jsonFunc_updateTime = String.format((String)jsonFunc_tmp, clientId, newDateTime);

        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_updateTime, Printer.PARAM_DEFAULT, getActivity());
        if(result == true){
            result = waitCallbackEvent(gfeSemaphore, responseLimitTime, new Object(){}.getClass().getEnclosingMethod().getName());
        }
        return result;
    }

    private boolean operateAuthenticateUserForTimeAdmin()
    {
        // GetChallenge
        boolean result = operateGetChallenge(sdkManager, clientId);
        if(result == true) {
            result = waitCallbackEvent(gfeSemaphore, responseLimitTime, new Object(){}.getClass().getEnclosingMethod().getName());

            if(result == true){
                // Hash calculationTime
                String secretKey = getString(R.string.secretKey);
                String input = challenge + secretKey;
                String hash = calculateHash(input);
                result = operateAuthenticateUserForTimeAdmin(sdkManager, hash);

                if(result == true) {
                    result = waitCallbackEvent(gfeSemaphore, responseLimitTime, new Object(){}.getClass().getEnclosingMethod().getName());
                }
            }
        }
        return result;
    }

    private boolean operateLogOutForTimeAdmin()
    {
        boolean result = operateLogOutForTimeAdmin(sdkManager);
        if(result == true) {
            result = waitCallbackEvent(gfeSemaphore, responseLimitTime, new Object(){}.getClass().getEnclosingMethod().getName());
        }
        return result;
    }

    private boolean operateStartTransaction()
    {
        String jsonFunc_tmp= getString(R.string.operate_func_startTransaction);
        String processData = convertBase64String(itemList.createTransactionData().getBytes());
        String processDataType = getString(R.string.processTypeStart);

        String jsonFunc_startTransaction = String.format((String)jsonFunc_tmp, clientId, processData ,processDataType);

        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat( "dd-MM-yyyy-HH:mm:ss");
        startDateTime = formatter.format(date);

        boolean result = sdkManager.operateGermanyFiscalElement((String)jsonFunc_startTransaction, GermanyFiscalElement.PARAM_DEFAULT, getActivity());
        if(result == true) {
            result = waitCallbackEvent(gfeSemaphore, responseLimitTime, new Object(){}.getClass().getEnclosingMethod().getName());
            isCompletedStartTransaction = true;
        }
        return result;
    }

    private boolean operateUpdateTransaction()
    {
        String jsonFunc_tmp= getString(R.string.operate_func_updateTransaction);
        String processData = convertBase64String(itemList.createTransactionData().getBytes());
        String processDataType = getString(R.string.processTypeUpdate);

        String jsonFunc_updateTransaction = String.format(jsonFunc_tmp, clientId, transactionNumber, processData ,processDataType);
        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_updateTransaction,GermanyFiscalElement.PARAM_DEFAULT, getActivity());
        if(result == true) {
            result = waitCallbackEvent(gfeSemaphore, responseLimitTime, new Object(){}.getClass().getEnclosingMethod().getName());
        }
        return result;
    }

    private boolean operateFinishTransaction()
    {
        String jsonFunc_tmp= getString(R.string.operate_func_finishTransaction);
        String tmpProcessData = itemList.createTransactionData();
        tmpProcessData = tmpProcessData + "[TOTAL,";
        tmpProcessData = tmpProcessData + itemList.createTotalAmountData();
        tmpProcessData = tmpProcessData + "]";
        tmpProcessData = tmpProcessData + "[PAYMENT,";
        tmpProcessData = tmpProcessData + itemList.createTotalAmountData();
        tmpProcessData = tmpProcessData + "]";
        String processData = convertBase64String(tmpProcessData.getBytes());
        String processDataType = getString(R.string.processTypeFinish);
        String jsonFunc_finishTransaction = String.format(jsonFunc_tmp, clientId, transactionNumber, processData, processDataType);

        Date date = new Date();
        SimpleDateFormat formatter = new SimpleDateFormat( "dd-MM-yyyy-HH:mm:ss");
        endDateTime = formatter.format(date);

        boolean result = sdkManager.operateGermanyFiscalElement(jsonFunc_finishTransaction, GermanyFiscalElement.PARAM_DEFAULT, getActivity());
        if(result == true) {
            result =waitCallbackEvent(gfeSemaphore, responseLimitTime, new Object(){}.getClass().getEnclosingMethod().getName());
        }
        return result;
    }

    private boolean createReceiptData()
    {
        String receiptData = "";
        // Prefix
        sdkManager.addTextAlignPrinter(Printer.ALIGN_CENTER);
        sdkManager.addImagePrinter(getActivity());
        sdkManager.addFeedLinePrinter(1);

        receiptData += "THE STORE 123 (555) 555 – 5555\n";
        receiptData += "STORE DIRECTOR – John Smith\n";
        receiptData += "\n";
        receiptData += "7/01/07 16:58 6153 05 0191 134\n";
        receiptData += "ST# 21 OP# 001 TE# 01 TR# 747\n";
        receiptData += "------------------------------\n";
        sdkManager.addTextPrinter(receiptData);
        receiptData = "";

        // Receipt Data
        sdkManager.addTextAlignPrinter(Printer.ALIGN_LEFT);
        receiptData += itemList.createReceiptData();
        sdkManager.addTextPrinter(receiptData);
        receiptData = "";

        sdkManager.addTextAlignPrinter(Printer.ALIGN_CENTER);
        receiptData += "------------------------------\n";
        sdkManager.addTextPrinter(receiptData);
        receiptData = "";

        // Suffix
        sdkManager.addTextSizePrinter(2 , 2);
        receiptData += "TOTAL         €";
        receiptData += itemList.createTotalAmountData();
        receiptData += "\n";
        sdkManager.addTextPrinter(receiptData);
        receiptData = "";

        sdkManager.addTextAlignPrinter(Printer.ALIGN_LEFT);
        sdkManager.addTextSizePrinter(1, 1);
        sdkManager.addFeedLinePrinter(1);
        receiptData += "       CASH                       €";
        receiptData += itemList.createTotalAmountData();
        receiptData += "\n";
        receiptData += "       CHANGE                     €0\n";
        sdkManager.addTextPrinter(receiptData);
        receiptData = "";

        sdkManager.addTextAlignPrinter(Printer.ALIGN_CENTER);
        receiptData += "------------------------------\n";
        receiptData += "Purchased item total number\n";
        receiptData += "Sign Up and Save !\n";
        receiptData += "With Preferred Saving Card\n";
        receiptData += "------------------------------\n";
        sdkManager.addTextPrinter(receiptData);
        receiptData = "";

        sdkManager.addTextAlignPrinter(Printer.ALIGN_LEFT);
        receiptData += "TransactionNumber:";
        receiptData += String.format("%d\n", transactionNumber);
        receiptData += "Signature:\n";
        receiptData += signature;
        receiptData += "TSE SerialNumber:\n";
        receiptData += "    DemoSerialNumberDemoSerialNumber\n";
        receiptData += "StartDate:";
        receiptData += startDateTime;
        receiptData += "\n";
        receiptData += "EndDate  :";
        receiptData += endDateTime;
        sdkManager.addTextPrinter(receiptData);
        receiptData = "";

        sdkManager.addFeedLinePrinter(2);
        sdkManager.addTextAlignPrinter(Printer.ALIGN_CENTER);
        sdkManager.addBarcodePrinter();
        sdkManager.addCutPrinter();

        return true;
    }

    private boolean printReceipt()
    {

        boolean result = sdkManager.sendDataPrinter();
        if(result == true){
            result = waitCallbackEvent(prnSemaphore, responseLimitTime, new Object(){}.getClass().getEnclosingMethod().getName());
            sdkManager.clearCommandBufferPrinter();
        }
        return result;
    }

    @Override
    public void onClick(View v) {
        if(itemList == null){
            return;
        }

        String itemCode = null;
        switch (v.getId()) {
            case R.id.btnOpenStore:
                openStore();
                break;
            case R.id.btnCloseStore:
                closeStore();
                break;
            case R.id.btnItem1:
                itemCode = getString(R.string.item1Code);
                break;
            case R.id.btnItem2:
                itemCode = getString(R.string.item2Code);
                break;
            case R.id.btnItem3:
                itemCode = getString(R.string.item3Code);
                break;
            case R.id.btnItem4:
                itemCode = getString(R.string.item4Code);
                break;
            case R.id.btnItem5:
                itemCode = getString(R.string.item5Code);
                break;
            case R.id.btnItem6:
                itemCode = getString(R.string.item6Code);
                break;
            case R.id.btnItem7:
                itemCode = getString(R.string.item7Code);
                break;
            case R.id.btnItem8:
                itemCode = getString(R.string.item8Code);
                break;
            case R.id.btnItem9:
                itemCode = getString(R.string.item9Code);
                break;
            case R.id.btnItem10:
                itemCode = getString(R.string.item10Code);
                break;
            case R.id.btnCheck:
                check();
                break;
            default:
                // Do nothing
                break;
        }

        if(itemCode != null) {
            enqueueStartTransaction();
            startTimeMeasurement();
            itemList.incrementItemCount(itemCode);
            mBtnCheck.setEnabled(true);
            mBtnCloseStore.setEnabled(false);

            if(isEnabledLineDisplay) {
                synchronized (queueForSDK){
                    boolean result = sdkManager.indicateDisplay(itemList.createItemData(itemCode));
                    if(result == true) {
                        waitCallbackEvent(dspSemaphore, responseLimitTime, new Object(){}.getClass().getEnclosingMethod().getName());
                    }
                }
            }
        }
        return;
    }

    private void openStore() {
        new Thread (() -> {
            synchronized (queueForSDK){
                beginProgress(getActivity().getString(R.string.progress_msg));

                //Get setting information from SettingFragment
                isEnabledLineDisplay = ((ToggleButton)(getActivity().findViewById(R.id.toggle_display))).isChecked();
                isEnabledBarcodeScanner = ((ToggleButton)(getActivity().findViewById(R.id.toggle_scanner))).isChecked();

                boolean result = sdkManager.connectPrinter(targetPrinter);
                if(result == true){
                    result = sdkManager.connectGermanyFiscalElement(targetGermanyFiscalElement);
                }

                if(result == true){
                    result = operateAuthenticateUserForTimeAdmin();
                    if(result == true){
                        result = operateUpdateTime();
                    }
                }
                if(result == true && isEnabledLineDisplay){
                    result = sdkManager.connectLineDisplay(targetLineDisplay);
                }
                if(result == true && isEnabledBarcodeScanner){
                    result = sdkManager.connectBarcodeScanner(targetBarcodeScanner);
                }

                if(result == true){
                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mBtnOpenStore.setEnabled(false);
                            mBtnCloseStore.setEnabled(true);
                            mBtnCheck.setEnabled(false);
                            if(!isEnabledBarcodeScanner){
                                buttonItemEnable(true);
                            }
                        }
                    });
                }else{
                    disconnectAllDevices();
                }

                endProgress();
            }
        }).start();
    }

    public void closeStore() {
        new Thread (() -> {
            synchronized (queueForSDK){
                beginProgress(getActivity().getString(R.string.progress_msg));

                itemList.clearItemCount();

                operateLogOutForTimeAdmin();
                disconnectAllDevices();

                getActivity().runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        mBtnOpenStore.setEnabled(true);
                        mBtnCloseStore.setEnabled(false);
                        mBtnCheck.setEnabled(false);
                        if(!isEnabledBarcodeScanner){
                            buttonItemEnable(false);
                        }
                    }
                });
                endProgress();
            }
        }).start();
    }

    private void check() {
        new Thread (() -> {
            beginProgress(getActivity().getString(R.string.progress_msg));
            if(timerThread!= null && timerThread.isAlive()){
                synchronized (timerSemaphore){
                    timerSemaphore.notify();
                }
                try{
                    timerThread.join(responseLimitTime);
                }catch(Exception e){
                }
            }

            synchronized (queueForSDK) {
                boolean result = true;
                if(isEnabledLineDisplay){
                    String displayData = "TOTAL      €";
                    displayData += itemList.createTotalAmountData();
                    result = sdkManager.indicateDisplay(displayData);
                    if(result == true) {
                        waitCallbackEvent(dspSemaphore, responseLimitTime, new Object(){}.getClass().getEnclosingMethod().getName());
                    }
                }

                // Payment...
                if(result == true){
                    operateFinishTransaction();

                }

                // Print Receipt
                if(result == true){
                    if(createReceiptData()) {
                        result = printReceipt();
                    }
                }

                if(result ==  true){
                    isCompletedStartTransaction = false;
                    itemList.clearItemCount();

                    getActivity().runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            mBtnCheck.setEnabled(false);
                            mBtnCloseStore.setEnabled(true);
                        }
                    });
                }

                endProgress();
            }
        }).start();
    }


    @Override
    public void onGfeReceiveEPOS2SDKManager(final GermanyFiscalElement GfeObj, final int code, final String data){
        String viewText = String.format("onGfeReceive:\n");
        viewText += String.format("  code:%s\n", sdkManager.getEposErrorText(code));
        viewText += String.format("  data:%s\n", data);
        appendTextView(viewText);

        JSONObject json = parseJson(data);
        String result = getJsonString(json, "result");
        if(result != null){
            if(result.equals("EXECUTION_OK")) {
                String function = getJsonString(json, "function");

                if(function.equals("GetChallenge")) {
                    String tmpChallenge = getJsonString(getJsonOutputInfo(json), "challenge");
                    if(tmpChallenge != null) {
                        challenge = tmpChallenge;
                    }
                }

                if(function.equals("StartTransaction")) {
                    String transactionNum = getJsonString(getJsonOutputInfo(json), "transactionNumber");
                    if(transactionNum != null) {
                        transactionNumber = Integer.parseInt(transactionNum);
                    }
                }

                if(function.equals("FinishTransaction")) {
                    String tmpSignature = getJsonString(getJsonOutputInfo(json), "signature");
                    if(tmpSignature != null) {
                        signature = tmpSignature;
                    }
                }
            }
        }

        synchronized (gfeSemaphore){
            gfeSemaphore.notify();
        }
    }
    @Override
    public void onPtrReceiveResult(final Printer printerObj, final int code, final PrinterStatusInfo status, final String printJobId){
        String viewText = String.format("onPtrReceive:\n");
        viewText += String.format("  code:%s\n", sdkManager.getEposErrorText(code));
        appendTextView(viewText);
        if(prnSemaphore != null) {
            synchronized (prnSemaphore){
                prnSemaphore.notify();
            }
        }
    }
    @Override
    public void onDispReceiveResult(final LineDisplay LineDisplayObj, final int code){
        String viewText = String.format("onDispReceive:\n");
        viewText += String.format("  code:%s\n", sdkManager.getEposErrorText(code));
        appendTextView(viewText);
        if(dspSemaphore != null) {
            synchronized (dspSemaphore){
                dspSemaphore.notify();
            }
        }
    }
    @Override
    public void onScanDataResult(final BarcodeScanner scanObj, final String data){
        if(data == null) {
            return;
        }
        String viewText = String.format("onScanData:\n");
        viewText += String.format("  data:%s\n", data);
        appendTextView(viewText);

        // register Item count;
        enqueueStartTransaction();
        startTimeMeasurement();
        itemList.incrementItemCount(data);
        getActivity().runOnUiThread(new Runnable() {
            public synchronized void run() {
                mBtnCheck.setEnabled(true);
                mBtnCloseStore.setEnabled(false);
            }
        });

        if(isEnabledLineDisplay) {
            new Thread (() -> {
                synchronized (queueForSDK) {
                    boolean result = sdkManager.indicateDisplay(itemList.createItemData(data));
                    if (result == true) {
                        waitCallbackEvent(dspSemaphore, responseLimitTime, new Object() {
                        }.getClass().getEnclosingMethod().getName());
                    }
                }
            }).start();
        }
    }

    private boolean waitCallbackEvent(Object semaphore, int timeout, String method){
        if(method == null){
            return false;
        }
        synchronized (semaphore) {
            try {
                semaphore.wait(timeout);
            } catch (Exception e) {
                sdkManager.showError(getActivity().getString(R.string.error_msg), method);
                return false;
            }
        }
        return true;
    }

    @Override
    public void onLogEPOS2SDKManager(final String apiLog){
        if(apiLog != null){
            appendTextView(apiLog);
        }
    }

    private void appendTextView(String text){
        if(text == null){
            return;
        }
        getActivity().runOnUiThread(new Runnable() {
            public synchronized void run() {
                mTextGermanyFiscalElement.append(text);
                mScrollView.post(new Runnable(){
                    public void run()
                    {
                        mScrollView.fullScroll(ScrollView.FOCUS_DOWN);
                    }
                });
            }
        });
    }

}
