package com.epson.epos2_germanyfiscalelement;
import android.content.Context;

import java.util.ArrayList;
import java.util.List;

public class PurchaseItemList {
    List<PurchaseItems> items;

    PurchaseItems item1;
    PurchaseItems item2;
    PurchaseItems item3;
    PurchaseItems item4;
    PurchaseItems item5;
    PurchaseItems item6;
    PurchaseItems item7;
    PurchaseItems item8;
    PurchaseItems item9;
    PurchaseItems item10;


    public void init(Context context) {
        item1 = (new PurchaseItems()).initItem(context.getString(R.string.item1Code), context.getString(R.string.btn_item1Name), (float) 7.90);
        item2 = (new PurchaseItems()).initItem(context.getString(R.string.item2Code), context.getString(R.string.btn_item2Name), (float) 9.39);
        item3 = (new PurchaseItems()).initItem(context.getString(R.string.item3Code), context.getString(R.string.btn_item3Name), (float) 8.06);
        item4 = (new PurchaseItems()).initItem(context.getString(R.string.item4Code), context.getString(R.string.btn_item4Name), (float) 10.95);
        item5 = (new PurchaseItems()).initItem(context.getString(R.string.item5Code), context.getString(R.string.btn_item5Name), (float) 8.21);
        item6 = (new PurchaseItems()).initItem(context.getString(R.string.item6Code), context.getString(R.string.btn_item6Name), (float) 20.34);
        item7 = (new PurchaseItems()).initItem(context.getString(R.string.item7Code), context.getString(R.string.btn_item7Name), (float) 16.19);
        item8 = (new PurchaseItems()).initItem(context.getString(R.string.item8Code), context.getString(R.string.btn_item8Name), (float) 21.91);
        item9 = (new PurchaseItems()).initItem(context.getString(R.string.item9Code), context.getString(R.string.btn_item9Name), (float) 16.35);
        item10 = (new PurchaseItems()).initItem(context.getString(R.string.item10Code), context.getString(R.string.btn_item10Name), (float) 23.47);
        createItemList();
        return;
    }

    public void finalize(){
        deleteItemList();
        item1 = null;
        item2 = null;
        item3 = null;
        item4 = null;
        item5 = null;
        item6 = null;
        item7 = null;
        item8 = null;
        item9 = null;
        item10 = null;
    }

    private void createItemList() {
        items = new ArrayList<PurchaseItems>();
        if (items != null) {
            items.add(item1);
            items.add(item2);
            items.add(item3);
            items.add(item4);
            items.add(item5);
            items.add(item6);
            items.add(item7);
            items.add(item8);
            items.add(item9);
            items.add(item10);
        }
    }

    private void deleteItemList()
    {
        if(items != null) {
            items.removeAll(items);
            items = null;
        }
    }


    private int getItemsCount()
    {
        if(items != null) {
            return items.size();
        } else {
            return 0;
        }
    }

    private int getItemIndex(String itemCode)
    {
        if(items == null || itemCode == null) {
            return -1;
        }

        int index = 0;
        PurchaseItems item = null;
        String tmpItemCode = null;
        for(int i=0; i< getItemsCount(); i++) {
            item = items.get(i);
            if(item == null) {
                return -1;
            }
            tmpItemCode = item.getItemCode();
            if(tmpItemCode.equals(itemCode)) {
                index = i;
                break;
            }
        }

        return index;
    }

    private PurchaseItems getItem(int index)
    {
        if(items == null) {
            return null;
        }

        return items.get(index);
    }

    private String getItemName(String itemCode)
    {
        if(itemCode == null) {
            return null;
        }

        int index = getItemIndex(itemCode);
        PurchaseItems item = getItem(index);

        return item.getItemName();
    }

    private float getItemValue(String itemCode)
    {
        if(itemCode == null) {
            return 0;
        }
        int index = getItemIndex(itemCode);
        PurchaseItems item = getItem(index);
        return item.getItemValue();
    }

    public void clearItemCount()
    {
        if(items == null) {
            return;
        }
        PurchaseItems item = null;
        for(int i = 0; i < getItemsCount(); i++) {
            item = getItem(i);
            item.setItemCount(0);
        }
    }
    public void incrementItemCount(String itemCode)
    {
        if(itemCode == null) {
            return;
        }

        int index = getItemIndex(itemCode);
        PurchaseItems item = getItem(index);

        int tmpItemCount = item.getItemCount();
        tmpItemCount++;
        item.setItemCount(tmpItemCount);
    }


    public String createItemData(String itemCode)
    {
        if(itemCode == null) {
            return null;
        }

        int index = getItemIndex(itemCode);
        PurchaseItems item = getItem(index);

        String itemName = item.getItemName();
        String itemValue = String.format("  €%.2f\n", item.getItemValue());
        String itemData = itemName + itemValue;

        return itemData;
    }

    public String createTotalAmountData()
    {
        if(items == null) {
            return null;
        }

        PurchaseItems item = null;
        float totalAmount = 0;
        float tmpValue = 0;
        int tmpCount = 0;
        for(int i = 0; i < getItemsCount(); i++) {
            item = getItem(i);
            tmpCount = item.getItemCount();
            if(tmpCount > 0) {
                tmpValue = item.getItemValue();
                totalAmount += (tmpValue * tmpCount);
            }
        }
        return String.format("%.2f", totalAmount);
    }

    public String createTransactionData()
    {
        if(items == null) {
            return null;
        }

        PurchaseItems item = null;
        String data = "";
        String itemCode = null;
        String itemName = null;
        float itemValue = 0;
        int itemCount = 0;
        for(int i = 0; i < getItemsCount(); i++) {
            item = getItem(i);
            itemCode = item.getItemCode();
            if(itemCode == null) {
                return null;
            }
            itemName = item.getItemName();
            if(itemName == null) {
                return null;
            }
            itemValue = item.getItemValue();
            itemCount = item.getItemCount();
            data += String.format("[%s,%s,%.2f,%d]", itemCode, itemName, itemValue, itemCount);
        }
        return data;
    }

    public String createReceiptData()
    {
        if(items == null) {
            return null;
        }

        PurchaseItems item;
        String data = "";
        String itemCode;
        String itemName;
        float itemValue;
        int itemCount;

        for(int i = 0; i < getItemsCount(); i++) {
            item = getItem(i);
            itemCount = item.getItemCount();
            if(itemCount > 0) {
                itemCode = item.getItemCode();
                if(itemCode == null) {
                    return null;
                }
                itemName = item.getItemName();
                if(itemName == null) {
                    return null;
                }
                itemValue = (item.getItemValue() * itemCount);
                data += String.format(" %s %s       %d €%.2f\n", itemCode, itemName, itemCount, itemValue);
            }
        }
        return data;
    }
}
