package com.epson.epos2_germanyfiscalelement;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;

import com.epson.epos2.barcodescanner.BarcodeScanner;
import com.epson.epos2.discovery.DeviceInfo;
import com.epson.epos2.discovery.Discovery;
import com.epson.epos2.discovery.FilterOption;
import com.epson.epos2.Epos2Exception;
import com.epson.epos2.germanyfiscalelement.GermanyFiscalElement;
import com.epson.epos2.linedisplay.LineDisplay;
import com.epson.epos2.printer.FirmwareInfo;
import com.epson.epos2.printer.Printer;
import com.epson.epos2.printer.PrinterStatusInfo;

public class DiscoveryActivity extends Activity implements View.OnClickListener, AdapterView.OnItemClickListener, Epos2SdkMgrListenerInterface{

    private ArrayList<HashMap<String, String>> mPrinterList = null;
    private SimpleAdapter mPrinterListAdapter = null;
    private FilterOption mFilterOption = null;
    private Epos2SdkMgr sdkManager = null;
    private Epos2SdkMgrListener sdkMgrListener = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_discovery);

        Button button = (Button)findViewById(R.id.btnRestart);
        button.setOnClickListener(this);

        mPrinterList = new ArrayList<HashMap<String, String>>();
        mPrinterListAdapter = new SimpleAdapter(this, mPrinterList, R.layout.list_at,
                new String[] { "PrinterName", "Target" },
                new int[] { R.id.PrinterName, R.id.Target });
        ListView list = (ListView)findViewById(R.id.lstReceiveData);
        list.setAdapter(mPrinterListAdapter);
        list.setOnItemClickListener(this);

        mFilterOption = new FilterOption();
        mFilterOption.setDeviceType(Discovery.TYPE_PRINTER);
        mFilterOption.setEpsonFilter(Discovery.FILTER_NAME);
        sdkMgrListener = new Epos2SdkMgrListener();
        sdkMgrListener.setListener(this);
        sdkManager = new Epos2SdkMgr(sdkMgrListener);
        try {
            sdkManager.startDiscovery(this, mFilterOption);
        }
        catch (Exception e) {
        }
    }

    @Override
    public void onDestroy() {
        super.onDestroy();

        while (true) {
            try {
                Discovery.stop();
                break;
            }
            catch (Epos2Exception e) {
                if (e.getErrorStatus() != Epos2Exception.ERR_PROCESSING) {
                    break;
                }
            }
        }

        if(sdkMgrListener != null){
            sdkMgrListener.removeListener();
            sdkMgrListener.setListener(null);
            sdkMgrListener = null;
        }
        sdkManager = null;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btnRestart:
                restartDiscovery();
                break;

            default:
                // Do nothing
                break;
        }
    }

    @Override
    public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
        Intent intent = new Intent();

        HashMap<String, String> item  = mPrinterList.get(position);
        String selectTarget = item.get("Target");
        int location = selectTarget.indexOf("[");
        if ( location == -1){
            intent.putExtra(getString(R.string.title_target_printer), selectTarget);
            intent.putExtra(getString(R.string.title_target_gfe), selectTarget);
            intent.putExtra(getString(R.string.title_target_display), selectTarget);
            intent.putExtra(getString(R.string.title_target_scanner), selectTarget);
        }else{
            String tempTarget = selectTarget.substring(0,location);
            intent.putExtra(getString(R.string.title_target_printer), tempTarget + getString(R.string.deviceId_printer));
            intent.putExtra(getString(R.string.title_target_gfe), tempTarget + getString(R.string.deviceId_gfe));
            intent.putExtra(getString(R.string.title_target_display), tempTarget + getString(R.string.deviceId_display));
            intent.putExtra(getString(R.string.title_target_scanner), tempTarget + getString(R.string.deviceId_scanner));
        }
        setResult(RESULT_OK, intent);

        finish();
    }

    private void restartDiscovery() {
        while (true) {
            try {
                sdkManager.stopDiscovery();
                break;
            }
            catch (Epos2Exception e) {
                if (e.getErrorStatus() != Epos2Exception.ERR_PROCESSING) {
                    return;
                }
            }
        }

        mPrinterList.clear();
        mPrinterListAdapter.notifyDataSetChanged();

        try {
            sdkManager.startDiscovery(this, mFilterOption);
        }
        catch (Exception e) {
        }
    }

    @Override
    public void onDiscoveryResult(final DeviceInfo deviceInfo){
        runOnUiThread(new Runnable() {
            @Override
            public synchronized void run() {
                HashMap<String, String> item = new HashMap<String, String>();
                item.put("PrinterName", deviceInfo.getDeviceName());
                item.put("Target", deviceInfo.getTarget());
                mPrinterList.add(item);
                mPrinterListAdapter.notifyDataSetChanged();
            }
        });
    }

    @Override
    public void onGfeReceiveEPOS2SDKManager(final GermanyFiscalElement GfeObj, final int code, final String printJobId){
        /* do nothing. */
    }
    @Override
    public void onPtrReceiveResult(final Printer printerObj, final int code, final PrinterStatusInfo status, final String printJobId){
        /* do nothing. */
    }
    @Override
    public void onFirmwareListDownloadResult(final int code, FirmwareInfo[] firmwareList){
        /* do nothing. */
    }
    @Override
    public void onFirmwareInformationReceiveResult(FirmwareInfo firmwareInfo){
        /* do nothing. */
    }
    @Override
    public void onFirmwareUpdateProgressResult(String task, float progress){
        /* do nothing. */
    }
    @Override
    public void onFirmwareUpdateResult(final int code, int maxWaitTime){
        /* do nothing. */
    }
    @Override
    public void onUpdateVerifyResult(final int code){
        /* do nothing. */
    }
    @Override
    public void onDispReceiveResult(final LineDisplay LineDisplayObj, final int code){
        /* do nothing. */
    }
    @Override
    public void onScanDataResult(final BarcodeScanner scanObj, final String data){
        /* do nothing. */
    }
    @Override
    public void onLogEPOS2SDKManager(final String apiLog){
        /* do nothing. */
    }
    @Override
    public void onConnectionResult(final Object printerObj, final int code){
        /* do nothing. */
    }
}
